sub init()
    m.bg = m.top.findNode("bg")
    m.box = m.top.findNode("box")
    m.label = m.top.findNode("label")
    m.top.focusable = true
    m.top.observeField("focusedChild", "render")
    render()
end sub

sub render()
    focused = m.top.hasFocus()
    h = m.top.height
    m.bg.width = m.top.width
    m.bg.height = h
    m.bg.visible = focused
    m.box.translation = [20, (h - 44) / 2]
    state = "_off"
    if m.top.checked then state = "_on"
    if focused then
        m.box.uri = "pkg:/images/check_dark" + state + ".png"
        m.label.color = "0x0B0B0BFF"
    else
        m.box.uri = "pkg:/images/check" + state + ".png"
        m.label.color = "0xF5F5F5FF"
    end if
    m.label.translation = [84, 0]
    m.label.width = m.top.width - 104
    m.label.height = h
    m.label.text = m.top.text
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if press and key = "OK" then
        m.top.checked = not m.top.checked
        m.top.pressed = true
        return true
    end if
    return false
end function
