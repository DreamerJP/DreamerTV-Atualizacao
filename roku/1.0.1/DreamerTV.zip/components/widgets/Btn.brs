sub init()
    m.bg = m.top.findNode("bg")
    m.label = m.top.findNode("label")
    m.top.focusable = true
    m.top.observeField("focusedChild", "render")
    restyle()
end sub

sub restyle()
    font = CreateObject("roSGNode", "Font")
    if m.top.bold then font.uri = "font:BoldSystemFontFile" else font.uri = "font:SystemFontFile"
    font.size = m.top.fontSize
    m.label.font = font
    render()
end sub

sub render()
    w = m.top.width
    h = m.top.height
    focused = m.top.hasFocus()
    m.bg.width = w
    m.bg.height = h
    m.label.width = w - 24
    m.label.height = h
    m.label.translation = [12, 0]
    m.label.text = m.top.text
    isTab = m.top.kind = "tab"
    uri = "pkg:/images/btn_normal.9.png"
    color = "0xF5F5F5FF"
    if focused then
        uri = "pkg:/images/btn_focused.9.png"
        color = "0x0B0B0BFF"
    else if m.top.disabled then
        uri = "pkg:/images/btn_disabled.9.png"
        color = "0xA3A3A3FF"
    else if m.top.selected then
        uri = "pkg:/images/btn_selected.9.png"
        if isTab then uri = "pkg:/images/tab_selected.9.png"
        color = "0xFFFFFFFF"
    else if isTab then
        uri = ""
        color = "0xC4C4C4FF"
    end if
    m.bg.visible = uri <> ""
    if uri <> "" and m.bg.uri <> uri then m.bg.uri = uri
    m.label.color = color
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if press and key = "OK" then
        if not m.top.disabled then m.top.pressed = true
        return true
    end if
    return false
end function
