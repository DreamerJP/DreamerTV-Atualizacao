sub init()
    m.bg = m.top.findNode("bg")
    m.label = m.top.findNode("label")
    m.top.focusable = true
    m.top.observeField("focusedChild", "render")
    render()
end sub

sub render()
    focused = m.top.hasFocus()
    m.bg.width = m.top.width
    m.bg.height = m.top.height
    if focused then m.bg.uri = "pkg:/images/input_focused.9.png" else m.bg.uri = "pkg:/images/input_normal.9.png"
    m.label.translation = [36, 0]
    m.label.width = m.top.width - 72
    m.label.height = m.top.height
    value = m.top.value
    if value = "" then
        m.label.text = m.top.hint
        m.label.color = "0xA3A3A3FF"
    else
        if m.top.secret then
            dots = ""
            for i = 1 to Len(value)
                dots = dots + "•"
            end for
            m.label.text = dots
        else
            m.label.text = value
        end if
        m.label.color = "0xF5F5F5FF"
    end if
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if press and key = "OK" then
        m.top.pressed = true
        return true
    end if
    return false
end function
