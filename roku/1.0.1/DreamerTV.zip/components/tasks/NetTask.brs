' Synopses, subtitles and the check for a newer package. Request {id, cmd, args} -> response {id, cmd, ok, data}.

sub init()
    m.top.functionName = "runLoop"
end sub

sub runLoop()
    port = CreateObject("roMessagePort")
    m.top.observeField("request", port)
    while true
        msg = wait(0, port)
        if type(msg) = "roSGNodeEvent" and msg.getField() = "request" then
            req = msg.getData()
            if req <> invalid then
                out = net_handle(req)
                out.id = req.id
                out.cmd = req.cmd
                m.top.response = out
            end if
        end if
    end while
end sub

function net_handle(req as object) as object
    args = req.args
    if args = invalid then args = {}
    cmd = req.cmd
    if cmd = "details" then
        found = invalid
        if not u_true(args.isSeries) then found = dc_websiteDetails(u_str(args.title))
        if found = invalid then found = dc_details(u_str(args.title), u_true(args.isSeries), u_str(args.poster))
        return { ok: found <> invalid, data: found }
    else if cmd = "subtitleTitles" then
        return sub_findTitles(u_str(args.name), u_true(args.isSeries))
    else if cmd = "subtitleDownload" then
        return sub_download(args)
    else if cmd = "trailer" then
        return net_openTrailer(u_str(args.id))
    else if cmd = "probe" then
        return { ok: true, data: { status: net_probe(u_str(args.url)) } }
    else if cmd = "update" then
        return net_update()
    else if cmd = "invalidate" then
        u_deleteFile("cachefs:/matches.json")
        u_deleteFile("cachefs:/feed.json")
        return { ok: true }
    else if cmd = "clearCaches" then
        for each f in ["cachefs:/details.json", "cachefs:/matches.json", "cachefs:/feed.json"]
            u_deleteFile(f)
        end for
        return { ok: true }
    else if cmd = "storage" then
        total = 0#
        fs = CreateObject("roFileSystem")
        for each name in fs.GetDirectoryListing("cachefs:/")
            total = total + u_fileSize("cachefs:/" + name)
        end for
        return { ok: true, data: { bytes: total } }
    end if
    return { ok: false, message: "Pedido desconhecido." }
end function

' A Roku app cannot show YouTube inside it, so the trailer opens in the YouTube app (id 837) through the
' TV's own remote-control address, with the deep link every certified Roku app accepts.
function net_openTrailer(videoId as string) as object
    apps = CreateObject("roAppManager")
    if not apps.IsAppInstalled("837", "") then return { ok: false, reason: "notInstalled" }
    port = CreateObject("roMessagePort")
    t = CreateObject("roUrlTransfer")
    t.SetMessagePort(port)
    t.SetUrl("http://127.0.0.1:8060/launch/837?contentId=" + u_escape(videoId) + "&mediaType=movie")
    if not t.AsyncPostFromString("") then return { ok: false, reason: "refused", status: 0 }
    msg = wait(8000, port)
    status = 0
    if type(msg) = "roUrlEvent" then status = msg.GetResponseCode() else t.AsyncCancel()
    if status >= 200 and status < 300 then return { ok: true, status: status }
    return { ok: false, reason: "refused", status: status }
end function

' HTTP answer of a video address, asked without downloading the file. 0 when there is no answer.
function net_probe(url as string) as integer
    port = CreateObject("roMessagePort")
    t = CreateObject("roUrlTransfer")
    t.SetMessagePort(port)
    t.SetUrl(url)
    t.AddHeader("User-Agent", u_providerAgent())
    if LCase(Left(url, 6)) = "https:" then
        t.SetCertificatesFile("common:/certs/ca-bundle.crt")
        t.InitClientCertificates()
    end if
    if not t.AsyncHead() then return 0
    msg = wait(10000, port)
    if type(msg) = "roUrlEvent" then
        code = msg.GetResponseCode()
        if code > 0 then return code
        return 0
    end if
    t.AsyncCancel()
    return 0
end function

' Newer package published for the installer ------------------------------------------------------------

function net_versionParts(v as string) as object
    out = []
    for each p in v.Split(".")
        out.Push(p.ToInt())
    end for
    while out.Count() < 3
        out.Push(0)
    end while
    return out
end function

function net_update() as object
    data = u_httpJson(cfg_updateUrl() + "?t=" + Int(u_now() / 60000).ToStr(), 15000)
    if not u_isAA(data) then return { ok: false }
    published = u_str(data.versao)
    current = cfg_version()
    a = net_versionParts(published)
    b = net_versionParts(current)
    newer = false
    for i = 0 to 2
        if a[i] <> b[i] then
            newer = a[i] > b[i]
            exit for
        end if
    end for
    return { ok: true, data: { published: published, current: current, newer: newer } }
end function

' Portuguese subtitles found online (OpenSubtitles through Stremio) ----------------------------------------

function sub_languages() as object
    return ["pob", "pt-br", "por", "pt"]
end function

function sub_normalize(value as dynamic) as string
    re = CreateObject("roRegex", "[^a-z0-9]+", "")
    return re.ReplaceAll(u_fold(value), " ").Trim()
end function

function sub_query(title as string) as object
    yearRe = CreateObject("roRegex", "[\[(]((?:19|20)\d{2})[\])]", "")
    found = yearRe.Match(title)
    year = 0
    if found.Count() > 1 then year = found[1].ToInt()
    clean = CreateObject("roRegex", "\s*-\s*(?:epis[oó]dio\s*\d+|t\d+e\d+).*", "i").ReplaceAll(title, "")
    clean = CreateObject("roRegex", "\s*\[.*?\]|\(.*?\)|\b(?:1080p|720p|2160p|4k|dublado|legendado|dual\s*áudio)\b", "i").ReplaceAll(clean, "")
    return { title: clean.Trim(), year: year }
end function

function sub_fail(message as string) as object
    return { ok: false, message: message }
end function

function sub_findTitles(target as string, isSeries as boolean) as object
    q = sub_query(target)
    if q.title = "" then return sub_fail("Não foi possível identificar o título para a legenda.")
    kind = "movie"
    if isSeries then kind = "series"
    data = u_httpJson("https://v3-cinemeta.strem.io/catalog/" + kind + "/top/search=" + u_escape(q.title) + ".json", 20000)
    if not u_isAA(data) then return sub_fail("Não foi possível buscar a legenda. Tente novamente.")
    metas = data.metas
    if not u_isArray(metas) or metas.Count() = 0 then return sub_fail("Título não encontrado no catálogo de legendas.")
    imdbRe = CreateObject("roRegex", "^tt\d+$", "")
    yearRe = CreateObject("roRegex", "(?:19|20)\d{2}", "")
    valid = []
    seen = {}
    for each meta in metas
        id = u_str(meta.imdb_id)
        if id = "" then id = u_str(meta.id)
        name = u_str(meta.name)
        year = u_str(meta.releaseInfo)
        if year = "" then year = u_str(meta.year)
        if imdbRe.IsMatch(id) and name <> "" and not seen.DoesExist(id) then
            seen[id] = true
            valid.Push({ id: id, name: name, year: year })
        end if
    end for
    byYear = []
    if q.year = 0 then
        byYear = valid
    else
        for each t in valid
            y = yearRe.Match(t.year)
            if y.Count() > 0 and y[0].ToInt() = q.year then byYear.Push(t)
        end for
        if byYear.Count() = 0 then
            for each t in valid
                if t.year = "" then byYear.Push(t)
            end for
        end if
    end if
    exact = []
    for each t in byYear
        if sub_normalize(t.name) = sub_normalize(q.title) then exact.Push(t)
    end for
    found = byYear
    if exact.Count() > 0 then found = exact
    if found.Count() = 0 then return sub_fail("Não foi encontrada uma correspondência para este título e ano.")
    return { ok: true, data: found }
end function

function sub_download(args as object) as object
    isSeries = u_true(args.isSeries)
    seasonMatch = CreateObject("roRegex", "\d+", "").Match(u_str(args.season))
    seasonNumber = 1
    if seasonMatch.Count() > 0 then seasonNumber = seasonMatch[0].ToInt()
    epRe = CreateObject("roRegex", "(?:e|ep|epis[oó]dio)\s*(\d+)", "i")
    ep = epRe.Match(u_str(args.episodeCode))
    if ep.Count() < 2 then ep = epRe.Match(u_str(args.title))
    if isSeries and ep.Count() < 2 then return sub_fail("Não foi possível identificar o episódio para a legenda.")
    if isSeries then
        url = "https://opensubtitles-v3.strem.io/subtitles/series/" + u_str(args.imdbId) + ":" + seasonNumber.ToStr() + ":" + ep[1].ToInt().ToStr() + ".json"
    else
        url = "https://opensubtitles-v3.strem.io/subtitles/movie/" + u_str(args.imdbId) + ".json"
    end if
    data = u_httpJson(url, 20000)
    if not u_isAA(data) then return sub_fail("Não foi possível buscar a legenda. Tente novamente.")
    best = invalid
    bestRank = 99
    langs = sub_languages()
    if u_isArray(data.subtitles) then
        for each s in data.subtitles
            rank = u_indexOf(langs, LCase(u_str(s.lang)))
            if u_str(s.url) <> "" and rank >= 0 and rank < bestRank then
                best = s
                bestRank = rank
            end if
        end for
    end if
    if best = invalid then return sub_fail("Nenhuma legenda em português encontrada.")
    path = "tmp:/legenda.srt"
    u_deleteFile(path)
    r = u_httpGet(u_str(best.url), 20000, false, path)
    if r.status <> 200 then return sub_fail("Não foi possível buscar a legenda. Tente novamente.")
    bytes = CreateObject("roByteArray")
    bytes.ReadFile(path)
    u_deleteFile(path)
    if bytes.Count() = 0 then return sub_fail("O arquivo de legenda está vazio.")
    cues = sub_parseSrt(sub_decode(bytes))
    if cues.Count() = 0 then return sub_fail("O arquivo de legenda está vazio.")
    return { ok: true, data: cues }
end function

' UTF-8 when the bytes are valid UTF-8; otherwise Windows-1252, common in Brazilian subtitle files.
function sub_decode(bytes as object) as string
    if sub_isUtf8(bytes) then return bytes.ToAsciiString()
    high = [8364, 0, 8218, 402, 8222, 8230, 8224, 8225, 710, 8240, 352, 8249, 338, 0, 381, 0, 0, 8216, 8217, 8220, 8221, 8226, 8211, 8212, 732, 8482, 353, 8250, 339, 0, 382, 376]
    out = CreateObject("roByteArray")
    for i = 0 to bytes.Count() - 1
        b = bytes[i]
        code = b
        if b >= 128 and b < 160 then code = high[b - 128]
        if code = 0 then code = 63
        if code < 128 then
            out.Push(code)
        else if code < 2048 then
            out.Push(192 + Int(code / 64))
            out.Push(128 + (code mod 64))
        else
            out.Push(224 + Int(code / 4096))
            out.Push(128 + (Int(code / 64) mod 64))
            out.Push(128 + (code mod 64))
        end if
    end for
    return out.ToAsciiString()
end function

function sub_isUtf8(bytes as object) as boolean
    i = 0
    n = bytes.Count()
    while i < n
        b = bytes[i]
        if b < 128 then
            i = i + 1
        else
            need = 0
            if b >= 194 and b <= 223 then
                need = 1
            else if b >= 224 and b <= 239 then
                need = 2
            else if b >= 240 and b <= 244 then
                need = 3
            else
                return false
            end if
            if i + need >= n then return false
            for k = 1 to need
                c = bytes[i + k]
                if c < 128 or c > 191 then return false
            end for
            i = i + need + 1
        end if
    end while
    return true
end function

function sub_parseSrt(text as string) as object
    timeRe = CreateObject("roRegex", "(\d+):(\d{2}):(\d{2})[,.](\d{3})\s*-->\s*(\d+):(\d{2}):(\d{2})[,.](\d{3})", "")
    tagRe = CreateObject("roRegex", "<[^>]+>|\{[^}]+\}", "")
    cues = []
    lines = text.Replace(Chr(13), "").Split(Chr(10))
    i = 0
    n = lines.Count()
    while i < n
        found = timeRe.Match(lines[i])
        if found.Count() > 8 then
            start = ((found[1].ToInt() * 60 + found[2].ToInt()) * 60 + found[3].ToInt()) * 1000 + found[4].ToInt()
            finish = ((found[5].ToInt() * 60 + found[6].ToInt()) * 60 + found[7].ToInt()) * 1000 + found[8].ToInt()
            body = []
            i = i + 1
            while i < n and lines[i].Trim() <> ""
                body.Push(lines[i])
                i = i + 1
            end while
            textBody = tagRe.ReplaceAll(body.Join(Chr(10)), "").Trim()
            if textBody <> "" then cues.Push({ s: start, e: finish, t: textBody })
        else
            i = i + 1
        end if
    end while
    return cues
end function
