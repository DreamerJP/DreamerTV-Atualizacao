' Sign-in screen: same fields, messages and automatic entry as the Android and Samsung apps.

sub init()
    m.form = m.top.findNode("form")
    m.loading = m.top.findNode("loading")
    m.status = m.top.findNode("status")
    m.spin = m.top.findNode("spin")
    m.error = m.top.findNode("error")
    m.fields = {
        user: m.top.findNode("user"), pass: m.top.findNode("pass"), server: m.top.findNode("server"),
        remember: m.top.findNode("remember"), connect: m.top.findNode("connect")
    }
    m.order = ["user", "pass", "server", "remember", "connect"]
    for each name in m.order
        m.fields[name].name = name
        m.fields[name].observeField("pressed", "onPressed")
    end for
    m.values = { user: "", pass: "", server: "" }
    m.remember = true
    m.attempt = 0
    m.busy = false
end sub

function showScreen(params as object) as boolean
    c = pr_credentials()
    m.remember = c.remember
    if m.remember then
        m.values.user = u_str(c.username)
        m.values.pass = u_str(c.password)
    end if
    m.values.server = u_str(c.serverUrl)
    render()
    setBusy(false)
    if m.values.user <> "" then m.fields.connect.setFocus(true) else m.fields.user.setFocus(true)
    if pr_isLoggedIn() and m.remember then startLogin(c.username, c.password, c.serverUrl)
    return true
end function

function leaveScreen(params as object) as boolean
    m.attempt = m.attempt + 1
    m.spin.control = "stop"
    return true
end function

function coverScreen(params as object) as boolean
    return true
end function

function returnToScreen(params as object) as boolean
    return true
end function

sub render()
    m.fields.user.value = m.values.user
    m.fields.pass.value = m.values.pass
    m.fields.server.value = m.values.server
    m.fields.remember.checked = m.remember
    u_trace("loginForm", { user: m.values.user, server: m.values.server, password: m.values.pass <> "", remember: m.remember })
end sub

sub setBusy(value as boolean)
    m.busy = value
    m.form.visible = not value
    m.loading.visible = value
    if value then
        m.status.text = "Preparando seu acesso…"
        m.spin.control = "start"
    else
        m.spin.control = "stop"
        m.fields.connect.setFocus(true)
    end if
end sub

sub showError(text as string)
    m.error.text = text
    m.error.visible = true
end sub

sub onPressed(event as object)
    name = event.getRoSGNode().name
    if name = "remember" then
        m.remember = m.fields.remember.checked
        pr_setRemember(m.remember)
        render()
    else if name = "connect" then
        submit()
    else
        editField(name)
    end if
end sub

sub editField(name as string)
    m.editing = name
    kb = CreateObject("roSGNode", "StandardKeyboardDialog")
    titles = { user: "Usuário", pass: "Senha", server: "Servidor (opcional)" }
    kb.title = titles[name]
    kb.text = m.values[name]
    kb.buttons = ["Confirmar", "Cancelar"]
    if name = "pass" then kb.textEditBox.secureMode = true
    if name = "server" then kb.message = ["Deixe como está para usar o servidor padrão."]
    kb.observeField("buttonSelected", "onKeyboardButton")
    kb.observeField("wasClosed", "onKeyboardClosed")
    m.keyboard = kb
    m.top.getScene().dialog = kb
    u_trace("keyboard", { field: name })
end sub

sub onKeyboardButton()
    kb = m.keyboard
    if kb = invalid then return
    u_trace("keyboardButton", { index: kb.buttonSelected, length: Len(kb.text) })
    if kb.buttonSelected = 0 then
        m.values[m.editing] = kb.text.Trim()
        render()
    end if
    kb.close = true
end sub

sub onKeyboardClosed()
    m.keyboard = invalid
    order = m.order
    idx = u_indexOf(order, m.editing)
    ' Confirming a field moves on to the next one, like the "Done" key of the Android form.
    if idx >= 0 and idx < 2 and m.values[m.editing] <> "" then
        m.fields[order[idx + 1]].setFocus(true)
    else if m.editing = "server" then
        m.fields.connect.setFocus(true)
    else
        m.fields[m.editing].setFocus(true)
    end if
end sub

function failureMessage(response as dynamic, serverText as string) as string
    if response <> invalid and u_true(response.denied) then return "O provedor recusou o acesso. Confira usuário, senha e se a assinatura está ativa."
    if response <> invalid and u_str(response.message) = "INVALID_SERVER" then return "O endereço do servidor é inválido."
    if not u_isValidServer(serverText) then return "O endereço do servidor é inválido."
    info = CreateObject("roDeviceInfo")
    if not info.GetLinkStatus() then return "Sem conexão com a internet. Confira a rede da TV."
    return "O provedor não respondeu. Pode ser instabilidade, tente de novo em alguns minutos."
end function

sub submit()
    u = m.values.user.Trim()
    p = m.values.pass.Trim()
    s = m.values.server.Trim()
    if s = "" then s = pr_credentials().serverUrl
    if u = "" or p = "" then
        showError("Preencha usuário e senha")
        return
    end if
    startLogin(u, p, s)
end sub

sub startLogin(u as string, p as string, s as string)
    m.attempt = m.attempt + 1
    m.pending = { attempt: m.attempt, user: u, pass: p, server: s }
    m.error.visible = false
    setBusy(true)
    m.status.text = "Conectando à sua conta…"
    c = pr_credentials()
    base = u_stripTrailingSlashes(s)
    acceptedBefore = pr_isLoggedIn() and c.username = u and c.password = p and LCase(u_stripTrailingSlashes(u_str(c.serverUrl))) = LCase(base)
    rq_send(m.global.catalog, "login", { user: u, pass: p, server: s, acceptedBefore: acceptedBefore, knownUsers: pr_session().knownUsers }, onLogin)
end sub

sub onLogin(response as object)
    pending = m.pending
    if pending = invalid or pending.attempt <> m.attempt then return
    if response.ok then
        m.status.text = "Abrindo seu catálogo…"
        pr_setCredentials(pending.user, pending.pass, u_stripTrailingSlashes(pending.server), m.remember)
        u_trace("login", { ok: true })
        ui_nav("main")
        return
    end if
    u_trace("login", { ok: false, message: response.message })
    setBusy(false)
    if u_str(response.message) = "EMPTY" then
        showError(failureMessage(invalid, pending.server))
    else
        showError(failureMessage(response, pending.server))
    end if
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    if key = "back" then
        if m.busy then
            m.attempt = m.attempt + 1
            setBusy(false)
            showError("Entrada cancelada. Você pode tentar novamente.")
        else
            ui_nav("exit")
        end if
        return true
    end if
    if m.busy then return true
    current = ""
    for each name in m.order
        if m.fields[name].hasFocus() then current = name
    end for
    idx = u_indexOf(m.order, current)
    if key = "down" and idx >= 0 and idx < m.order.Count() - 1 then
        m.fields[m.order[idx + 1]].setFocus(true)
        return true
    end if
    if key = "up" and idx > 0 then
        m.fields[m.order[idx - 1]].setFocus(true)
        return true
    end if
    return true
end function
