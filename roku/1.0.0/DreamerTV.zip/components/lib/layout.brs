' Order of the channel categories, kept on this TV for each list ("live" and "24h"): categories pinned
' by the user come first, hidden ones are left out, adult ones go last, and the most recently watched
' channels form their own category.
' The provider renames and renumbers things without notice: categories are matched by name ignoring
' case, accents and spacing; choices for a name that disappeared are kept and apply again if it
' returns; recent channels keep their name to be found again when the number changes.

function cl_norm(name as dynamic) as string
    if m.cl_other = invalid then m.cl_other = CreateObject("roRegex", "[^a-z0-9]+", "")
    return m.cl_other.ReplaceAll(u_fold(name), " ").Trim()
end function

function cl_isAdult(name as dynamic) as boolean
    if m.cl_adult = invalid then m.cl_adult = CreateObject("roRegex", "adult|xxx|\+ ?18|18 ?\+|erotic", "i")
    compact = cl_norm(name).Replace(" ", "")
    return m.cl_adult.IsMatch(compact + " " + u_str(name))
end function

function cl_get(mode as string) as object
    l = pr_get("catLayout." + mode, {})
    if not u_isArray(l.pins) then l.pins = []
    if not u_isArray(l.hidden) then l.hidden = []
    return l
end function

function cl_without(list as object, name as string) as object
    key = cl_norm(name)
    out = []
    for each n in list
        if cl_norm(n) <> key then out.Push(n)
    end for
    return out
end function

function cl_has(list as object, name as string) as boolean
    key = cl_norm(name)
    for each n in list
        if cl_norm(n) = key then return true
    end for
    return false
end function

function cl_isPinned(mode as string, name as string) as boolean
    return cl_has(cl_get(mode).pins, name)
end function

sub cl_pin(mode as string, name as string)
    l = cl_get(mode)
    l.pins = cl_without(l.pins, name)
    l.pins.Push(name)
    pr_set("catLayout." + mode, l)
end sub

sub cl_unpin(mode as string, name as string)
    l = cl_get(mode)
    l.pins = cl_without(l.pins, name)
    pr_set("catLayout." + mode, l)
end sub

sub cl_hide(mode as string, name as string)
    l = cl_get(mode)
    l.pins = cl_without(l.pins, name)
    l.hidden = cl_without(l.hidden, name)
    l.hidden.Push(name)
    pr_set("catLayout." + mode, l)
end sub

sub cl_reset(mode as string)
    pr_set("catLayout." + mode, { pins: [], hidden: [] })
end sub

function cl_recent(mode as string) as object
    out = []
    for each r in pr_get("recentChannels." + mode, [])
        if u_isAA(r) and u_str(r.id) <> "" then out.Push(r)
    end for
    return out
end function

sub cl_remember(mode as string, channel as object)
    list = [{ id: channel.id, name: channel.name }]
    key = cl_norm(channel.name)
    for each r in cl_recent(mode)
        if r.id <> channel.id and cl_norm(r.name) <> key and list.Count() < 10 then list.Push(r)
    end for
    pr_set("recentChannels." + mode, list)
end sub

' The remembered channels that still exist, found by number or, when it changed, by name.
function cl_recentChannels(mode as string, channels as object) as object
    byId = {}
    byName = {}
    for each c in channels
        byId[c.id] = c
        k = cl_norm(c.name)
        if not byName.DoesExist(k) then byName[k] = c
    end for
    seen = {}
    out = []
    for each r in cl_recent(mode)
        c = byId[r.id]
        if c = invalid then c = byName[cl_norm(r.name)]
        if c <> invalid and not seen.DoesExist(c.id) then
            seen[c.id] = true
            out.Push(c)
        end if
    end for
    return out
end function

function cl_order(mode as string, categories as object) as object
    l = cl_get(mode)
    visible = []
    for each c in categories
        if not cl_has(l.hidden, c.name) then visible.Push(c)
    end for
    pinned = []
    for each n in l.pins
        key = cl_norm(n)
        for each c in visible
            if cl_norm(c.name) = key then
                pinned.Push(c)
                exit for
            end if
        end for
    end for
    normal = []
    adult = []
    for each c in visible
        if not cl_has(l.pins, c.name) then
            if cl_isAdult(c.name) then adult.Push(c) else normal.Push(c)
        end if
    end for
    pinned.Append(normal)
    pinned.Append(adult)
    return pinned
end function
