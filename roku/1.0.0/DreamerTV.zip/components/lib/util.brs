' Text, time, URL and network helpers shared by screens and tasks.

' Numbers read back from node fields come boxed (roInt, roFloat...), so types are told apart by interface.
function u_numberKind(value as dynamic) as string
    if GetInterface(value, "ifInt") <> invalid then return "int"
    if GetInterface(value, "ifLongInt") <> invalid then return "long"
    if GetInterface(value, "ifFloat") <> invalid or GetInterface(value, "ifDouble") <> invalid then return "real"
    return ""
end function

function u_str(value as dynamic) as string
    if value = invalid then return ""
    if GetInterface(value, "ifString") <> invalid then return value
    kind = u_numberKind(value)
    if kind = "int" or kind = "long" then return value.ToStr()
    if kind = "real" then
        if value = Int(value) and Abs(value) < 2000000000 then return Int(value).ToStr()
        return Str(value).Trim()
    end if
    if GetInterface(value, "ifBoolean") <> invalid then
        if value then return "true"
        return "false"
    end if
    return ""
end function

function u_int(value as dynamic) as integer
    if value = invalid then return 0
    if GetInterface(value, "ifString") <> invalid then return value.ToInt()
    kind = u_numberKind(value)
    if kind = "int" then return value
    if kind <> "" then return Int(value)
    return 0
end function

' Comparing invalid with a boolean stops BrightScript, so optional flags are read through these.
function u_true(value as dynamic) as boolean
    if GetInterface(value, "ifBoolean") <> invalid then return value
    return false
end function

function u_false(value as dynamic) as boolean
    if GetInterface(value, "ifBoolean") <> invalid then return not value
    return false
end function

function u_iif(condition as boolean, yes as dynamic, no as dynamic) as dynamic
    if condition then return yes
    return no
end function

function u_pad(n as integer, size = 2 as integer) as string
    s = n.ToStr()
    while Len(s) < size
        s = "0" + s
    end while
    return s
end function

function u_formatTime(ms as dynamic) as string
    total = Int(u_num(ms) / 1000)
    if total < 0 then total = 0
    h = Int(total / 3600)
    mins = Int(total / 60) mod 60
    s = total mod 60
    if h > 0 then return u_pad(h) + ":" + u_pad(mins) + ":" + u_pad(s)
    return u_pad(mins) + ":" + u_pad(s)
end function

function u_positionLabel(ms as dynamic) as string
    minutes = Int(u_num(ms) / 60000)
    if minutes < 0 then minutes = 0
    if minutes >= 60 then return Int(minutes / 60).ToStr() + "h " + (minutes mod 60).ToStr() + "min"
    return minutes.ToStr() + "min"
end function

function u_num(value as dynamic) as double
    if value = invalid then return 0
    if GetInterface(value, "ifString") <> invalid then return Val(value)
    if u_numberKind(value) <> "" then return value
    return 0
end function

function u_clock() as string
    d = CreateObject("roDateTime")
    d.ToLocalTime()
    return u_pad(d.GetHours()) + ":" + u_pad(d.GetMinutes())
end function

' Milliseconds since 1970, as a double (an integer would overflow).
function u_now() as double
    d = CreateObject("roDateTime")
    seconds# = d.AsSeconds()
    return seconds# * 1000# + d.GetMilliseconds()
end function

function u_escape(value as string) as string
    t = CreateObject("roUrlTransfer")
    return t.Escape(value)
end function

function u_unescape(value as string) as string
    t = CreateObject("roUrlTransfer")
    return t.Unescape(value)
end function

function u_trim(value as dynamic) as string
    return u_str(value).Trim()
end function

function u_startsWith(text as string, prefix as string) as boolean
    return Left(text, Len(prefix)) = prefix
end function

function u_endsWith(text as string, suffix as string) as boolean
    if Len(suffix) > Len(text) then return false
    return Right(text, Len(suffix)) = suffix
end function

function u_stripTrailingSlashes(value as string) as string
    s = value
    while Len(s) > 0 and Right(s, 1) = "/"
        s = Left(s, Len(s) - 1)
    end while
    return s
end function

' Last path segment, ignoring trailing slashes.
function u_lastSegment(url as string) as string
    s = u_stripTrailingSlashes(url)
    parts = s.Split("/")
    if parts.Count() = 0 then return ""
    return parts[parts.Count() - 1]
end function

function u_replace(text as string, find as string, repl as string) as string
    return text.Replace(find, repl)
end function

' Accents removed and letters lowered; used for matching, never shown.
function u_fold(value as dynamic) as string
    s = LCase(u_str(value))
    if m.u_foldRules = invalid then
        rules = []
        pairs = [["[áàâãäåā]", "a"], ["[éèêëē]", "e"], ["[íìîïī]", "i"], ["[óòôõöø]", "o"], ["[úùûü]", "u"], ["ç", "c"], ["ñ", "n"], ["ý|ÿ", "y"]]
        for each p in pairs
            rules.Push({ re: CreateObject("roRegex", p[0], ""), to: p[1] })
        end for
        m.u_foldRules = rules
        m.u_asciiOnly = CreateObject("roRegex", "^[\x00-\x7F]*$", "")
    end if
    if m.u_asciiOnly.IsMatch(s) then return s
    for each r in m.u_foldRules
        s = r.re.ReplaceAll(s, r.to)
    end for
    return s
end function

function u_jsonParse(text as dynamic) as dynamic
    if text = invalid then return invalid
    s = u_str(text)
    if s = "" then return invalid
    return ParseJson(s)
end function

function u_isArray(value as dynamic) as boolean
    return Type(value) = "roArray"
end function

function u_isAA(value as dynamic) as boolean
    return Type(value) = "roAssociativeArray"
end function

function u_isString(value as dynamic) as boolean
    return GetInterface(value, "ifString") <> invalid
end function

function u_copyAA(source as object) as object
    out = {}
    if source = invalid then return out
    for each k in source
        out[k] = source[k]
    end for
    return out
end function

function u_merge(base as object, extra as object) as object
    out = u_copyAA(base)
    if extra <> invalid then
        for each k in extra
            out[k] = extra[k]
        end for
    end if
    return out
end function

function u_indexOf(list as object, value as dynamic) as integer
    if list = invalid then return -1
    for i = 0 to list.Count() - 1
        if list[i] = value then return i
    end for
    return -1
end function

' Splits scheme://host[:port]/path?query; invalid when the address is not http(s).
function u_parseUrl(url as string) as dynamic
    re = CreateObject("roRegex", "^(https?)://([^/?#]+)([^?#]*)(\?[^#]*)?", "i")
    found = re.Match(url)
    if found.Count() < 4 then return invalid
    authority = found[2]
    query = ""
    if found.Count() > 4 then query = found[4]
    return { scheme: LCase(found[1]), authority: authority, path: found[3], query: query, hasUserInfo: Instr(1, authority, "@") > 0 }
end function

function u_origin(url as string) as string
    p = u_parseUrl(url)
    if p = invalid then return ""
    return p.scheme + "://" + LCase(p.authority)
end function

function u_isValidServer(url as string) as boolean
    p = u_parseUrl(u_stripTrailingSlashes(url.Trim()))
    if p = invalid then return false
    return p.authority <> "" and not p.hasUserInfo
end function

function u_providerAgent() as string
    ' The provider expects a VLC-compatible client for the catalog and the video.
    return "VLC/3.0.18 LibVLC/3.0.18"
end function

' Blocking GET for task threads. Returns {status, text, failure}; status 0 means no answer.
function u_httpGet(url as string, timeoutMs = 30000 as integer, provider = false as boolean, toFile = "" as string) as object
    port = CreateObject("roMessagePort")
    t = CreateObject("roUrlTransfer")
    t.SetMessagePort(port)
    t.SetUrl(url)
    t.RetainBodyOnError(true)
    t.EnableEncodings(true)
    if LCase(Left(url, 6)) = "https:" then
        t.SetCertificatesFile("common:/certs/ca-bundle.crt")
        t.InitClientCertificates()
    end if
    if provider then t.AddHeader("User-Agent", u_providerAgent())
    started = false
    if toFile <> "" then
        started = t.AsyncGetToFile(toFile)
    else
        started = t.AsyncGetToString()
    end if
    if not started then return { status: 0, text: "", failure: "start" }
    msg = wait(timeoutMs, port)
    if type(msg) = "roUrlEvent" then
        code = msg.GetResponseCode()
        body = ""
        if toFile = "" then body = msg.GetString()
        if code < 0 then return { status: 0, text: "", failure: msg.GetFailureReason() }
        return { status: code, text: body, failure: "" }
    end if
    t.AsyncCancel()
    return { status: 0, text: "", failure: "timeout" }
end function

function u_httpJson(url as string, timeoutMs = 18000 as integer) as dynamic
    r = u_httpGet(url, timeoutMs)
    if r.status < 200 or r.status >= 300 then return invalid
    return u_jsonParse(r.text)
end function

function u_readFile(path as string) as string
    fs = CreateObject("roFileSystem")
    if not fs.Exists(path) then return ""
    return ReadAsciiFile(path)
end function

function u_writeFile(path as string, text as string) as boolean
    return WriteAsciiFile(path, text)
end function

function u_deleteFile(path as string) as boolean
    fs = CreateObject("roFileSystem")
    if fs.Exists(path) then return fs.Delete(path)
    return true
end function

function u_fileSize(path as string) as double
    fs = CreateObject("roFileSystem")
    if not fs.Exists(path) then return 0
    info = fs.Stat(path)
    if info = invalid or info.size = invalid then return 0
    return info.size
end function

function u_readJson(path as string) as dynamic
    return u_jsonParse(u_readFile(path))
end function

function u_writeJson(path as string, value as dynamic) as boolean
    return WriteAsciiFile(path, FormatJson(value))
end function

' Test builds print one line per event so the computer checks can follow the app.
sub u_trace(kind as string, data = invalid as dynamic)
    if m.global = invalid then return
    if not m.global.traceEnabled then return
    line = "DTV|" + kind
    if data <> invalid then line = line + "|" + FormatJson(data)
    print line
end sub
