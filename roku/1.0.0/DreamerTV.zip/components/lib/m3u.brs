' Provider list format (SSIPTV/M3U) and the title rules shared with the Android and Samsung apps.

' Text after the first comma that is outside quotes.
function m3u_title(extinf as string) as string
    lastQuote = 0
    at = Instr(1, extinf, Chr(34))
    while at > 0
        lastQuote = at
        at = Instr(at + 1, extinf, Chr(34))
    end while
    comma = Instr(lastQuote + 1, extinf, ",")
    if comma = 0 then return ""
    return Mid(extinf, comma + 1).Trim()
end function

function m3u_attr(line as string, name as string) as string
    target = name + "=" + Chr(34)
    at = Instr(1, line, target)
    if at = 0 then return ""
    from = at + Len(target)
    closing = Instr(from, line, Chr(34))
    if closing = 0 then return ""
    return Mid(line, from, closing - from)
end function

' Pairs of [extinf, url] in order.
function m3u_entries(text as string) as object
    out = []
    current = invalid
    bom = Chr(65279)
    for each raw in text.Split(Chr(10))
        line = raw.Trim()
        if Left(line, 1) = bom then line = Mid(line, 2).Trim()
        if Left(line, 7) = "#EXTINF" then
            current = line
        else if current <> invalid and line <> "" and Left(line, 1) <> "#" then
            out.Push([current, line])
            current = invalid
        end if
    end for
    return out
end function

function m3u_looksLikeM3u(text as string) as boolean
    head = Left(text, 8192)
    return Instr(1, head, "#EXTM3U") > 0 or Instr(1, head, "#EXTINF") > 0
end function

function m3u_hasEntries(text as string) as boolean
    return m3u_entries(text).Count() > 0
end function

function m3u_roots(text as string) as object
    map = {}
    for each e in m3u_entries(text)
        name = m3u_title(e[0])
        if name <> "" then map[UCase(name)] = e[1]
    end for
    return map
end function

function m3u_categories(text as string) as object
    list = []
    for each e in m3u_entries(text)
        name = m3u_title(e[0])
        if name <> "" then list.Push({ id: u_lastSegment(e[1]), name: name, url: e[1], hasContent: invalid })
    end for
    return list
end function

function m3u_channels(text as string, defaultCategory as string) as object
    channels = []
    counts = {}
    order = []
    n = 0
    seen = {}
    for each e in m3u_entries(text)
        n = n + 1
        extinf = e[0]
        url = e[1]
        category = m3u_attr(extinf, "group-title")
        if category = "" then category = defaultCategory
        id = u_lastSegment(url)
        if id = "" then id = "ch_" + n.ToStr()
        name = m3u_title(extinf)
        if name = "" then name = "Canal " + n.ToStr()
        if not seen.DoesExist(id) then
            seen[id] = true
            channels.Push({ id: id, name: name, logo: m3u_attr(extinf, "tvg-logo"), category: category, streamUrl: url, number: n })
            if not counts.DoesExist(category) then
                counts[category] = 0
                order.Push(category)
            end if
            counts[category] = counts[category] + 1
        end if
    end for
    categories = []
    for each name in order
        categories.Push({ id: name, name: name, count: counts[name] })
    end for
    categories.SortBy("name")
    return { categories: categories, channels: channels }
end function

' Movie and series lists are kept as parallel arrays: thousands of items cost much less this way.
function m3u_newList() as object
    return { ids: [], titles: [], posters: [], urls: [], descs: [], folded: [], index: {} }
end function

function m3u_movieId(url as string) as string
    parts = url.Split("/")
    if parts.Count() = 0 then return ""
    id = parts[parts.Count() - 1]
    if u_endsWith(LCase(id), ".mp4") or u_endsWith(LCase(id), ".mkv") then id = Left(id, Len(id) - 4)
    return id
end function

function m3u_fillList(text as string, series as boolean) as object
    list = m3u_newList()
    n = 0
    for each e in m3u_entries(text)
        n = n + 1
        extinf = e[0]
        url = e[1]
        if series then
            id = u_lastSegment(url)
            if id = "" then id = "sr_" + n.ToStr()
        else
            id = m3u_movieId(url)
            if id = "" then id = "mv_" + n.ToStr()
        end if
        if not list.index.DoesExist(id) then
            title = m3u_title(extinf)
            if title = "" then
                if series then title = "Série " + n.ToStr() else title = "Filme " + n.ToStr()
            end if
            list.index[id] = list.ids.Count()
            list.ids.Push(id)
            list.titles.Push(title)
            list.posters.Push(m3u_attr(extinf, "tvg-logo"))
            list.urls.Push(url)
            list.descs.Push(m3u_attr(extinf, "description"))
            list.folded.Push(u_fold(title))
        end if
    end for
    return list
end function

function m3u_listItem(list as object, i as integer, series as boolean, categoryId as string, categoryName as string) as object
    item = { id: list.ids[i], title: list.titles[i], poster: list.posters[i], description: list.descs[i], categoryId: categoryId, categoryName: categoryName }
    if series then item.episodesUrl = list.urls[i] else item.streamUrl = list.urls[i]
    return item
end function

function m3u_episodes(text as string) as object
    list = []
    n = 0
    seen = {}
    for each e in m3u_entries(text)
        n = n + 1
        extinf = e[0]
        url = e[1]
        trimmed = url
        while Len(trimmed) > 0 and Right(trimmed, 1) = "."
            trimmed = Left(trimmed, Len(trimmed) - 1)
        end while
        parts = trimmed.Split("/")
        id = ""
        if parts.Count() > 0 then id = parts[parts.Count() - 1]
        if id = "" then id = "ep_" + n.ToStr()
        if not seen.DoesExist(id) then
            seen[id] = true
            title = m3u_title(extinf)
            if title = "" then title = "Episódio " + n.ToStr()
            season = m3u_attr(extinf, "group-title")
            if season = "" then season = season_unnamed()
            code = m3u_attr(extinf, "description")
            if code = "" then code = "T1E" + n.ToStr()
            list.Push({ id: id, title: title, season: season, episodeCode: code, streamUrl: url })
        end if
    end for
    return list
end function

function season_unnamed() as string
    return "1º Temporada"
end function

function season_display(season as string) as string
    if season = season_unnamed() then return "1ª Temporada"
    return season
end function

function season_displaySubtitle(text as dynamic) as string
    s = u_str(text)
    if u_startsWith(s, season_unnamed()) then return "1ª Temporada" + Mid(s, Len(season_unnamed()) + 1)
    return s
end function

function category_movieName(name as string) as string
    re = CreateObject("roRegex", "^\s*filmes\s*\|\s*", "i")
    out = re.Replace(name, "").Trim()
    if out = "" then return name
    return out
end function

function category_seriesName(name as string) as string
    re = CreateObject("roRegex", "^\s*s[ée]ries\s*\|\s*", "i")
    out = re.Replace(name, "").Trim()
    if out = "" then return name
    return out
end function

' Year is part of a movie identity: a title alone never confirms a match.
function identity_normalize(value as dynamic) as string
    s = u_str(value)
    if m.idRules = invalid then
        m.idRules = {
            ordinal: CreateObject("roRegex", "(\d)[ºª°]", ""),
            apostrophe: CreateObject("roRegex", "([a-z])['’]([a-z])", ""),
            other: CreateObject("roRegex", "[^a-z0-9]+", ""),
            enclosedYear: CreateObject("roRegex", "[\[(](?:19|20)\d{2}[\])]", ""),
            deliveryTag: CreateObject("roRegex", "[\[(](?:dublado|legendado|l|dual\s*[aá]udio|1080p|720p|2160p|4k)[\])]", "i"),
            trailingYear: CreateObject("roRegex", "\s[-–]\s(?:19|20)\d{2}\s*$", ""),
            quality: CreateObject("roRegex", "\b(?:1080p|720p|2160p|4k|full\s*hd|uhd|dublado|legendado|dual\s*[aá]udio)\b", "i"),
            year: CreateObject("roRegex", "(?:\(|\[|\s[-–]\s)((?:19|20)\d{2})(?:\)|\]|\s*$)", ""),
        }
    end if
    s = m.idRules.ordinal.ReplaceAll(s, "\1")
    s = u_fold(s)
    s = m.idRules.apostrophe.ReplaceAll(s, "\1\2")
    s = m.idRules.other.ReplaceAll(s, " ")
    return s.Trim()
end function

function identity_searchTitle(value as dynamic) as string
    s = u_str(value)
    identity_normalize("")
    r = m.idRules
    s = r.enclosedYear.ReplaceAll(s, " ")
    s = r.deliveryTag.ReplaceAll(s, " ")
    s = r.trailingYear.ReplaceAll(s, "")
    s = r.quality.ReplaceAll(s, " ")
    return s.Trim()
end function

' {title, year}; year is 0 when the title has none.
function identity_parse(value as dynamic) as object
    s = u_str(value)
    identity_normalize("")
    year = 0
    rest = s
    found = m.idRules.year.Match(rest)
    while found.Count() > 1
        year = found[1].ToInt()
        cut = Instr(1, rest, found[0])
        rest = Mid(rest, cut + Len(found[0]))
        found = m.idRules.year.Match(rest)
    end while
    return { title: identity_normalize(identity_searchTitle(s)), year: year }
end function
