' Playback descriptions for movies and episodes, and the "continue or start over" choice.

function vod_moviePlayback(movie as object, restart as boolean) as object
    if restart then pr_savePosition(movie.id, 0, "MOVIE")
    startMs = 0
    if not restart then startMs = pr_savedPosition(movie.id, "MOVIE")
    return {
        url: movie.streamUrl, title: movie.title, subtitle: u_str(movie.categoryName), live: false,
        startMs: startMs, posterUrl: u_str(movie.poster), mediaId: movie.id, mediaType: "MOVIE"
    }
end function

function vod_episodePlayback(series as object, episode as object, episodes as object) as object
    index = -1
    for i = 0 to episodes.Count() - 1
        if episodes[i].id = episode.id then index = i
    end for
    return {
        url: episode.streamUrl, title: series.title + " - " + episode.title,
        subtitle: season_display(episode.season) + " (" + episode.episodeCode + ")", live: false,
        startMs: pr_savedPosition(episode.id, "EPISODE"), episodes: episodes, episodeIndex: index,
        posterUrl: u_str(series.poster), mediaId: episode.id, mediaType: "EPISODE", seriesId: series.id, seriesTitle: series.title,
        seriesEpisodesUrl: u_str(series.episodesUrl), season: episode.season, episodeCode: episode.episodeCode
    }
end function

sub vod_play(info as object, replace = false as boolean)
    ui_nav("open", { screen: "PlayerScreen", live: false, info: info, replace: replace })
end sub

sub vod_playWithResumeChoice(info as object, replace = false as boolean)
    if u_num(info.startMs) <= 0 then
        vod_play(info, replace)
        return
    end if
    m.vod_pending = { info: info, replace: replace }
    options = [{ label: "Cancelar" }, { label: "Assistir do início" }, { label: "Continuar (" + u_positionLabel(info.startMs) + ")", primary: true }]
    ui_choose(info.title, "", options, vod_onResumeChoice)
end sub

sub vod_onResumeChoice(index as integer)
    pending = m.vod_pending
    m.vod_pending = invalid
    if pending = invalid or index <= 0 then return
    info = pending.info
    if index = 1 then
        pr_savePosition(info.mediaId, 0, info.mediaType)
        info.startMs = 0
    end if
    vod_play(info, pending.replace)
end sub
