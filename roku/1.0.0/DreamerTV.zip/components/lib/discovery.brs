' Synopses (TMDB) and the "Dreamer indica" selection. Used only by task threads.

function dc_feedUrl() as string
    return "https://dreamerjp.github.io/Dreamer/Assets/Filmes/minha_lista_filmes.json"
end function

function dc_tmdb(path as string, params as object, language = "pt-BR" as string) as dynamic
    key = cfg_tmdbKey()
    if key = "" then return invalid
    url = "https://api.themoviedb.org/3/" + path + "?api_key=" + u_escape(key)
    if language <> "" then url = url + "&language=" + language
    if params <> invalid then
        for each k in params
            url = url + "&" + k + "=" + u_escape(u_str(params[k]))
        end for
    end if
    result = u_httpJson(url, 18000)
    ' Lets the recommendation check tell "not found" from "could not ask".
    if result = invalid then m.dc_failed = true
    return result
end function

function dc_image(path as dynamic, size as string) as string
    p = u_str(path)
    if Left(p, 1) = "/" then return "https://image.tmdb.org/t/p/" + size + p
    return ""
end function

function dc_cleanTitle(title as string) as string
    re1 = CreateObject("roRegex", "\s*[\[(](?:19|20)\d{2}[\])]", "")
    re2 = CreateObject("roRegex", "\b(?:1080p|720p|2160p|4k|dublado|legendado)\b", "i")
    return re2.ReplaceAll(re1.ReplaceAll(title, ""), "").Trim()
end function

function dc_artworkKey(url as dynamic) as string
    re = CreateObject("roRegex", "^https?://(?:image\.tmdb\.org|www\.themoviedb\.org)/t/p/[^/]+/([A-Za-z0-9]+\.(?:jpg|png|webp))$", "i")
    found = re.Match(u_str(url))
    if found.Count() > 1 then return found[1]
    return ""
end function

' Year of a TMDB date, or 0 when it has none.
function dc_year(value as dynamic) as integer
    s = Left(u_str(value), 4)
    if Len(s) = 4 and s.ToInt() > 0 then return s.ToInt()
    return 0
end function

function dc_parseFeed(raw as string) as object
    data = u_jsonParse(raw)
    films = []
    if not u_isAA(data) or not u_isArray(data.films) then return films
    seen = {}
    slugRe = CreateObject("roRegex", "^https?://letterboxd\.com/film/([^?#]+?)/*$", "i")
    for each item in data.films
        title = u_trim(item.title)
        year = u_int(item.year)
        if title <> "" and year >= 1880 and year <= 2100 then
            key = identity_normalize(title) + "|" + year.ToStr()
            if not seen.DoesExist(key) then
                seen[key] = true
                originalSlug = ""
                found = slugRe.Match(u_str(item.url))
                if found.Count() > 1 then originalSlug = found[1]
                slug = u_str(item.slug)
                if slug = "" then slug = title + "-" + year.ToStr()
                films.Push({
                    slug: slug, title: title, year: year, originalTitle: u_str(item.original_title), director: u_str(item.director),
                    releaseDate: u_str(item.released), originalSlug: originalSlug,
                    details: { title: title, year: year, overview: u_str(item.plot), poster: u_str(item.poster), backdrop: u_str(item.backdrop), genres: u_str(item.genre), runtime: u_str(item.runtime), fromTmdb: false }
                })
            end if
        end if
    end for
    return films
end function

' {films, stale}; films is invalid when nothing could be loaded.
function dc_loadFeed(maxAgeMs = 900000 as double) as object
    path = "cachefs:/feed.json"
    saved = u_readJson(path)
    if u_isAA(saved) and u_isArray(saved.films) and u_now() - u_num(saved.time) < maxAgeMs then return { films: saved.films, stale: false }
    r = u_httpGet(dc_feedUrl(), 18000)
    if r.status = 200 then
        films = dc_parseFeed(r.text)
        u_writeJson(path, { films: films, time: u_now() })
        return { films: films, stale: false }
    end if
    if u_isAA(saved) and u_isArray(saved.films) then return { films: saved.films, stale: true }
    return { films: invalid, stale: true }
end function

function dc_websiteDetails(title as string) as dynamic
    id = identity_parse(title)
    if id.year = 0 then return invalid
    feed = dc_loadFeed()
    if feed.films = invalid then return invalid
    found = []
    for each f in feed.films
        if f.year = id.year then
            if identity_parse(f.title).title = id.title or (f.originalTitle <> "" and identity_parse(f.originalTitle).title = id.title) then found.Push(f)
        end if
    end for
    if found.Count() = 1 then return found[0].details
    return invalid
end function

' TMDB details of a catalog title, chosen only when title, year and (when known) poster agree.
function dc_details(title as string, isSeries as boolean, poster as string) as dynamic
    id = identity_parse(title)
    yearText = "?"
    if id.year > 0 then yearText = id.year.ToStr()
    cacheKey = u_str(isSeries) + "|" + id.title + "|" + yearText + "|" + dc_artworkKey(poster)
    cachePath = "cachefs:/details.json"
    cache = u_readJson(cachePath)
    if not u_isAA(cache) then cache = {}
    cached = cache[cacheKey]
    if u_isAA(cached) and u_now() - u_num(cached.time) < 7 * 86400000# then return cached.value
    if cfg_tmdbKey() = "" then return invalid
    kind = "movie"
    nameKey = "title"
    originalKey = "original_title"
    dateKey = "release_date"
    if isSeries then
        kind = "tv"
        nameKey = "name"
        originalKey = "original_name"
        dateKey = "first_air_date"
    end if
    params = { query: dc_cleanTitle(title) }
    if id.year > 0 then
        if isSeries then params.first_air_date_year = id.year else params.year = id.year
    end if
    search = dc_tmdb("search/" + kind, params)
    if not u_isAA(search) then
        if u_isAA(cached) then return cached.value
        return invalid
    end if
    candidates = []
    seen = {}
    for each item in search.results
        year = dc_year(item[dateKey])
        sameYear = id.year = 0 or year = id.year
        if sameYear and not seen.DoesExist(u_str(item.id)) then
            if identity_parse(item[nameKey]).title = id.title or identity_parse(item[originalKey]).title = id.title then
                seen[u_str(item.id)] = true
                candidates.Push(item)
            end if
        end if
    end for
    selected = dc_selectCandidate(candidates, kind, dc_artworkKey(poster))
    if selected = invalid then return invalid
    item = dc_tmdb(kind + "/" + u_str(selected.id), {})
    if not u_isAA(item) then return invalid
    genres = []
    if u_isArray(item.genres) then
        for each g in item.genres
            genres.Push(u_str(g.name))
        end for
    end if
    runtime = ""
    if u_int(item.runtime) > 0 then runtime = u_int(item.runtime).ToStr() + " min"
    result = {
        title: u_str(item[nameKey]), year: dc_year(item[dateKey]), overview: u_str(item.overview),
        poster: dc_image(item.poster_path, "w500"), backdrop: dc_image(item.backdrop_path, "w1280"),
        genres: genres.Join(" · "), runtime: runtime, fromTmdb: true
    }
    if result.title = "" then result.title = dc_cleanTitle(title)
    cache[cacheKey] = { time: u_now(), value: result }
    keys = cache.Keys()
    while keys.Count() > 100
        cache.Delete(keys.Shift())
    end while
    u_writeJson(cachePath, cache)
    return result
end function

function dc_selectCandidate(candidates as object, kind as string, artwork as string) as dynamic
    if artwork = "" then
        if candidates.Count() = 1 then return candidates[0]
        return invalid
    end if
    found = []
    for each c in candidates
        images = dc_tmdb(kind + "/" + u_str(c.id) + "/images", {}, "")
        if u_isAA(images) and u_isArray(images.posters) then
            for each p in images.posters
                if u_lastSegment(u_str(p.file_path)) = artwork then
                    found.Push(c)
                    exit for
                end if
            end for
        end if
    end for
    if found.Count() = 1 then return found[0]
    return invalid
end function

' TMDB edition of a recommended film: its official and alternative titles for the same year.
function dc_edition(film as object) as dynamic
    if cfg_tmdbKey() = "" then return invalid
    queries = []
    for each q in [film.title, film.originalTitle, film.slug.Replace("-" + film.year.ToStr(), "").Replace("-", " "), film.originalSlug.Replace("-" + film.year.ToStr(), "").Replace("-", " ")]
        if u_str(q) <> "" then queries.Push(q)
    end for
    names = {}
    for each q in queries
        names[identity_parse(q).title] = true
    end for
    for each q in queries
        chosen = invalid
        for each language in ["pt-BR", "en-US"]
            if chosen = invalid then
                search = dc_tmdb("search/movie", { query: q, year: film.year }, language)
                if u_isAA(search) and u_isArray(search.results) then chosen = dc_pickEdition(search.results, film, names)
            end if
        end for
        if chosen <> invalid then
            d = dc_tmdb("movie/" + u_str(chosen.id), { append_to_response: "alternative_titles,credits" })
            if u_isAA(d) and dc_year(d.release_date) = film.year and dc_directedBy(d, film.director) then
                titles = [film.title, film.originalTitle, u_str(d.title), u_str(d.original_title)]
                if u_isAA(d.alternative_titles) and u_isArray(d.alternative_titles.titles) then
                    for each a in d.alternative_titles.titles
                        if u_indexOf(["BR", "PT", "US", "GB"], u_str(a.iso_3166_1)) >= 0 then titles.Push(u_str(a.title))
                    end for
                end if
                out = []
                for each t in titles
                    if t <> "" then out.Push(t)
                end for
                return { id: d.id, titles: out }
            end if
        end if
    end for
    return invalid
end function

function dc_pickEdition(results as object, film as object, names as object) as dynamic
    exact = []
    seen = {}
    for each r in results
        if dc_year(r.release_date) = film.year and not seen.DoesExist(u_str(r.id)) then
            if names.DoesExist(identity_parse(r.title).title) or names.DoesExist(identity_parse(r.original_title).title) then
                seen[u_str(r.id)] = true
                exact.Push(r)
            end if
        end if
    end for
    if exact.Count() = 1 then return exact[0]
    dated = []
    dateRe = CreateObject("roRegex", "^\d{4}-\d{2}-\d{2}$", "")
    if dateRe.IsMatch(film.releaseDate) then
        for each r in exact
            if u_str(r.release_date) = film.releaseDate then dated.Push(r)
        end for
    end if
    if dated.Count() = 1 then return dated[0]
    return invalid
end function

function dc_directedBy(d as object, director as string) as boolean
    if director = "" or director = "N/A" then return true
    if not u_isAA(d.credits) or not u_isArray(d.credits.crew) then return true
    wanted = identity_normalize(director)
    for each c in d.credits.crew
        if u_str(c.job) = "Director" then
            if identity_normalize(c.name) = wanted or identity_normalize(c.original_name) = wanted then return true
        end if
    end for
    return false
end function
