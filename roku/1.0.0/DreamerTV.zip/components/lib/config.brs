' Gerar-Pacote.bat fills the TMDB key when it builds the package; the source keeps no keys.

function cfg_tmdbKey() as string
    return "4e44d9029b1270a757cddc766a1bcb63"
end function

function cfg_defaultServer() as string
    return "http://painel.dytop.org"
end function

function cfg_updateUrl() as string
    return "https://raw.githubusercontent.com/DreamerJP/DreamerTV-Atualizacao/main/roku/versao.json"
end function

function cfg_version() as string
    info = CreateObject("roAppInfo")
    return info.GetVersion()
end function
