' Render-thread helpers: requests to the background tasks, messages, choices and list content.

' Sends {cmd, args} to a task and calls handler(response) when it answers.
sub rq_send(task as object, cmd as string, args as dynamic, handler as dynamic)
    if m.rq_pending = invalid then
        m.rq_pending = {}
        m.rq_seq = 0
        m.rq_observed = {}
        m.rq_prefix = CreateObject("roDeviceInfo").GetRandomUUID().Left(8)
    end if
    m.rq_seq = m.rq_seq + 1
    id = m.rq_prefix + "-" + m.rq_seq.ToStr()
    if handler <> invalid then m.rq_pending[id] = handler
    key = task.subtype() + task.id
    if not m.rq_observed.DoesExist(key) then
        m.rq_observed[key] = true
        task.observeFieldScoped("response", "rq_onResponse")
    end if
    if args = invalid then args = {}
    task.request = { id: id, cmd: cmd, args: args }
end sub

sub rq_onResponse(event as object)
    data = event.getData()
    if data = invalid or m.rq_pending = invalid then return
    handler = m.rq_pending[data.id]
    if handler = invalid then return
    if not u_true(data.partial) then m.rq_pending.Delete(data.id)
    handler(data)
end sub

sub rq_forget()
    if m.rq_pending <> invalid then m.rq_pending.Clear()
end sub

sub ui_toast(text as string, seconds = 2.6 as float)
    m.global.toast = { text: text, seconds: seconds }
end sub

' Opens a choice box; handler(index) receives -1 when the box is closed with VOLTAR.
' options: [{label, selected (optional), primary (optional)}]
sub ui_choose(title as string, message as string, options as object, handler as dynamic)
    if m.ui_dialog = invalid then
        m.ui_dialog = {}
        m.global.observeFieldScoped("dialogResult", "ui_onDialogResult")
    end if
    token = CreateObject("roDeviceInfo").GetRandomUUID()
    m.ui_dialog[token] = handler
    m.global.dialogRequest = { token: token, title: title, message: message, options: options }
end sub

sub ui_onDialogResult(event as object)
    result = event.getData()
    if result = invalid or m.ui_dialog = invalid then return
    handler = m.ui_dialog[result.token]
    if handler = invalid then return
    m.ui_dialog.Delete(result.token)
    handler(result.index)
end sub

sub ui_nav(action as string, params = invalid as dynamic)
    if params = invalid then params = {}
    params.action = action
    m.global.nav = params
end sub

function ui_font(size as integer, bold = false as boolean) as object
    font = CreateObject("roSGNode", "Font")
    if bold then font.uri = "font:BoldSystemFontFile" else font.uri = "font:SystemFontFile"
    font.size = size
    return font
end function

' Rows for TextItem lists: [{title, right, badge, small, selected}].
function ui_textContent(rows as object) as object
    root = CreateObject("roSGNode", "ContentNode")
    for each r in rows
        child = root.createChild("ContentNode")
        child.update({ title: u_str(r.title), right: u_str(r.right), badge: u_str(r.badge), small: u_str(r.small), selected: u_true(r.selected) }, true)
    end for
    return root
end function

function ui_channelNode(parent as object, c as object, selectedId as string) as object
    child = parent.createChild("ContentNode")
    child.update({ title: u_str(c.name), number: u_int(c.number), logo: u_str(c.logo), fav: u_true(c.isFavorite), selected: c.id = selectedId }, true)
    return child
end function

function ui_channelContent(channels as object, selectedId as string, first = 0 as integer, count = -1 as integer) as object
    root = CreateObject("roSGNode", "ContentNode")
    ui_appendChannels(root, channels, selectedId, first, count)
    return root
end function

sub ui_appendChannels(root as object, channels as object, selectedId as string, first as integer, count as integer)
    last = channels.Count() - 1
    if count >= 0 and first + count - 1 < last then last = first + count - 1
    for i = first to last
        ui_channelNode(root, channels[i], selectedId)
    end for
end sub

' Poster cards: [{title, poster, sub, subMuted, fav, progress, dim}].
sub ui_appendPosters(root as object, cards as object)
    for each c in cards
        child = root.createChild("ContentNode")
        progress = -1
        if c.progress <> invalid then progress = u_int(c.progress)
        child.update({ title: u_str(c.title), poster: u_str(c.poster), sub: u_str(c.sub), subMuted: u_true(c.subMuted), fav: u_true(c.fav), progress: progress, dim: u_true(c.dim) }, true)
    end for
end sub

' Rows for RowItem lists: [{title, kind: "channel" | "poster", items}] where items are channels or cards.
function ui_rowContent(rows as object) as object
    root = CreateObject("roSGNode", "ContentNode")
    for each r in rows
        row = root.createChild("ContentNode")
        row.title = r.title
        for each c in r.items
            child = row.createChild("ContentNode")
            if r.kind = "channel" then
                child.update({ kind: "channel", title: u_str(c.name), number: u_int(c.number), logo: u_str(c.logo), fav: u_true(c.isFavorite), selected: false }, true)
            else
                progress = -1
                if c.progress <> invalid then progress = u_int(c.progress)
                child.update({ kind: "poster", title: u_str(c.title), poster: u_str(c.poster), sub: u_str(c.sub), subMuted: u_true(c.subMuted), fav: u_true(c.fav), progress: progress, dim: u_true(c.dim) }, true)
            end if
        end for
    end for
    return root
end function

' Progress of a history entry in percent, or -1 when the duration is unknown.
function ui_progressOf(item as object) as integer
    duration = u_num(item.durationMs)
    if duration <= 0 then return -1
    pct = Int(u_num(item.positionMs) / duration * 100)
    if pct < 5 then pct = 5
    if pct > 100 then pct = 100
    return pct
end function

function ui_label(text as string, size as integer, color as string, bold = false as boolean) as object
    label = CreateObject("roSGNode", "Label")
    label.font = ui_font(size, bold)
    label.color = color
    label.text = text
    return label
end function

function ui_btn(text as string, width as float, height = 88 as float, kind = "normal" as string) as object
    b = CreateObject("roSGNode", "Btn")
    b.width = width
    b.height = height
    b.text = text
    b.kind = kind
    return b
end function

' Deepest node holding the key focus under root.
function ui_focusedLeaf(root as object) as dynamic
    node = root
    guard = 0
    while node <> invalid and guard < 50
        guard = guard + 1
        child = node.focusedChild
        if child = invalid or child.isSameNode(node) then return node
        node = child
    end while
    return node
end function
