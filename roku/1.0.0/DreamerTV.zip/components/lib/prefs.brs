' Account, settings, favorites, history and resume positions, kept in the Roku registry.
' The registry is small (32 KB per app): lists are capped and the oldest entries go first when it fills up.

function pr_section() as object
    if m.pr_reg = invalid then m.pr_reg = CreateObject("roRegistrySection", "dtv")
    return m.pr_reg
end function

function pr_get(key as string, fallback as dynamic) as dynamic
    s = pr_section()
    if not s.Exists(key) then return fallback
    value = ParseJson(s.Read(key))
    if value = invalid then return fallback
    return value
end function

sub pr_set(key as string, value as dynamic)
    s = pr_section()
    text = FormatJson(value)
    if not s.Write(key, text) then
        pr_makeRoom(Len(text) + 512)
        s.Write(key, text)
    end if
    s.Flush()
    pr_makeRoom(1536)
end sub

sub pr_remove(key as string)
    s = pr_section()
    if s.Exists(key) then
        s.Delete(key)
        s.Flush()
    end if
end sub

' Frees registry space by dropping the oldest positions, watched episodes and history.
sub pr_makeRoom(wanted as integer)
    reg = CreateObject("roRegistry")
    s = pr_section()
    guard = 0
    while reg.GetSpaceAvailable() < wanted and guard < 40
        guard = guard + 1
        positions = pr_get("positions", {})
        keys = positions.Keys()
        if keys.Count() > 20 then
            entries = []
            for each k in keys
                entries.Push({ k: k, t: u_num(positions[k][1]) })
            end for
            entries.SortBy("t")
            for i = 0 to 19
                positions.Delete(entries[i].k)
            end for
            s.Write("positions", FormatJson(positions))
        else
            watched = pr_get("watched", [])
            if watched.Count() > 50 then
                rest = []
                for i = 50 to watched.Count() - 1
                    rest.Push(watched[i])
                end for
                s.Write("watched", FormatJson(rest))
            else
                history = pr_get("history", [])
                if history.Count() > 5 then
                    history.Pop()
                    s.Write("history", FormatJson(history))
                else
                    exit while
                end if
            end if
        end if
        s.Flush()
    end while
end sub

' Account ---------------------------------------------------------------------------------

function pr_defaultServer() as string
    return cfg_defaultServer()
end function

function pr_credentials() as object
    c = pr_get("credentials", invalid)
    if c = invalid then c = { username: "", password: "", serverUrl: pr_defaultServer(), remember: true }
    if u_str(c.serverUrl) = "" then c.serverUrl = pr_defaultServer()
    if c.remember = invalid then c.remember = true
    return c
end function

function pr_isLoggedIn() as boolean
    c = pr_credentials()
    return u_str(c.username) <> "" and u_str(c.password) <> ""
end function

sub pr_setCredentials(user as string, pass as string, server as string, remember as boolean)
    known = pr_get("knownUsers", [])
    if u_indexOf(known, user) < 0 then
        known.Push(user)
        pr_set("knownUsers", known)
    end if
    pr_set("credentials", { username: user, password: pass, serverUrl: server, remember: remember })
end sub

' Keeps the session usable while the app runs; without "remember" only the server is saved.
sub pr_setRemember(remember as boolean)
    c = pr_credentials()
    c.remember = remember
    pr_set("credentials", c)
end sub

sub pr_clearAuth()
    c = pr_credentials()
    pr_set("credentials", { username: "", password: "", serverUrl: c.serverUrl, remember: c.remember })
end sub

' Session for address renewal and the provider lists.
function pr_session() as object
    c = pr_credentials()
    known = {}
    for each u in pr_get("knownUsers", [])
        known[u_str(u)] = true
    end for
    return { username: u_str(c.username), password: u_str(c.password), serverUrl: u_stripTrailingSlashes(u_str(c.serverUrl)), knownUsers: known }
end function

' Settings ---------------------------------------------------------------------------------

function pr_settings() as object
    s = { showClock: false, autoBoot: false, lastChannelId: "" }
    saved = pr_get("settings", {})
    for each k in saved
        s[k] = saved[k]
    end for
    return s
end function

sub pr_setSetting(key as string, value as dynamic)
    s = pr_settings()
    s[key] = value
    pr_set("settings", s)
end sub

' Address renewal ---------------------------------------------------------------------------

' Renews user and password inside catalog addresses; other hosts and token links stay intact.
function pr_refreshUrl(session as object, url as dynamic) as string
    address = u_str(url)
    if session = invalid or session.username = "" or session.password = "" or address = "" then return address
    p = u_parseUrl(address)
    if p = invalid or p.hasUserInfo or p.query <> "" then return address
    parts = []
    for each piece in p.path.Split("/")
        if piece <> "" then parts.Push(piece)
    end for
    slots = pr_credentialSlots(parts)
    if slots = invalid then return address
    originalUser = u_unescape(parts[slots[0]])
    if not session.knownUsers.DoesExist(originalUser) and originalUser <> session.username then return address
    if slots[0] = 2 and LCase(u_origin(address)) <> LCase(u_origin(session.serverUrl)) then return address
    parts[slots[0]] = u_escape(session.username)
    parts[slots[1]] = u_escape(session.password)
    trailing = ""
    if Right(p.path, 1) = "/" then trailing = "/"
    return p.scheme + "://" + p.authority + "/" + parts.Join("/") + trailing
end function

function pr_credentialSlots(parts as object) as dynamic
    routes = ["download_m3u", "list_lives", "list_created_channels", "movie_categories", "serie_categories", "list_movies", "list_series", "list_episodes"]
    contentId = CreateObject("roRegex", "^\d+(?:\.[A-Za-z0-9]*)?$", "")
    n = parts.Count()
    if n >= 5 and parts[0] = "ssiptv" and parts[1] = "get" and u_indexOf(routes, parts[4]) >= 0 then return [2, 3]
    if n = 4 and (parts[0] = "movie" or parts[0] = "series") and contentId.IsMatch(parts[3]) then return [1, 2]
    if n = 3 and contentId.IsMatch(parts[2]) then return [0, 1]
    return invalid
end function

' Favorites ----------------------------------------------------------------------------------

function pr_favorites() as object
    f = pr_get("favorites", {})
    for each t in ["CHANNEL", "MOVIE", "SERIES"]
        if not u_isArray(f[t]) then f[t] = []
    end for
    return f
end function

function pr_favoriteIds(kind as string) as object
    return pr_favorites()[kind]
end function

function pr_isFavorite(id as string, kind as string) as boolean
    return u_indexOf(pr_favoriteIds(kind), id) >= 0
end function

function pr_toggleFavorite(id as string, kind as string) as boolean
    f = pr_favorites()
    list = f[kind]
    at = u_indexOf(list, id)
    if at >= 0 then
        list.Delete(at)
    else
        list.Unshift(id)
    end if
    f[kind] = list
    pr_set("favorites", f)
    return at < 0
end function

function pr_storedMovie(movie as object) as object
    return { id: u_str(movie.id), title: u_str(movie.title), poster: u_str(movie.poster), categoryId: u_str(movie.categoryId), categoryName: u_str(movie.categoryName), streamUrl: u_str(movie.streamUrl), description: "" }
end function

function pr_storedSeries(series as object) as object
    return { id: u_str(series.id), title: u_str(series.title), poster: u_str(series.poster), categoryId: u_str(series.categoryId), categoryName: u_str(series.categoryName), episodesUrl: u_str(series.episodesUrl), description: "" }
end function

function pr_toggleFavoriteMovie(movie as object) as boolean
    added = pr_toggleFavorite(u_str(movie.id), "MOVIE")
    list = []
    if added then list.Push(pr_storedMovie(movie))
    for each item in pr_get("favMovies", [])
        if item.id <> movie.id then list.Push(item)
    end for
    pr_set("favMovies", list)
    return added
end function

function pr_toggleFavoriteSeries(series as object) as boolean
    added = pr_toggleFavorite(u_str(series.id), "SERIES")
    list = []
    if added then list.Push(pr_storedSeries(series))
    for each item in pr_get("favSeries", [])
        if item.id <> series.id then list.Push(item)
    end for
    pr_set("favSeries", list)
    return added
end function

function pr_favoriteMovies() as object
    session = pr_session()
    ids = pr_favoriteIds("MOVIE")
    out = []
    for each item in pr_get("favMovies", [])
        if u_indexOf(ids, item.id) >= 0 then
            copy = u_copyAA(item)
            copy.isFavorite = true
            copy.streamUrl = pr_refreshUrl(session, item.streamUrl)
            out.Push(copy)
        end if
    end for
    return out
end function

function pr_favoriteSeries() as object
    session = pr_session()
    ids = pr_favoriteIds("SERIES")
    out = []
    for each item in pr_get("favSeries", [])
        if u_indexOf(ids, item.id) >= 0 then
            copy = u_copyAA(item)
            copy.isFavorite = true
            copy.episodesUrl = pr_refreshUrl(session, item.episodesUrl)
            out.Push(copy)
        end if
    end for
    return out
end function

' Positions and history ------------------------------------------------------------------------

function pr_savedPosition(id as dynamic, kind as dynamic) as double
    positions = pr_get("positions", {})
    entry = positions[u_str(kind) + "|" + u_str(id)]
    if entry = invalid then return 0
    if u_isArray(entry) then return u_num(entry[0])
    return u_num(entry)
end function

sub pr_savePosition(id as dynamic, ms as double, kind as dynamic)
    if u_str(id) = "" then return
    positions = pr_get("positions", {})
    key = u_str(kind) + "|" + u_str(id)
    if ms > 0 then
        positions[key] = [Int(ms), Int(u_now() / 1000)]
    else
        positions.Delete(key)
    end if
    pr_set("positions", positions)
end sub

function pr_storedHistory(item as object) as object
    keys = ["id", "title", "subtitle", "poster", "streamUrl", "positionMs", "durationMs", "mediaType", "seriesId", "seriesTitle", "seriesEpisodesUrl", "season", "episodeCode"]
    out = {}
    for each k in keys
        if item[k] <> invalid then out[k] = item[k]
    end for
    out.timestamp = u_now()
    return out
end function

sub pr_savePlaybackProgress(item as object, completed as boolean, watchedEpisode as boolean)
    if u_str(item.id) = "" then return
    kind = u_str(item.mediaType)
    position = 0
    if not completed then position = u_num(item.positionMs)
    pr_savePosition(item.id, position, kind)
    rest = []
    for each h in pr_get("history", [])
        if not (h.id = item.id and h.mediaType = kind) then rest.Push(h)
    end for
    history = []
    if not completed then history.Push(pr_storedHistory(item))
    for each h in rest
        if history.Count() < 20 then history.Push(h)
    end for
    pr_set("history", history)
    if kind = "EPISODE" and watchedEpisode then
        watched = pr_get("watched", [])
        if u_indexOf(watched, item.id) < 0 then
            watched.Push(item.id)
            while watched.Count() > 400
                watched.Shift()
            end while
            pr_set("watched", watched)
        end if
    end if
end sub

function pr_history() as object
    session = pr_session()
    out = []
    for each h in pr_get("history", [])
        copy = u_copyAA(h)
        copy.streamUrl = pr_refreshUrl(session, h.streamUrl)
        if u_str(h.seriesEpisodesUrl) <> "" then copy.seriesEpisodesUrl = pr_refreshUrl(session, h.seriesEpisodesUrl)
        saved = pr_savedPosition(h.id, h.mediaType)
        if saved > 0 then copy.positionMs = saved
        out.Push(copy)
    end for
    return out
end function

sub pr_removeHistory(id as string, kind as string)
    list = []
    for each h in pr_get("history", [])
        if not (h.id = id and (kind = "" or h.mediaType = kind)) then list.Push(h)
    end for
    pr_set("history", list)
end sub

function pr_isSeriesItem(h as object) as boolean
    return h.mediaType = "EPISODE" or h.mediaType = "SERIES"
end function

function pr_seriesKey(h as object) as string
    if u_str(h.seriesId) <> "" then return "series:" + u_str(h.seriesId)
    if u_str(h.seriesEpisodesUrl) <> "" then return "url:" + u_str(h.seriesEpisodesUrl)
    if u_str(h.seriesTitle) <> "" then return "title:" + u_str(h.seriesTitle)
    return "episode:" + u_str(h.id)
end function

sub pr_removeSeriesHistory(item as object)
    key = pr_seriesKey(item)
    list = []
    for each h in pr_get("history", [])
        if not (pr_isSeriesItem(h) and pr_seriesKey(h) = key) then list.Push(h)
    end for
    pr_set("history", list)
end sub

function pr_sortedByTime(list as object) as object
    list.SortBy("timestamp", "r")
    return list
end function

function pr_movieHistory() as object
    out = []
    for each h in pr_history()
        if h.mediaType = "MOVIE" then out.Push(h)
    end for
    return pr_sortedByTime(out)
end function

function pr_seriesHistory() as object
    seen = {}
    out = []
    all = []
    for each h in pr_history()
        if pr_isSeriesItem(h) then all.Push(h)
    end for
    for each h in pr_sortedByTime(all)
        key = pr_seriesKey(h)
        if not seen.DoesExist(key) then
            seen[key] = true
            out.Push(h)
        end if
    end for
    return out
end function

function pr_watchedEpisodes() as object
    return pr_get("watched", [])
end function

function pr_lastSeason(seriesId as string) as string
    return u_str(pr_get("seasons", {})[seriesId])
end function

sub pr_saveLastSeason(seriesId as string, season as string)
    if seriesId = "" then return
    seasons = pr_get("seasons", {})
    if u_str(seasons[seriesId]) = season then return
    seasons[seriesId] = season
    keys = seasons.Keys()
    if keys.Count() > 100 then seasons.Delete(keys[0])
    pr_set("seasons", seasons)
end sub

' Movies renumbered by the provider: points saved items at their new numbers.
sub pr_relinkMovies(replacements as object)
    if replacements = invalid or replacements.Count() = 0 then return
    positions = pr_get("positions", {})
    for each old in replacements
        movie = replacements[old]
        oldKey = "MOVIE|" + old
        newKey = "MOVIE|" + movie.id
        if positions.DoesExist(oldKey) and not positions.DoesExist(newKey) then positions[newKey] = positions[oldKey]
        positions.Delete(oldKey)
    end for
    pr_set("positions", positions)
    history = []
    for each h in pr_get("history", [])
        if h.mediaType = "MOVIE" and replacements.DoesExist(h.id) then
            m2 = replacements[h.id]
            h.id = m2.id
            h.streamUrl = m2.streamUrl
            h.poster = m2.poster
        end if
        history.Push(h)
    end for
    pr_set("history", history)
    favMovies = []
    for each item in pr_get("favMovies", [])
        if replacements.DoesExist(item.id) then
            favMovies.Push(pr_storedMovie(replacements[item.id]))
        else
            favMovies.Push(item)
        end if
    end for
    pr_set("favMovies", favMovies)
    f = pr_favorites()
    ids = []
    ' Brackets keep the key exactly as saved: a dotted name may be stored in lower case.
    for each id in f["MOVIE"]
        if replacements.DoesExist(id) then ids.Push(replacements[id].id) else ids.Push(id)
    end for
    f["MOVIE"] = ids
    pr_set("favorites", f)
end sub
