' Movie or series page, also opened from "Continuar assistindo", favorites, search and "Dreamer indica".

sub init()
    m.parts = {}
    for each id in ["backdrop", "poster", "eyebrow", "title", "facts", "synopsis", "status", "close", "watch", "favorite", "restart"]
        m.parts[id] = m.top.findNode(id)
    end for
    for each id in ["close", "watch", "favorite", "restart"]
        m.parts[id].name = id
        m.parts[id].observeField("pressed", "onPressed")
    end for
    m.state = invalid
end sub

function showScreen(params as object) as boolean
    s = {
        movie: params.movie, series: params.series, history: params.history, recommendation: params.recommendation,
        sources: [], candidates: [], unconfirmed: false, catalogReady: not u_false(params.catalogReady), loading: true
    }
    if m.seq = invalid then m.seq = 0
    m.seq = m.seq + 1
    s.seq = m.seq
    m.state = s
    title = ""
    if s.recommendation <> invalid then
        title = s.recommendation.film.title
    else if s.movie <> invalid then
        title = s.movie.title
    else if s.series <> invalid then
        title = s.series.title
    else if s.history <> invalid then
        title = u_str(s.history.seriesTitle)
        if title = "" then title = s.history.title.Split(" - ")[0]
    end if
    if s.recommendation <> invalid then
        s.details = u_copyAA(s.recommendation.film.details)
        s.sources = s.recommendation.sources
        s.candidates = s.recommendation.candidates
        s.movie = invalid
        if s.sources.Count() > 0 then s.movie = s.sources[0]
        s.unconfirmed = s.recommendation.availability = "UNCONFIRMED" or s.recommendation.availability = "CHECKING"
    else
        overview = ""
        poster = ""
        genres = ""
        if s.movie <> invalid then
            overview = u_str(s.movie.description)
            poster = u_str(s.movie.poster)
            genres = u_str(s.movie.categoryName)
        else if s.series <> invalid then
            overview = u_str(s.series.description)
            poster = u_str(s.series.poster)
            genres = u_str(s.series.categoryName)
        else if s.history <> invalid then
            poster = u_str(s.history.poster)
        end if
        s.details = { title: title, year: identity_parse(title).year, overview: overview, poster: poster, genres: genres, runtime: "" }
    end if
    render()
    if m.parts.watch.disabled then m.parts.close.setFocus(true) else m.parts.watch.setFocus(true)
    if s.recommendation <> invalid then
        s.loading = false
        render()
    else if s.history <> invalid then
        rq_send(m.global.library, "enrich", { items: [s.history] }, onHistoryEnriched)
    else
        loadDetails()
    end if
    return true
end function

function leaveScreen(params as object) as boolean
    m.state = invalid
    return true
end function

function coverScreen(params as object) as boolean
    return true
end function

function returnToScreen(params as object) as boolean
    s = m.state
    if s = invalid then return true
    if s.history <> invalid and isSeries() then
        key = pr_seriesKey(s.history)
        for each h in pr_history()
            if pr_isSeriesItem(h) and pr_seriesKey(h) = key then
                s.history = h
                exit for
            end if
        end for
    end if
    updateActions()
    if m.parts.watch.disabled then m.parts.close.setFocus(true) else m.parts.watch.setFocus(true)
    return true
end function

function isSeries() as boolean
    s = m.state
    return s.series <> invalid or (s.history <> invalid and s.history.mediaType <> "MOVIE")
end function

' History entries: the movie or series is looked up in the full list, keeping the saved data otherwise.
sub onHistoryEnriched(response as object)
    s = m.state
    if s = invalid then return
    if response.ok and response.data.Count() > 0 then s.history = response.data[0]
    h = s.history
    if h.mediaType = "MOVIE" then
        rq_send(m.global.library, "find", { kind: "movie", id: h.id }, onHistoryFound)
    else if u_str(h.seriesId) <> "" then
        rq_send(m.global.library, "find", { kind: "series", id: h.seriesId }, onHistoryFound)
    else
        loadDetails()
    end if
end sub

sub onHistoryFound(response as object)
    s = m.state
    if s = invalid then return
    h = s.history
    found = invalid
    if response.ok then found = response.data
    if h.mediaType = "MOVIE" then
        if found = invalid then found = { id: h.id, title: h.title, poster: u_str(h.poster), categoryName: u_str(h.subtitle), description: "", streamUrl: h.streamUrl }
        s.movie = found
    else
        if found = invalid then
            title = u_str(h.seriesTitle)
            if title = "" then title = h.title.Split(" - ")[0]
            found = { id: h.seriesId, title: title, poster: u_str(h.poster), categoryName: "", description: "", episodesUrl: u_str(h.seriesEpisodesUrl) }
        end if
        s.series = found
    end if
    loadDetails()
end sub

sub loadDetails()
    s = m.state
    title = s.details.title
    poster = s.details.poster
    if s.movie <> invalid then
        title = s.movie.title
        if u_str(s.movie.poster) <> "" then poster = s.movie.poster
    else if s.series <> invalid then
        title = s.series.title
        if u_str(s.series.poster) <> "" then poster = s.series.poster
    end if
    m.detailsToken = s.seq
    rq_send(m.global.net, "details", { title: title, isSeries: isSeries(), poster: poster }, onDetails)
end sub

sub onDetails(response as object)
    s = m.state
    if s = invalid or s.seq <> m.detailsToken then return
    if response.ok and response.data <> invalid then
        fetched = response.data
        prev = s.details
        merged = u_copyAA(fetched)
        if u_str(fetched.overview) = "" then merged.overview = prev.overview
        if u_str(fetched.poster) = "" then merged.poster = prev.poster
        if u_str(fetched.genres) = "" then merged.genres = prev.genres
        s.details = merged
    end if
    s.loading = false
    if s.movie <> invalid then
        if u_str(s.movie.poster) = "" then s.movie.poster = s.details.poster
        if u_str(s.movie.description) = "" then s.movie.description = s.details.overview
    end if
    render()
end sub

sub render()
    s = m.state
    d = s.details
    if s.recommendation <> invalid then
        m.parts.eyebrow.text = "SELEÇÃO DREAMER"
    else if isSeries() then
        m.parts.eyebrow.text = "SÉRIE"
    else
        m.parts.eyebrow.text = "FILME"
    end if
    m.parts.title.text = u_str(d.title)
    facts = []
    if u_int(d.year) > 0 then facts.Push(u_int(d.year).ToStr())
    if u_str(d.runtime) <> "" then facts.Push(d.runtime)
    if u_str(d.genres) <> "" then facts.Push(d.genres)
    m.parts.facts.text = facts.Join("  ·  ")
    overview = u_str(d.overview)
    if overview = "" then overview = "Sinopse em português não disponível para este título."
    m.parts.synopsis.text = overview
    m.parts.poster.uri = u_str(d.poster)
    m.parts.backdrop.uri = u_str(d.backdrop)
    text = ""
    if s.loading then
        text = "Buscando sinopse…"
    else if s.recommendation <> invalid and not s.catalogReady then
        text = "Não foi possível conferir a disponibilidade. Atualize a lista e tente novamente."
    else if s.recommendation <> invalid and s.unconfirmed then
        if s.candidates.Count() > 0 then
            text = "Há itens com título compatível no servidor, mas faltam dados para confirmar a edição. Você pode conferir as opções no catálogo."
        else
            text = "Não foi possível confirmar a edição deste filme no servidor. A reprodução fica indisponível para evitar abrir outro filme com o mesmo nome."
        end if
    else if s.recommendation <> invalid and s.movie = invalid then
        text = "Não disponível no catálogo com título e ano confirmados."
    else if u_true(d.fromTmdb) then
        text = "Informações: TMDB"
    else if s.recommendation <> invalid then
        text = "Informações: seleção Dreamer"
    end if
    m.parts.status.text = text
    updateActions()
end sub

sub updateActions()
    s = m.state
    position = 0
    if s.movie <> invalid then position = pr_savedPosition(s.movie.id, "MOVIE")
    label = "Assistir Agora"
    if s.unconfirmed and s.candidates.Count() > 0 and s.movie = invalid then
        label = "Ver opções no catálogo"
    else if s.series <> invalid then
        label = "Temporadas e episódios"
    end if
    if s.history <> invalid and isSeries() then
        label = "Continuar episódio"
    else if position > 0 and s.series = invalid then
        label = "Continuar (" + u_positionLabel(position) + ")"
    end if
    m.parts.watch.text = label
    m.parts.watch.disabled = not (s.movie <> invalid or s.series <> invalid or s.history <> invalid or s.candidates.Count() > 0)
    showRestart = (position > 0 and s.series = invalid) or (s.series <> invalid and s.history <> invalid)
    m.parts.restart.visible = showRestart
    if s.series <> invalid then m.parts.restart.text = "Temporadas e episódios" else m.parts.restart.text = "Assistir do início"
    m.parts.favorite.disabled = s.movie = invalid and s.series = invalid
    fav = false
    if s.movie <> invalid then
        fav = pr_isFavorite(s.movie.id, "MOVIE")
    else if s.series <> invalid then
        fav = pr_isFavorite(s.series.id, "SERIES")
    end if
    if fav then m.parts.favorite.text = "Favoritado" else m.parts.favorite.text = "Favoritar"
    u_trace("details", { title: m.parts.title.text, watch: label, favorite: m.parts.favorite.text, restart: showRestart, status: m.parts.status.text })
end sub

' Actions ----------------------------------------------------------------------------------------------------

sub onPressed(event as object)
    name = event.getRoSGNode().name
    s = m.state
    if s = invalid then return
    if name = "close" then
        ui_nav("back")
    else if name = "watch" then
        watch(false)
    else if name = "favorite" then
        if s.movie <> invalid then
            pr_toggleFavoriteMovie(s.movie)
        else if s.series <> invalid then
            pr_toggleFavoriteSeries(s.series)
        end if
        updateActions()
    else if name = "restart" then
        if s.series <> invalid and s.history <> invalid then
            ui_nav("open", { screen: "EpisodesScreen", series: s.series })
        else
            watch(true)
        end if
    end if
end sub

sub watch(restart as boolean)
    s = m.state
    if s.movie = invalid and s.unconfirmed and s.candidates.Count() > 0 then
        ui_nav("open", { screen: "OptionsScreen", candidates: s.candidates })
        return
    end if
    if s.history <> invalid and isSeries() then
        historyPlayback(s.history)
        return
    end if
    if s.series <> invalid then
        ui_nav("open", { screen: "EpisodesScreen", series: s.series })
        return
    end if
    if s.movie = invalid then return
    if s.sources.Count() > 1 then
        m.restartChoice = restart
        options = []
        for each source in s.sources
            options.Push({ label: source.title })
        end for
        ui_choose("Escolha a versão disponível", "", options, onSourceChosen)
        return
    end if
    vod_play(vod_moviePlayback(s.movie, restart))
end sub

sub onSourceChosen(index as integer)
    s = m.state
    if s = invalid or index < 0 or index >= s.sources.Count() then return
    vod_play(vod_moviePlayback(s.sources[index], m.restartChoice))
end sub

' Rebuilds a history entry, recovering the series only from an unambiguous title prefix.
sub historyPlayback(h as object)
    m.resume = { history: h, series: invalid }
    if h.mediaType = "EPISODE" and u_str(h.seriesId) = "" then
        rq_send(m.global.library, "inferSeries", { title: h.title }, onSeriesInferred)
    else
        onSeriesInferred(invalid)
    end if
end sub

sub onSeriesInferred(response as dynamic)
    r = m.resume
    if r = invalid then return
    h = r.history
    seriesId = u_str(h.seriesId)
    seriesTitle = u_str(h.seriesTitle)
    seriesUrl = u_str(h.seriesEpisodesUrl)
    if response <> invalid and response.ok and response.data <> invalid then
        seriesId = response.data.id
        seriesTitle = response.data.title
        seriesUrl = response.data.episodesUrl
    end if
    r.seriesId = seriesId
    r.seriesTitle = seriesTitle
    r.seriesUrl = seriesUrl
    if h.mediaType = "EPISODE" and seriesId <> "" then
        series = { id: seriesId, title: seriesTitle, poster: u_str(h.poster), episodesUrl: seriesUrl }
        rq_send(m.global.catalog, "episodes", { series: series }, onResumeEpisodes)
    else
        onResumeEpisodes({ ok: true, data: [] })
    end if
end sub

sub onResumeEpisodes(response as object)
    r = m.resume
    m.resume = invalid
    if r = invalid then return
    h = r.history
    episodes = []
    if response.ok then episodes = response.data
    episode = invalid
    index = -1
    for i = 0 to episodes.Count() - 1
        if episodes[i].id = h.id then
            episode = episodes[i]
            index = i
        end if
    end for
    url = h.streamUrl
    season = u_str(h.season)
    code = u_str(h.episodeCode)
    if episode <> invalid then
        url = episode.streamUrl
        season = episode.season
        code = episode.episodeCode
    end if
    info = {
        url: url, title: h.title, subtitle: u_str(h.subtitle), live: false, startMs: pr_savedPosition(h.id, h.mediaType),
        episodes: episodes, episodeIndex: index, posterUrl: u_str(h.poster), mediaId: h.id, mediaType: h.mediaType,
        seriesId: r.seriesId, seriesTitle: r.seriesTitle, seriesEpisodesUrl: r.seriesUrl, season: season, episodeCode: code
    }
    vod_play(info)
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    p = m.parts
    if key = "back" then
        ui_nav("back")
        return true
    end if
    if p.watch.hasFocus() then
        if key = "right" and not p.favorite.disabled then p.favorite.setFocus(true)
        if key = "down" and p.restart.visible then p.restart.setFocus(true)
        if key = "up" then p.close.setFocus(true)
    else if p.favorite.hasFocus() then
        if key = "left" and not p.watch.disabled then p.watch.setFocus(true)
        if key = "down" and p.restart.visible then p.restart.setFocus(true)
        if key = "up" then p.close.setFocus(true)
    else if p.restart.hasFocus() then
        if key = "up" then
            if p.watch.disabled then p.favorite.setFocus(true) else p.watch.setFocus(true)
        end if
    else if p.close.hasFocus() then
        if key = "down" then
            if not p.watch.disabled then
                p.watch.setFocus(true)
            else if not p.favorite.disabled then
                p.favorite.setFocus(true)
            end if
        end if
    end if
    return true
end function
