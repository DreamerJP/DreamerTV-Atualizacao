' Results are shown in rows; reaching the end of a row loads more of that kind.

sub init()
    m.keyboard = m.top.findNode("keyboard")
    m.rows = m.top.findNode("rows")
    m.status = m.top.findNode("status")
    m.debounce = m.top.findNode("debounce")
    m.keyboard.observeField("text", "onText")
    m.debounce.observeField("fire", "search")
    m.rows.observeField("rowItemSelected", "onSelected")
    m.rows.observeField("rowItemFocused", "onFocused")
    m.query = ""
    m.sections = []
    m.seq = 0
    m.global.library.observeFieldScoped("state", "onLibraryState")
end sub

function showScreen(params as object) as boolean
    rq_send(m.global.library, "build", {}, invalid)
    m.keyboard.setFocus(true)
    render()
    return true
end function

function leaveScreen(params as object) as boolean
    m.global.library.unobserveFieldScoped("state")
    return true
end function

function coverScreen(params as object) as boolean
    return true
end function

function returnToScreen(params as object) as boolean
    if m.sections.Count() > 0 then m.rows.setFocus(true) else m.keyboard.setFocus(true)
    return true
end function

sub onText()
    m.debounce.control = "stop"
    m.debounce.control = "start"
end sub

sub onLibraryState()
    if Len(m.query) >= 2 then search()
end sub

sub search()
    m.query = m.keyboard.text.Trim()
    m.seq = m.seq + 1
    if Len(m.query) < 2 then
        m.results = invalid
        render()
        return
    end if
    m.results = { channels: invalid, library: invalid, seq: m.seq }
    rq_send(m.global.catalog, "searchChannels", { query: m.query, offset: 0, limit: 50 }, onChannels)
    rq_send(m.global.library, "search", { query: m.query, offset: 0, limit: 50 }, onLibrary)
end sub

sub onChannels(response as object)
    if m.results = invalid or m.results.seq <> m.seq then return
    m.results.channels = []
    if response.ok then m.results.channels = response.data
    if m.results.library <> invalid then render()
end sub

sub onLibrary(response as object)
    if m.results = invalid or m.results.seq <> m.seq then return
    m.results.library = { movies: [], series: [] }
    if response.ok then m.results.library = response.data
    if m.results.channels <> invalid then render()
end sub

function cardsOf(items as object) as object
    cards = []
    for each item in items
        cards.Push({ title: item.title, poster: item.poster, fav: u_true(item.isFavorite) })
    end for
    return cards
end function

sub render()
    if m.results = invalid then
        m.sections = []
        m.rows.visible = false
        m.status.text = "Digite pelo menos duas letras para pesquisar"
        return
    end if
    r = m.results
    m.sections = []
    rows = []
    sizes = []
    heights = []
    if r.channels.Count() > 0 then
        m.sections.Push({ kind: "CHANNEL", items: r.channels, done: r.channels.Count() < 50 })
        rows.Push({ title: "CANAIS AO VIVO", kind: "channel", items: r.channels })
        sizes.Push([440, 92])
        heights.Push(170)
    end if
    if r.library.movies.Count() > 0 then
        m.sections.Push({ kind: "MOVIE", items: r.library.movies, done: r.library.movies.Count() < 50 })
        rows.Push({ title: "FILMES", kind: "poster", items: cardsOf(r.library.movies) })
        sizes.Push([219, 406])
        heights.Push(480)
    end if
    if r.library.series.Count() > 0 then
        m.sections.Push({ kind: "SERIES", items: r.library.series, done: r.library.series.Count() < 50 })
        rows.Push({ title: "SÉRIES & NOVELAS", kind: "poster", items: cardsOf(r.library.series) })
        sizes.Push([219, 406])
        heights.Push(480)
    end if
    state = m.global.library.state
    message = ""
    if rows.Count() = 0 then
        if state = "loading" then
            message = "Carregando catálogo completo…"
        else if state = "error" then
            message = "Não foi possível completar o catálogo. Os itens já carregados continuam disponíveis."
        else
            message = "Nenhum resultado para " + Chr(34) + m.query + Chr(34)
        end if
    else if state = "error" then
        message = "Não foi possível completar o catálogo. Os itens já carregados continuam disponíveis."
    end if
    m.status.text = message
    if rows.Count() = 0 then
        m.rows.visible = false
        return
    end if
    m.rows.visible = true
    m.rows.rowItemSize = sizes
    m.rows.rowHeights = heights
    m.rows.rowItemSpacing = [[20, 0]]
    m.rows.content = ui_rowContent(rows)
    u_trace("search", { query: m.query, channels: r.channels.Count(), movies: r.library.movies.Count(), series: r.library.series.Count() })
end sub

' The end of a row asks for the next 50 of that kind.
sub onFocused()
    f = m.rows.rowItemFocused
    if f = invalid or f.Count() < 2 or f[0] >= m.sections.Count() then return
    section = m.sections[f[0]]
    if section.done or u_true(section.loading) or f[1] < section.items.Count() - 3 then return
    section.loading = true
    m.moreRow = f[0]
    m.moreSeq = m.seq
    if section.kind = "CHANNEL" then
        rq_send(m.global.catalog, "searchChannels", { query: m.query, offset: section.items.Count(), limit: 50 }, onMore)
    else
        rq_send(m.global.library, "search", { query: m.query, type: section.kind, offset: section.items.Count(), limit: 50 }, onMore)
    end if
end sub

sub onMore(response as object)
    if m.moreSeq <> m.seq or m.moreRow >= m.sections.Count() then return
    section = m.sections[m.moreRow]
    section.loading = false
    if not response.ok then return
    batch = response.data
    if section.kind = "MOVIE" then batch = response.data.movies
    if section.kind = "SERIES" then batch = response.data.series
    if batch.Count() < 50 then section.done = true
    row = m.rows.content.getChild(m.moreRow)
    for each item in batch
        section.items.Push(item)
        child = row.createChild("ContentNode")
        if section.kind = "CHANNEL" then
            child.update({ kind: "channel", title: u_str(item.name), number: u_int(item.number), logo: u_str(item.logo), fav: u_true(item.isFavorite), selected: false }, true)
        else
            child.update({ kind: "poster", title: u_str(item.title), poster: u_str(item.poster), sub: "", subMuted: false, fav: u_true(item.isFavorite), progress: -1, dim: false }, true)
        end if
    end for
end sub

sub onSelected()
    sel = m.rows.rowItemSelected
    if sel = invalid or sel.Count() < 2 or sel[0] >= m.sections.Count() then return
    section = m.sections[sel[0]]
    item = section.items[sel[1]]
    if section.kind = "CHANNEL" then
        m.pendingChannel = item
        rq_send(m.global.catalog, "allChannels", {}, onAllChannels)
    else if section.kind = "MOVIE" then
        ui_nav("open", { screen: "DetailsScreen", movie: item })
    else
        ui_nav("open", { screen: "DetailsScreen", series: item })
    end if
end sub

sub onAllChannels(response as object)
    list = []
    if response.ok then list = response.data
    ui_nav("open", { screen: "PlayerScreen", live: true, channel: m.pendingChannel, channels: list })
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    if key = "back" then
        ui_nav("back")
        return true
    end if
    if key = "right" and m.keyboard.isInFocusChain() and m.rows.visible then
        m.rows.setFocus(true)
        return true
    end if
    if key = "left" and m.rows.hasFocus() then
        m.keyboard.setFocus(true)
        return true
    end if
    return false
end function
