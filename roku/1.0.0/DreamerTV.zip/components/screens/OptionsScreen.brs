sub init()
    m.grid = m.top.findNode("grid")
    m.close = m.top.findNode("close")
    m.grid.observeField("itemSelected", "onSelected")
    m.close.observeField("pressed", "finish")
    m.items = []
end sub

function showScreen(params as object) as boolean
    m.items = params.candidates
    cards = []
    for each item in m.items
        cards.Push({ title: item.title, poster: item.poster })
    end for
    root = CreateObject("roSGNode", "ContentNode")
    ui_appendPosters(root, cards)
    m.grid.content = root
    if m.items.Count() > 0 then m.grid.setFocus(true) else m.close.setFocus(true)
    return true
end function

function leaveScreen(params as object) as boolean
    return true
end function

function coverScreen(params as object) as boolean
    return true
end function

function returnToScreen(params as object) as boolean
    return true
end function

sub finish()
    ui_nav("back")
end sub

sub onSelected()
    index = m.grid.itemSelected
    if index < 0 or index >= m.items.Count() then return
    ui_nav("open", { screen: "DetailsScreen", movie: m.items[index], replace: true })
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    if key = "back" then
        finish()
        return true
    end if
    if key = "up" and m.grid.hasFocus() then
        m.close.setFocus(true)
        return true
    end if
    if key = "down" and m.close.hasFocus() and m.items.Count() > 0 then
        m.grid.setFocus(true)
        return true
    end if
    return true
end function
