' Tabs move with the arrows and open with OK; DOWN enters the section and VOLTAR returns to the tabs.

sub init()
    m.content = m.top.findNode("content")
    m.tabsGroup = m.top.findNode("tabs")
    m.clock = m.top.findNode("clock")
    m.clockTimer = m.top.findNode("clockTimer")
    m.clockTimer.observeField("fire", "onClock")
    m.tabDefs = [
        { key: "live", label: "TV ao vivo", width: 196 },
        { key: "movies", label: "Filmes", width: 136 },
        { key: "series", label: "Séries", width: 136 },
        { key: "24h", label: "24 horas", width: 160 },
        { key: "favorites", label: "Favoritos", width: 176 },
        { key: "settings", label: "Ajustes", width: 156 },
        { key: "search", label: "Buscar", width: 156 }
    ]
    m.buttons = []
    x = 0
    for each t in m.tabDefs
        b = ui_btn(t.label, t.width, 84, "tab")
        b.bold = true
        b.fontSize = 26
        b.name = t.key
        if t.key = "search" then
            x = x + 24
            b.kind = "normal"
        end if
        b.translation = [x, 0]
        b.observeField("pressed", "onTabPressed")
        m.tabsGroup.appendChild(b)
        m.buttons.Push(b)
        x = x + t.width + 6
    end for
    m.views = {}
    m.active = ""
    m.backAt = 0
end sub

function showScreen(params as object) as boolean
    onClock()
    m.clockTimer.control = "start"
    saved = u_str(pr_get("tab", "live"))
    if saved = "search" or saved = "" then saved = "live"
    ' "Abrir no último canal" starts from TV ao vivo whatever tab was used last.
    if m.global.autoBootPending then saved = "live"
    switchTab(saved)
    focusInitial()
    rq_send(m.global.library, "build", {}, invalid)
    rq_send(m.global.net, "update", {}, onUpdateInfo)
    return true
end function

function leaveScreen(params as object) as boolean
    m.clockTimer.control = "stop"
    if m.active <> "" then m.views[m.active].callFunc("hideView", {})
    return true
end function

function coverScreen(params as object) as boolean
    return true
end function

function returnToScreen(result as object) as boolean
    if m.active <> "" then m.views[m.active].callFunc("returnToView", result)
    if m.active = "settings" or m.active = "favorites" then m.views[m.active].callFunc("focusView", {})
    return true
end function

sub onUpdateInfo(response as object)
    if response.ok then m.global.updateInfo = response.data
end sub

sub onClock()
    m.clock.text = u_clock()
end sub

function viewFor(key as string) as object
    view = m.views[key]
    if view <> invalid then return view
    if key = "live" or key = "24h" then
        view = CreateObject("roSGNode", "LiveView")
        view.mode = key
    else if key = "movies" or key = "series" then
        view = CreateObject("roSGNode", "VodView")
        view.series = key = "series"
    else if key = "favorites" then
        view = CreateObject("roSGNode", "FavoritesView")
    else
        view = CreateObject("roSGNode", "SettingsView")
    end if
    view.visible = false
    m.content.appendChild(view)
    m.views[key] = view
    return view
end function

sub switchTab(key as string)
    if key = m.active then return
    if m.active <> "" then
        old = m.views[m.active]
        old.callFunc("hideView", {})
        old.visible = false
    end if
    m.active = key
    pr_set("tab", key)
    for each b in m.buttons
        b.selected = b.name = key
    end for
    view = viewFor(key)
    view.visible = true
    u_trace("tab", { key: key })
    view.callFunc("showView", {})
end sub

function tabButton(key as string) as dynamic
    for each b in m.buttons
        if b.name = key then return b
    end for
    return invalid
end function

sub focusInitial()
    view = m.views[m.active]
    if view <> invalid then view.callFunc("focusView", {})
end sub

sub onTabPressed(event as object)
    key = event.getRoSGNode().name
    if key = "search" then
        ui_nav("open", { screen: "SearchScreen" })
        return
    end if
    switchTab(key)
    view = m.views[key]
    view.callFunc("focusView", {})
end sub

function focusedTabIndex() as integer
    for i = 0 to m.buttons.Count() - 1
        if m.buttons[i].hasFocus() then return i
    end for
    return -1
end function

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    tabIndex = focusedTabIndex()
    u_trace("homeKey", { key: key, tab: tabIndex })
    if tabIndex >= 0 then
        if key = "left" and tabIndex > 0 then
            m.buttons[tabIndex - 1].setFocus(true)
            return true
        end if
        if key = "right" and tabIndex < m.buttons.Count() - 1 then
            m.buttons[tabIndex + 1].setFocus(true)
            return true
        end if
        if key = "down" then
            focusInitial()
            return true
        end if
        if key = "back" then
            if u_now() - m.backAt < 2000 then
                ui_nav("exit")
            else
                m.backAt = u_now()
                ui_toast("Pressione VOLTAR novamente para sair")
            end if
            return true
        end if
        return true
    end if
    ' Keys the section did not use: UP and VOLTAR go to the tab bar.
    if key = "up" or key = "back" then
        b = tabButton(m.active)
        if b <> invalid then b.setFocus(true)
        return true
    end if
    return false
end function
