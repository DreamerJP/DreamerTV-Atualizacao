' Seasons on the left, episodes of the chosen season on the right. The last season opened is remembered.

sub init()
    m.seasons = m.top.findNode("seasons")
    m.episodesList = m.top.findNode("episodes")
    m.heading = m.top.findNode("heading")
    m.status = m.top.findNode("status")
    m.retry = m.top.findNode("retry")
    m.close = m.top.findNode("close")
    m.seasons.observeField("itemSelected", "onSeasonSelected")
    m.episodesList.observeField("itemSelected", "onEpisodeSelected")
    m.retry.observeField("pressed", "load")
    m.close.observeField("pressed", "finish")
    m.all = []
    m.seasonNames = []
    m.shown = []
    m.season = ""
end sub

function showScreen(params as object) as boolean
    m.series = params.series
    m.top.findNode("seriesTitle").text = u_str(m.series.title)
    m.top.findNode("seriesCategory").text = u_str(m.series.categoryName)
    m.top.findNode("poster").uri = u_str(m.series.poster)
    m.close.setFocus(true)
    load()
    return true
end function

function leaveScreen(params as object) as boolean
    return true
end function

function coverScreen(params as object) as boolean
    return true
end function

function returnToScreen(params as object) as boolean
    if m.season <> "" then showSeason(m.season, false)
    return true
end function

sub finish()
    ui_nav("back")
end sub

sub load()
    m.status.visible = true
    m.status.text = "Carregando episódios…"
    m.retry.visible = false
    rq_send(m.global.catalog, "episodes", { series: m.series }, onEpisodes)
end sub

sub onEpisodes(response as object)
    if not response.ok then
        m.status.text = "Não foi possível carregar os episódios. Confira a conexão e tente novamente."
        m.retry.visible = true
        m.retry.setFocus(true)
        return
    end if
    m.all = response.data
    m.seasonNames = []
    counts = {}
    for each e in m.all
        if not counts.DoesExist(e.season) then
            counts[e.season] = 0
            m.seasonNames.Push(e.season)
        end if
        counts[e.season] = counts[e.season] + 1
    end for
    if m.seasonNames.Count() = 0 then
        m.status.text = "Nenhum episódio disponível nesta série."
        return
    end if
    m.status.visible = false
    saved = LCase(pr_lastSeason(u_str(m.series.id)))
    initial = m.seasonNames[0]
    for each s in m.seasonNames
        if saved <> "" and LCase(s) = saved then initial = s
    end for
    m.counts = counts
    m.savedSeason = saved
    renderSeasons(initial)
    showSeason(initial, false)
    m.seasons.jumpToItem = u_indexOf(m.seasonNames, initial)
    m.seasons.setFocus(true)
end sub

sub renderSeasons(selected as string)
    rows = []
    for each s in m.seasonNames
        count = m.counts[s]
        text = count.ToStr() + " episódios"
        if count = 1 then text = "1 episódio"
        if m.savedSeason <> "" and LCase(s) = m.savedSeason then text = text + " · Atual"
        rows.Push({ title: season_display(s), small: text, selected: s = selected })
    end for
    focusIndex = m.seasons.itemFocused
    m.seasons.content = ui_textContent(rows)
    if m.seasons.hasFocus() then m.seasons.jumpToItem = focusIndex
end sub

sub showSeason(season as string, focusFirst as boolean)
    m.season = season
    m.shown = []
    for each e in m.all
        if LCase(e.season) = LCase(season) then m.shown.Push(e)
    end for
    content = m.seasons.content
    if content <> invalid then
        for i = 0 to m.seasonNames.Count() - 1
            content.getChild(i).selected = m.seasonNames[i] = season
        end for
    end if
    count = m.shown.Count()
    suffix = " episódios"
    if count = 1 then suffix = " episódio"
    m.heading.text = season_display(season) + " · " + count.ToStr() + suffix
    watched = pr_watchedEpisodes()
    rows = []
    for each e in m.shown
        badge = ""
        if u_indexOf(watched, e.id) >= 0 then badge = "VISTO"
        rows.Push({ title: e.episodeCode + "   " + e.title, badge: badge })
    end for
    m.episodesList.content = ui_textContent(rows)
    if focusFirst and count > 0 then m.episodesList.setFocus(true)
    u_trace("season", { season: season, episodes: count })
end sub

sub onSeasonSelected()
    index = m.seasons.itemSelected
    if index < 0 or index >= m.seasonNames.Count() then return
    showSeason(m.seasonNames[index], true)
end sub

sub onEpisodeSelected()
    index = m.episodesList.itemSelected
    if index < 0 or index >= m.shown.Count() then return
    episode = m.shown[index]
    pr_saveLastSeason(u_str(m.series.id), episode.season)
    vod_playWithResumeChoice(vod_episodePlayback(m.series, episode, m.all), true)
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    if key = "back" then
        finish()
        return true
    end if
    if m.seasons.hasFocus() then
        if key = "right" and m.shown.Count() > 0 then m.episodesList.setFocus(true)
        if key = "up" then m.close.setFocus(true)
    else if m.episodesList.hasFocus() then
        if key = "left" then m.seasons.setFocus(true)
        if key = "up" then m.close.setFocus(true)
    else if m.close.hasFocus() then
        if key = "down" then
            if m.retry.visible then
                m.retry.setFocus(true)
            else if m.seasonNames.Count() > 0 then
                m.seasons.setFocus(true)
            end if
        end if
    else if m.retry.hasFocus() then
        if key = "up" then m.close.setFocus(true)
    end if
    return true
end function
