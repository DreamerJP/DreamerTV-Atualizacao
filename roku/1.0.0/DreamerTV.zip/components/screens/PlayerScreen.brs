' Full-screen player. Live: UP/DOWN change channel, LEFT opens the channel list. Movies and episodes:
' LEFT/RIGHT (or the rewind and fast-forward keys) seek 10 s per tap and faster while held.

sub init()
    m.player = m.global.player
    m.osd = m.top.findNode("osd")
    m.title = m.top.findNode("title")
    m.clock = m.top.findNode("clock")
    m.vodRows = m.top.findNode("vodRows")
    m.hint = m.top.findNode("hint")
    m.currentText = m.top.findNode("current")
    m.totalText = m.top.findNode("total")
    m.bar = m.top.findNode("bar")
    m.barFill = m.top.findNode("barFill")
    m.barBg = m.top.findNode("barBg")
    m.knob = m.top.findNode("knob")
    m.buttonsGroup = m.top.findNode("buttons")
    m.next = m.top.findNode("next")
    m.nextText = m.top.findNode("nextText")
    m.nextBtn = m.top.findNode("nextBtn")
    m.drawer = m.top.findNode("drawer")
    m.drawerList = m.top.findNode("drawerList")
    m.loading = m.top.findNode("loading")
    m.subtitle = m.top.findNode("subtitle")
    m.osdTimer = m.top.findNode("osdTimer")
    m.tickTimer = m.top.findNode("tickTimer")
    m.seekTimer = m.top.findNode("seekTimer")
    m.osdTimer.observeField("fire", "hideOsd")
    m.tickTimer.observeField("fire", "onTick")
    m.seekTimer.observeField("fire", "onSeekTimer")
    m.nextBtn.observeField("pressed", "playNext")
    m.drawerList.observeField("itemSelected", "onDrawerSelected")
    m.bar.observeField("focusedChild", "onBarFocus")
    m.audioBtn = makeButton("audio", "Áudio", 0)
    m.subsBtn = makeButton("subs", "Legendas", 260)
    m.listBtn = makeButton("list", "Lista de Canais", 520)
    m.info = invalid
    m.channels = []
    m.channelIndex = 0
    m.episodes = []
    m.episodeIndex = -1
    m.prepared = false
    m.terminalError = false
    m.nextTriggered = false
    m.ending = false
    m.lastSave = 0
    m.duration = 0
    m.lastPosition = 0
    m.cues = invalid
    m.subtitleRequest = 0
    m.seek = invalid
    m.keepLive = false
end sub

function makeButton(name as string, label as string, x as float) as object
    b = ui_btn(label, 240, 80)
    b.name = name
    b.translation = [x, 0]
    b.observeField("pressed", "onButton")
    m.buttonsGroup.appendChild(b)
    return b
end function

' params: {live, channel, channels, keepLive} or {info} for movies and episodes.
function showScreen(params as object) as boolean
    m.player.observeFieldScoped("event", "onPlayerEvent")
    m.tickTimer.control = "start"
    if u_true(params.live) then
        openLive(params.channel, params.channels, u_true(params.keepLive))
    else
        openVod(params.info)
    end if
    return true
end function

function leaveScreen(params as object) as boolean
    m.player.unobserveFieldScoped("event")
    m.tickTimer.control = "stop"
    m.osdTimer.control = "stop"
    m.seekTimer.control = "stop"
    return true
end function

function coverScreen(params as object) as boolean
    return true
end function

function returnToScreen(params as object) as boolean
    return true
end function

' Opening -----------------------------------------------------------------------------------------------

sub prepareLayout()
    live = u_true(m.info.live)
    m.vodRows.visible = not live
    m.subsBtn.visible = not live
    m.listBtn.visible = live and m.channels.Count() > 1
    if live then
        m.listBtn.translation = [260, 0]
    else
        m.listBtn.translation = [520, 0]
    end if
    m.drawer.visible = false
    m.subtitle.text = ""
end sub

' Keeps the preview's playback when it is already the same channel.
sub openLive(channel as object, list as object, keepLive as boolean)
    m.keepLive = keepLive
    m.channels = list
    if m.channels = invalid or m.channels.Count() = 0 then m.channels = [channel]
    m.channelIndex = 0
    for i = 0 to m.channels.Count() - 1
        if m.channels[i].id = channel.id then m.channelIndex = i
    end for
    m.episodes = []
    m.episodeIndex = -1
    m.info = { url: channel.streamUrl, title: channel.name, subtitle: u_str(channel.category), live: true, mediaId: channel.id, mediaType: "CHANNEL" }
    prepareLayout()
    if m.player.callFunc("isKeepable", { id: channel.id }) then
        m.player.callFunc("setOwner", { owner: "player" })
        m.player.callFunc("fullscreen", {})
        m.prepared = true
        m.terminalError = false
        m.loading.callFunc("hideBox", {})
        updateTitle()
        showOsd(3)
    else
        start(false)
    end if
end sub

sub openVod(info as object)
    m.keepLive = false
    m.channels = []
    m.episodes = []
    if u_isArray(info.episodes) then m.episodes = info.episodes
    m.episodeIndex = -1
    if info.episodeIndex <> invalid then m.episodeIndex = u_int(info.episodeIndex)
    m.info = info
    prepareLayout()
    start(false)
end sub

sub start(retry as boolean)
    m.terminalError = false
    m.prepared = false
    m.nextTriggered = false
    m.ending = false
    m.lastSave = 0
    m.duration = 0
    m.subtitleRequest = m.subtitleRequest + 1
    stopExternal()
    m.seek = invalid
    m.seekTimer.control = "stop"
    m.next.visible = false
    m.loading.callFunc("showStatus", { message: "Conectando", pct: invalid })
    updateTitle()
    m.player.callFunc("fullscreen", {})
    startMs = u_num(m.info.startMs)
    if retry then startMs = m.lastPosition
    m.lastPosition = startMs
    url = pr_refreshUrl(pr_session(), m.info.url)
    m.player.callFunc("playItem", { url: url, live: u_true(m.info.live), id: u_str(m.info.mediaId), owner: "player", startMs: startMs })
    u_trace("playerOpen", { title: m.info.title, startMs: startMs, episodes: m.episodes.Count(), index: m.episodeIndex })
    if u_true(m.info.live) then showOsd(3) else showOsd(5)
end sub

sub updateTitle()
    if u_true(m.info.live) and m.channelIndex < m.channels.Count() then
        c = m.channels[m.channelIndex]
        number = u_int(c.number)
        if number <= 0 then number = m.channelIndex + 1
        m.title.text = u_pad(number, 3) + "  " + m.info.title
    else
        m.title.text = m.info.title
    end if
end sub

' OSD ------------------------------------------------------------------------------------------------------

sub showOsd(seconds = 5 as float)
    m.osd.visible = true
    if u_true(pr_settings().showClock) then m.clock.text = u_clock() else m.clock.text = ""
    m.osdTimer.control = "stop"
    m.osdTimer.duration = seconds
    m.osdTimer.control = "start"
    if not osdHasFocus() then
        if u_true(m.info.live) then
            m.audioBtn.setFocus(true)
        else
            m.bar.setFocus(true)
        end if
    end if
end sub

sub hideOsd()
    if m.seek <> invalid then return
    m.osd.visible = false
    m.top.setFocus(true)
end sub

function osdHasFocus() as boolean
    return m.bar.hasFocus() or m.audioBtn.hasFocus() or m.subsBtn.hasFocus() or m.listBtn.hasFocus()
end function

sub onBarFocus()
    if m.bar.hasFocus() then m.knob.color = "0xFFFFFFFF" else m.knob.color = "0xC4C4C4FF"
end sub

function visibleButtons() as object
    out = [m.audioBtn]
    if m.subsBtn.visible then out.Push(m.subsBtn)
    if m.listBtn.visible then out.Push(m.listBtn)
    return out
end function

' Progress ---------------------------------------------------------------------------------------------------

sub renderProgress(position as double)
    if u_true(m.info.live) or not m.prepared then return
    d = m.player.callFunc("playerDuration", {})
    if d > 0 then m.duration = d
    if m.duration <= 0 then return
    shown = position
    if m.seek <> invalid then shown = m.seek.target
    pct = shown / m.duration
    if pct < 0 then pct = 0
    if pct > 1 then pct = 1
    m.barFill.width = 1520 * pct
    m.knob.translation = [1520 * pct - 14, -6]
    m.currentText.text = u_formatTime(shown)
    m.totalText.text = u_formatTime(m.duration)
    remaining = m.duration - position
    if remaining >= 1000 and remaining <= 20000 and hasNext() then
        m.nextText.text = "Próximo episódio em " + Int(remaining / 1000).ToStr() + "s…"
        m.next.visible = true
    else
        m.next.visible = false
    end if
end sub

function progressItem(position as double, total as double) as object
    return {
        id: u_str(m.info.mediaId), title: m.info.title, subtitle: u_str(m.info.subtitle), poster: u_str(m.info.posterUrl),
        streamUrl: m.info.url, positionMs: position, durationMs: total, mediaType: m.info.mediaType,
        seriesId: u_str(m.info.seriesId), seriesTitle: u_str(m.info.seriesTitle), seriesEpisodesUrl: u_str(m.info.seriesEpisodesUrl),
        season: u_str(m.info.season), episodeCode: u_str(m.info.episodeCode)
    }
end function

sub saveProgress(force as boolean)
    if m.info = invalid or u_true(m.info.live) or not m.prepared then return
    position = m.player.callFunc("playerTime", {})
    if position < 0 then position = 0
    total = m.player.callFunc("playerDuration", {})
    if total <= 0 then total = m.duration
    m.lastPosition = position
    if position = 0 then return
    if not force and m.lastSave > 0 and u_now() - m.lastSave < 60000 then return
    m.lastSave = u_now()
    pr_savePlaybackProgress(progressItem(position, total), total > 60000 and position >= total * 0.97, total > 60000 and position >= total * 0.85)
end sub

sub completeItem()
    if m.info = invalid or u_true(m.info.live) then return
    pr_savePlaybackProgress(progressItem(0, m.duration), true, true)
end sub

' Episodes ---------------------------------------------------------------------------------------------------

function hasNext() as boolean
    return m.episodeIndex >= 0 and m.episodeIndex + 1 < m.episodes.Count()
end function

sub playNext()
    if not hasNext() or m.nextTriggered then return
    m.nextTriggered = true
    completeItem()
    m.episodeIndex = m.episodeIndex + 1
    nextEp = m.episodes[m.episodeIndex]
    seriesTitle = u_str(m.info.seriesTitle)
    if seriesTitle = "" then seriesTitle = m.info.title.Split(" - ")[0]
    info = u_copyAA(m.info)
    info.url = nextEp.streamUrl
    info.title = nextEp.title
    if seriesTitle <> "" then info.title = seriesTitle + " - " + nextEp.title
    info.subtitle = season_display(nextEp.season) + " (" + nextEp.episodeCode + ")"
    info.startMs = 0
    info.mediaId = nextEp.id
    info.mediaType = "EPISODE"
    info.seriesTitle = seriesTitle
    info.season = nextEp.season
    info.episodeCode = nextEp.episodeCode
    m.info = info
    if u_str(info.seriesId) <> "" then pr_saveLastSeason(info.seriesId, nextEp.season)
    start(false)
end sub

sub handleEnded()
    if u_true(m.info.live) or m.ending then return
    m.ending = true
    completeItem()
    if hasNext() then
        playNext()
    else
        closePlayer()
    end if
end sub

' Channels ---------------------------------------------------------------------------------------------------

sub switchChannel(index as integer)
    if index < 0 or index >= m.channels.Count() then return
    channel = m.channels[index]
    m.channelIndex = index
    pr_setSetting("lastChannelId", channel.id)
    m.info.url = channel.streamUrl
    m.info.title = channel.name
    m.info.subtitle = u_str(channel.category)
    m.info.mediaId = channel.id
    start(false)
end sub

sub toggleDrawer()
    if m.drawer.visible then
        m.drawer.visible = false
        showOsd()
        return
    end if
    if m.channels.Count() = 0 then return
    hideOsd()
    m.drawer.visible = true
    m.drawerList.content = ui_channelContent(m.channels, m.channels[m.channelIndex].id)
    m.drawerList.jumpToItem = m.channelIndex
    m.drawerList.setFocus(true)
end sub

sub onDrawerSelected()
    index = m.drawerList.itemSelected
    m.drawer.visible = false
    m.top.setFocus(true)
    switchChannel(index)
end sub

' Tracks and subtitles ---------------------------------------------------------------------------------------

sub onButton(event as object)
    name = event.getRoSGNode().name
    if name = "audio" then
        chooseAudio()
    else if name = "subs" then
        chooseSubtitles()
    else if name = "list" then
        toggleDrawer()
    end if
end sub

sub chooseAudio()
    m.audioOptions = m.player.callFunc("audioTracks", {})
    if m.audioOptions.Count() = 0 then
        ui_toast("Este conteúdo tem uma única faixa de áudio.")
        return
    end if
    options = []
    for each t in m.audioOptions
        options.Push({ label: t.name, selected: t.selected, primary: t.selected })
    end for
    ui_choose("Selecionar Áudio", "", options, onAudioChosen)
end sub

sub onAudioChosen(index as integer)
    if index < 0 or index >= m.audioOptions.Count() then return
    m.player.callFunc("selectAudio", { track: m.audioOptions[index].track })
end sub

sub stopExternal()
    m.cues = invalid
    m.subtitle.text = ""
end sub

sub chooseSubtitles()
    tracks = m.player.callFunc("textTracks", {})
    anySelected = false
    for each t in tracks
        if t.selected then anySelected = true
    end for
    m.subtitleActions = []
    options = [{ label: "Desativada", selected: m.cues = invalid and not anySelected }]
    m.subtitleActions.Push({ kind: "off" })
    for each t in tracks
        options.Push({ label: t.name + " (Embutida)", selected: m.cues = invalid and t.selected })
        m.subtitleActions.Push({ kind: "track", track: t.track })
    end for
    if m.cues <> invalid then
        options.Push({ label: "Português (PT-BR) (Online)", selected: true })
        m.subtitleActions.Push({ kind: "keep" })
    end if
    options.Push({ label: "Buscar Legenda Online (PT-BR)" })
    m.subtitleActions.Push({ kind: "online" })
    ui_choose("Selecionar Legenda", "", options, onSubtitleChosen)
end sub

sub onSubtitleChosen(index as integer)
    if index < 0 or index >= m.subtitleActions.Count() then return
    action = m.subtitleActions[index]
    if action.kind = "off" then
        m.subtitleRequest = m.subtitleRequest + 1
        stopExternal()
        m.player.callFunc("selectText", { track: "" })
    else if action.kind = "track" then
        m.subtitleRequest = m.subtitleRequest + 1
        stopExternal()
        m.player.callFunc("selectText", { track: action.track })
    else if action.kind = "online" then
        fetchOnline()
    end if
end sub

sub fetchOnline()
    m.subtitleRequest = m.subtitleRequest + 1
    isSeries = m.info.mediaType = "EPISODE" or u_str(m.info.seriesId) <> ""
    name = m.info.title
    if isSeries then
        name = u_str(m.info.seriesTitle)
        if name = "" then name = m.info.title.Split(" - ")[0]
    end if
    m.subtitleTarget = { request: m.subtitleRequest, isSeries: isSeries, mediaId: u_str(m.info.mediaId) }
    ui_toast("Buscando legenda em português...")
    rq_send(m.global.net, "subtitleTitles", { name: name, isSeries: isSeries }, onSubtitleTitles)
end sub

function subtitleCurrent() as boolean
    t = m.subtitleTarget
    return t <> invalid and t.request = m.subtitleRequest and m.info <> invalid and t.mediaId = u_str(m.info.mediaId)
end function

sub onSubtitleTitles(response as object)
    if not subtitleCurrent() then return
    if not response.ok then
        ui_toast(u_str(response.message))
        return
    end if
    m.subtitleTitles = response.data
    if m.subtitleTitles.Count() = 1 then
        downloadSubtitle(m.subtitleTitles[0])
        return
    end if
    options = []
    for each t in m.subtitleTitles
        label = t.name
        if t.year <> "" then label = label + " (" + t.year + ")"
        options.Push({ label: label })
    end for
    ui_choose("Confirme o título da legenda", "", options, onSubtitleTitleChosen)
end sub

sub onSubtitleTitleChosen(index as integer)
    if index < 0 or not subtitleCurrent() then return
    downloadSubtitle(m.subtitleTitles[index])
end sub

sub downloadSubtitle(title as object)
    episode = invalid
    if m.episodeIndex >= 0 and m.episodeIndex < m.episodes.Count() then episode = m.episodes[m.episodeIndex]
    season = u_str(m.info.season)
    code = u_str(m.info.episodeCode)
    episodeTitle = m.info.title
    if episode <> invalid then
        season = episode.season
        code = episode.episodeCode
        episodeTitle = episode.title
    end if
    rq_send(m.global.net, "subtitleDownload", { imdbId: title.id, isSeries: m.subtitleTarget.isSeries, season: season, episodeCode: code, title: episodeTitle }, onSubtitleDownloaded)
end sub

sub onSubtitleDownloaded(response as object)
    if not subtitleCurrent() then return
    if not response.ok then
        ui_toast(u_str(response.message))
        return
    end if
    m.player.callFunc("selectText", { track: "" })
    m.cues = response.data
    ui_toast("Legenda em português aplicada.")
end sub

function cueAt(ms as double) as string
    cues = m.cues
    lo = 0
    hi = cues.Count() - 1
    while lo <= hi
        middle = Int((lo + hi) / 2)
        c = cues[middle]
        if c.e < ms then
            lo = middle + 1
        else if c.s > ms then
            hi = middle - 1
        else
            return c.t
        end if
    end while
    return ""
end function

sub onTick()
    if m.info = invalid then return
    if m.cues <> invalid then m.subtitle.text = cueAt(m.player.callFunc("playerTime", {}))
    if m.osd.visible and u_true(pr_settings().showClock) then m.clock.text = u_clock()
end sub

' Remote seek ---------------------------------------------------------------------------------------------------

function seekStep(heldMs as double) as double
    if heldMs >= 10000 then return 300000
    if heldMs >= 6000 then return 120000
    if heldMs >= 3000 then return 60000
    if heldMs >= 1200 then return 30000
    return 10000
end function

function canSeek() as boolean
    return not u_true(m.info.live) and not m.terminalError and m.prepared and m.duration > 0 and not m.drawer.visible
end function

sub beginSeek(forward as boolean)
    if m.seek = invalid or m.seek.forward <> forward then
        wasPlaying = m.player.callFunc("playerState", {}) = "playing"
        target = m.player.callFunc("playerTime", {})
        if m.seek <> invalid then
            wasPlaying = m.seek.wasPlaying
            target = m.seek.target
        end if
        m.seek = { forward: forward, target: target, since: u_now(), wasPlaying: wasPlaying }
        m.player.callFunc("pausePlayback", {})
    end if
    stepSeek(10000)
    m.seekTimer.control = "start"
end sub

sub stepSeek(stepMs as double)
    if m.seek.forward then
        m.seek.target = m.seek.target + stepMs
        if m.seek.target > m.duration then m.seek.target = m.duration
    else
        m.seek.target = m.seek.target - stepMs
        if m.seek.target < 0 then m.seek.target = 0
    end if
    m.hint.text = "Solte para assistir a partir de " + u_formatTime(m.seek.target)
    showOsd()
    m.bar.setFocus(true)
    renderProgress(m.player.callFunc("playerTime", {}))
end sub

sub onSeekTimer()
    if m.seek = invalid then
        m.seekTimer.control = "stop"
        return
    end if
    stepSeek(seekStep(u_now() - m.seek.since))
end sub

sub finishSeek(commit as boolean)
    if m.seek = invalid then return
    s = m.seek
    m.seek = invalid
    m.seekTimer.control = "stop"
    m.hint.text = "Toque nas setas: 10 s · Segure: avanço rápido"
    if commit then
        m.player.callFunc("seekTo", { ms: s.target })
        m.lastPosition = s.target
        if s.wasPlaying then m.player.callFunc("resumePlayback", {})
        saveProgress(true)
    else if s.wasPlaying then
        m.player.callFunc("resumePlayback", {})
    end if
    showOsd()
end sub

function isSeekKey(key as string) as boolean
    return key = "left" or key = "right" or key = "fastforward" or key = "rewind"
end function

' Keys ------------------------------------------------------------------------------------------------------------

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then
        if m.seek <> invalid and isSeekKey(key) then finishSeek(true)
        return true
    end if
    if m.seek <> invalid and not isSeekKey(key) then finishSeek(true)
    if key = "back" then
        onBack()
        return true
    end if
    if isSeekKey(key) and canSeek() then
        trickKey = key = "fastforward" or key = "rewind"
        if m.seek <> invalid or not m.osd.visible or m.bar.hasFocus() or trickKey then
            if m.seek = invalid or m.seek.forward <> (key = "right" or key = "fastforward") then beginSeek(key = "right" or key = "fastforward")
            return true
        end if
    end if
    if key = "play" then
        m.player.callFunc("togglePlayback", {})
        if not u_true(m.info.live) then saveProgress(true)
        showOsd()
        return true
    end if
    if key = "replay" and canSeek() then
        target = m.player.callFunc("playerTime", {}) - 10000
        if target < 0 then target = 0
        m.player.callFunc("seekTo", { ms: target })
        showOsd()
        return true
    end if
    if m.drawer.visible then
        if key = "left" or key = "right" then return true
        return false
    end if
    if key = "OK" then
        if m.terminalError then
            start(true)
            return true
        end if
        if m.next.visible then
            playNext()
            return true
        end if
        if not m.osd.visible then
            showOsd()
            return true
        end if
        if m.bar.hasFocus() then
            m.player.callFunc("togglePlayback", {})
            showOsd()
            return true
        end if
        showOsd()
        return false
    end if
    if key = "up" or key = "down" then
        if u_true(m.info.live) and not m.osd.visible and m.channels.Count() > 1 then
            delta = 1
            if key = "up" then delta = -1
            switchChannel((m.channelIndex + delta + m.channels.Count()) mod m.channels.Count())
            return true
        end if
        if not m.osd.visible then
            showOsd()
            return true
        end if
        showOsd()
        buttons = visibleButtons()
        if key = "down" and m.bar.hasFocus() then
            buttons[0].setFocus(true)
        else if key = "up" and not m.bar.hasFocus() and m.vodRows.visible then
            m.bar.setFocus(true)
        end if
        return true
    end if
    if key = "left" or key = "right" then
        if not m.osd.visible then
            if u_true(m.info.live) and key = "left" and m.channels.Count() > 1 then
                toggleDrawer()
                return true
            end if
            showOsd()
            return true
        end if
        showOsd()
        buttons = visibleButtons()
        at = -1
        for i = 0 to buttons.Count() - 1
            if buttons[i].hasFocus() then at = i
        end for
        if at >= 0 then
            if key = "left" and at > 0 then buttons[at - 1].setFocus(true)
            if key = "right" and at < buttons.Count() - 1 then buttons[at + 1].setFocus(true)
        end if
        return true
    end if
    if key = "options" then
        showOsd()
        return true
    end if
    return true
end function

sub onBack()
    if m.drawer.visible then
        m.drawer.visible = false
        m.top.setFocus(true)
        return
    end if
    if m.osd.visible and not m.terminalError then
        m.osdTimer.control = "stop"
        m.osd.visible = false
        m.top.setFocus(true)
        return
    end if
    closePlayer()
end sub

' Playback events ---------------------------------------------------------------------------------------------------

sub onPlayerEvent(event as object)
    e = event.getData()
    if e = invalid or e.owner <> "player" or m.info = invalid then return
    kind = e.kind
    if kind = "buffering" then
        if not m.terminalError then
            message = "Conectando"
            if e.pct <> invalid or m.prepared then message = "Carregando"
            m.loading.callFunc("showStatus", { message: message, pct: e.pct })
        end if
    else if kind = "ready" then
        m.prepared = true
        m.terminalError = false
        m.loading.callFunc("hideBox", {})
        m.duration = m.player.callFunc("playerDuration", {})
        renderProgress(m.player.callFunc("playerTime", {}))
    else if kind = "retry" then
        m.terminalError = false
        m.loading.callFunc("showStatus", { message: "Reconectando", pct: invalid, extra: "Tentativa " + u_str(e.n) + " de " + u_str(e.max) })
    else if kind = "error" then
        finishSeek(false)
        m.terminalError = true
        m.loading.callFunc("showError", { message: e.message, hint: "OK: tentar novamente · VOLTAR: sair" })
        showOsd(3600)
    else if kind = "ended" then
        handleEnded()
    else if kind = "time" then
        if not u_true(m.info.live) then
            renderProgress(u_num(e.ms))
            saveProgress(false)
        end if
    end if
end sub

sub closePlayer()
    if m.info = invalid then return
    finishSeek(false)
    saveProgress(true)
    m.subtitleRequest = m.subtitleRequest + 1
    stopExternal()
    wasLive = u_true(m.info.live)
    channel = invalid
    if wasLive and m.channelIndex < m.channels.Count() then channel = m.channels[m.channelIndex]
    if not wasLive or not m.keepLive then m.player.callFunc("stopPlayback", {})
    m.info = invalid
    result = {}
    if wasLive and m.keepLive then result.channel = channel
    ui_nav("back", { result: result })
end sub
