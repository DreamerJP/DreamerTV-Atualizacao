' Provider catalog. The provider renumbers categories, moves channels and movies to other servers and
' answers old categories with an empty list, so nothing saved is permanent: categories are compared on
' every opening and channels at most every 10 minutes.
' The task stays alive and answers one request at a time: request {id, cmd, args} -> response {id, cmd, ok, data}.

sub init()
    m.top.functionName = "runLoop"
end sub

sub runLoop()
    port = CreateObject("roMessagePort")
    m.top.observeField("request", port)
    m.file = "cachefs:/catalog.json"
    m.session = { username: "", password: "", serverUrl: "", knownUsers: {} }
    m.memo = { movies: {}, series: {}, episodes: {} }
    m.memoOrder = { movies: [], series: [], episodes: [] }
    m.syncTimes = {}
    cat_loadSaved()
    m.top.ready = true
    while true
        msg = wait(0, port)
        if type(msg) = "roSGNodeEvent" and msg.getField() = "request" then
            req = msg.getData()
            if req <> invalid then
                out = cat_handle(req)
                out.id = req.id
                out.cmd = req.cmd
                m.top.response = out
            end if
        end if
    end while
end sub

function cat_empty() as object
    return { accountKey: "", roots: {}, liveCategories: [], liveChannels: [], created24hCategories: [], created24hChannels: [], movieCategories: [], serieCategories: [] }
end function

sub cat_loadSaved()
    m.data = cat_empty()
    saved = u_readJson(m.file)
    if u_isAA(saved) and u_isAA(saved.roots) then
        for each k in saved
            m.data[k] = saved[k]
        end for
    end if
    m.folded = {}
end sub

sub cat_save()
    u_writeJson(m.file, m.data)
    m.top.revision = m.top.revision + 1
end sub

function cat_ok(data = invalid as dynamic) as object
    return { ok: true, data: data }
end function

function cat_fail(message as string, denied = false as boolean) as object
    return { ok: false, message: message, denied: denied }
end function

function cat_handle(req as object) as object
    args = req.args
    if args = invalid then args = {}
    cmd = req.cmd
    if cmd = "session" then
        m.session = args
        if not u_isAA(m.session.knownUsers) then m.session.knownUsers = {}
        return cat_ok()
    else if cmd = "status" then
        return cat_ok({ accountKey: m.data.accountKey, hasRoots: m.data.roots.Count() > 0 })
    else if cmd = "login" then
        return cat_login(args)
    else if cmd = "logout" then
        m.data = cat_empty()
        m.memo = { movies: {}, series: {}, episodes: {} }
        m.memoOrder = { movies: [], series: [], episodes: [] }
        m.syncTimes = {}
        u_deleteFile(m.file)
        m.top.revision = m.top.revision + 1
        return cat_ok()
    else if cmd = "channels" then
        return cat_channels(u_true(args.is24h), u_true(args.force))
    else if cmd = "syncChannels" then
        return cat_syncChannels(u_true(args.is24h))
    else if cmd = "syncCategories" then
        return cat_syncCategories(u_true(args.series))
    else if cmd = "verifyCategories" then
        return cat_verifyCategories(u_true(args.series))
    else if cmd = "categories" then
        return cat_ok(cat_visibleCategories(u_true(args.series)))
    else if cmd = "items" then
        return cat_items(args)
    else if cmd = "page" then
        return cat_page(args)
    else if cmd = "episodes" then
        return cat_episodes(args)
    else if cmd = "searchChannels" then
        return cat_searchChannels(args)
    else if cmd = "allChannels" then
        return cat_ok(cat_allPlaybackChannels())
    else if cmd = "refreshAll" then
        return cat_refreshAll()
    end if
    return cat_fail("Pedido desconhecido.")
end function

' Network -------------------------------------------------------------------------------------

function cat_endpoint(path as string) as string
    return m.session.serverUrl + "/ssiptv/get/" + u_escape(m.session.username) + "/" + u_escape(m.session.password) + "/" + path
end function

function cat_route(name as string, fallback as string) as string
    source = m.data.roots[name]
    if source = invalid and name = "SÉRIES" then source = m.data.roots["SERIES"]
    if source = invalid then source = cat_endpoint(fallback)
    return pr_refreshUrl(m.session, source)
end function

' Downloads a provider list; 401/403 means the server refused the account.
function cat_fetch(url as string, description as string) as object
    r = u_httpGet(url, 45000, true)
    if r.status = 0 then return { ok: false, message: "Não foi possível carregar " + description + ". Verifique a conexão." }
    if r.status = 401 or r.status = 403 then return { ok: false, denied: true, message: "Acesso recusado pelo servidor." }
    if r.status < 200 or r.status >= 300 then return { ok: false, message: "Não foi possível carregar " + description + " (HTTP " + r.status.ToStr() + ")." }
    if not m3u_looksLikeM3u(r.text) then return { ok: false, message: "O servidor não retornou uma lista válida de " + description + "." }
    return { ok: true, text: r.text }
end function

' Login ---------------------------------------------------------------------------------------

' Credentials replace the saved session only after the server returns the lists.
function cat_login(args as object) as object
    base = u_stripTrailingSlashes(u_str(args.server).Trim())
    if not u_isValidServer(base) then return cat_fail("INVALID_SERVER")
    identity = LCase(base) + "|" + u_str(args.user)
    url = base + "/ssiptv/get/" + u_escape(args.user) + "/" + u_escape(args.pass) + "/download_m3u/"
    r = cat_fetch(url, "catálogo")
    if not r.ok then
        if u_true(r.denied) then return cat_fail(r.message, true)
        if u_true(args.acceptedBefore) and m.data.accountKey = identity and m.data.roots.Count() > 0 then return cat_ok({ offline: true })
        return cat_fail(r.message)
    end if
    roots = m3u_roots(r.text)
    if roots.Count() = 0 then return cat_fail("EMPTY")
    if m.data.accountKey <> identity then
        m.data = cat_empty()
        m.memo = { movies: {}, series: {}, episodes: {} }
        m.memoOrder = { movies: [], series: [], episodes: [] }
        m.syncTimes = {}
    end if
    m.data.accountKey = identity
    m.data.roots = roots
    m.session = { username: args.user, password: args.pass, serverUrl: base, knownUsers: args.knownUsers }
    if not u_isAA(m.session.knownUsers) then m.session.knownUsers = {}
    m.session.knownUsers[args.user] = true
    cat_save()
    return cat_ok({ offline: false })
end function

' Channels ------------------------------------------------------------------------------------

function cat_freshChannels(list as object) as object
    fav = pr_favoriteIds("CHANNEL")
    favSet = {}
    for each id in fav
        favSet[id] = true
    end for
    out = []
    for each c in list
        copy = u_copyAA(c)
        copy.isFavorite = favSet.DoesExist(c.id)
        copy.streamUrl = pr_refreshUrl(m.session, c.streamUrl)
        out.Push(copy)
    end for
    return out
end function

function cat_channelResult(is24h as boolean) as object
    if is24h then return { categories: m.data.created24hCategories, channels: cat_freshChannels(m.data.created24hChannels) }
    return { categories: m.data.liveCategories, channels: cat_freshChannels(m.data.liveChannels) }
end function

function cat_channelUrl(is24h as boolean) as string
    if is24h then return cat_route("24 HORAS", "list_created_channels/")
    return cat_route("CANAIS", "list_lives/")
end function

sub cat_storeChannels(is24h as boolean, parsed as object)
    if is24h then
        m.data.created24hCategories = parsed.categories
        m.data.created24hChannels = parsed.channels
    else
        m.data.liveCategories = parsed.categories
        m.data.liveChannels = parsed.channels
    end if
    m.folded = {}
end sub

function cat_channels(is24h as boolean, force as boolean) as object
    if is24h then current = m.data.created24hChannels else current = m.data.liveChannels
    if current.Count() > 0 and not force then return cat_ok(cat_channelResult(is24h))
    description = "canais"
    if is24h then description = "canais 24h"
    r = cat_fetch(cat_channelUrl(is24h), description)
    if not r.ok then return cat_fail(r.message, u_true(r.denied))
    defaultCategory = "Geral"
    if is24h then defaultCategory = "24 Horas"
    cat_storeChannels(is24h, m3u_channels(r.text, defaultCategory))
    m.syncTimes[u_str(is24h)] = u_now()
    cat_save()
    return cat_ok(cat_channelResult(is24h))
end function

' Returns whether the channel list changed. An empty answer or a failure keeps the saved list.
function cat_syncChannels(is24h as boolean) as object
    key = u_str(is24h)
    last = m.syncTimes[key]
    if last <> invalid and u_now() - last < 600000 then return cat_ok({ changed: false })
    r = cat_fetch(cat_channelUrl(is24h), "canais")
    if not r.ok then return cat_ok({ changed: false })
    m.syncTimes[key] = u_now()
    defaultCategory = "Geral"
    if is24h then defaultCategory = "24 Horas"
    parsed = m3u_channels(r.text, defaultCategory)
    if parsed.channels.Count() = 0 then return cat_ok({ changed: false })
    if is24h then current = m.data.created24hChannels else current = m.data.liveChannels
    if cat_signature(current) = cat_signature(parsed.channels) then return cat_ok({ changed: false })
    cat_storeChannels(is24h, parsed)
    cat_save()
    result = cat_channelResult(is24h)
    result.changed = true
    return cat_ok(result)
end function

' A list read back from the saved file keeps its fields in another order, so lists are compared by content.
function cat_signature(channels as object) as string
    parts = []
    for each c in channels
        parts.Push(u_str(c.id) + Chr(9) + u_str(c.name) + Chr(9) + u_str(c.category) + Chr(9) + u_str(c.streamUrl) + Chr(9) + u_str(c.logo))
    end for
    return parts.Join(Chr(10))
end function

function cat_categorySignature(categories as object) as string
    parts = []
    for each c in categories
        parts.Push(u_str(c.id) + Chr(9) + u_str(c.name) + Chr(9) + u_str(c.url) + Chr(9) + u_str(c.hasContent))
    end for
    return parts.Join(Chr(10))
end function

function cat_allPlaybackChannels() as object
    seen = {}
    out = []
    for each c in m.data.liveChannels
        if not seen.DoesExist(c.id) then
            seen[c.id] = true
            out.Push(c)
        end if
    end for
    for each c in m.data.created24hChannels
        if not seen.DoesExist(c.id) then
            seen[c.id] = true
            out.Push(c)
        end if
    end for
    return cat_freshChannels(out)
end function

function cat_searchChannels(args as object) as object
    key = u_fold(u_str(args.query).Trim())
    if Len(key) < 2 then return cat_ok([])
    offset = u_int(args.offset)
    limit = u_int(args.limit)
    if limit <= 0 then limit = 50
    all = cat_allPlaybackChannels()
    if m.folded.list = invalid or m.folded.count <> all.Count() then
        folded = []
        for each c in all
            folded.Push(u_fold(c.name + " " + c.category))
        end for
        m.folded = { list: folded, count: all.Count() }
    end if
    out = []
    skipped = 0
    for i = 0 to all.Count() - 1
        if out.Count() >= limit then exit for
        if Instr(1, m.folded.list[i], key) > 0 then
            if skipped < offset then
                skipped = skipped + 1
            else
                out.Push(all[i])
            end if
        end if
    end for
    return cat_ok(out)
end function

' Movie and series categories -----------------------------------------------------------------

function cat_ordered(categories as object) as object
    normal = []
    last = []
    re = CreateObject("roRegex", "VER TUDO", "i")
    for each c in categories
        if re.IsMatch(c.name) then last.Push(c) else normal.Push(c)
    end for
    normal.Append(last)
    return normal
end function

function cat_visibleCategories(series as boolean) as object
    if series then list = m.data.serieCategories else list = m.data.movieCategories
    out = []
    for each c in list
        if not u_false(c.hasContent) then out.Push(c)
    end for
    return out
end function

' The saved list stays when the provider fails; unchanged categories keep their content check.
function cat_syncCategories(series as boolean) as object
    if series then
        saved = m.data.serieCategories
        r = cat_fetch(cat_route("SÉRIES", "serie_categories/"), "categorias de séries")
    else
        saved = m.data.movieCategories
        r = cat_fetch(cat_route("FILMES", "movie_categories/"), "categorias de filmes")
    end if
    if not r.ok then
        if saved.Count() = 0 then return cat_fail(r.message, u_true(r.denied))
        return cat_ok(cat_visibleCategories(series))
    end if
    fetched = m3u_categories(r.text)
    if fetched.Count() = 0 and saved.Count() > 0 then return cat_ok(cat_visibleCategories(series))
    checked = {}
    for each c in saved
        checked[c.id + "|" + c.name] = c.hasContent
    end for
    replacement = []
    for each c in cat_ordered(fetched)
        k = c.id + "|" + c.name
        if checked.DoesExist(k) then c.hasContent = checked[k]
        replacement.Push(c)
    end for
    if cat_categorySignature(replacement) <> cat_categorySignature(saved) then
        if series then m.data.serieCategories = replacement else m.data.movieCategories = replacement
        cat_save()
    end if
    return cat_ok(cat_visibleCategories(series))
end function

' Hides categories the provider answers with an empty list. Failed checks keep them visible.
function cat_verifyCategories(series as boolean) as object
    if series then list = m.data.serieCategories else list = m.data.movieCategories
    changed = false
    for each c in list
        if c.hasContent = invalid then
            path = "list_movies/"
            if series then path = "list_series/"
            url = c.url
            if u_str(url) = "" then url = cat_endpoint(path + c.id + "/")
            r = cat_fetch(pr_refreshUrl(m.session, url), "categoria")
            if r.ok then
                c.hasContent = m3u_hasEntries(r.text)
                changed = true
            end if
        end if
    end for
    if changed then cat_save()
    return cat_ok({ changed: changed, categories: cat_visibleCategories(series) })
end function

' Movies and series of a category ---------------------------------------------------------------

sub cat_remember(kind as string, key as string, value as object)
    m.memo[kind][key] = value
    order = []
    for each k in m.memoOrder[kind]
        if k <> key then order.Push(k)
    end for
    order.Push(key)
    limit = 10
    if kind = "episodes" then limit = 30
    while order.Count() > limit
        m.memo[kind].Delete(order.Shift())
    end while
    m.memoOrder[kind] = order
end sub

' {kind: "movies"|"series", category, force} -> first page and total.
function cat_items(args as object) as object
    series = args.kind = "series"
    category = args.category
    key = u_str(category.id)
    list = m.memo[args.kind][key]
    if list = invalid or u_true(args.force) then
        path = "list_movies/"
        description = "filmes"
        if series then
            path = "list_series/"
            description = "séries"
        end if
        url = u_str(category.url)
        if url = "" then url = cat_endpoint(path + key + "/")
        r = cat_fetch(pr_refreshUrl(m.session, url), description)
        if not r.ok then return cat_fail(r.message, u_true(r.denied))
        list = m3u_fillList(r.text, series)
        list.categoryId = key
        list.categoryName = u_str(category.name)
        cat_remember(args.kind, key, list)
    end if
    count = u_int(args.count)
    if count <= 0 then count = 60
    return cat_ok({ key: key, total: list.ids.Count(), items: cat_slice(args.kind, list, 0, count) })
end function

function cat_page(args as object) as object
    list = m.memo[args.kind][u_str(args.key)]
    if list = invalid then return cat_fail("Lista expirada.")
    return cat_ok({ key: args.key, offset: args.offset, items: cat_slice(args.kind, list, u_int(args.offset), u_int(args.count)) })
end function

function cat_slice(kind as string, list as object, offset as integer, count as integer) as object
    series = kind = "series"
    kindName = "MOVIE"
    if series then kindName = "SERIES"
    favSet = {}
    for each id in pr_favoriteIds(kindName)
        favSet[id] = true
    end for
    out = []
    last = offset + count - 1
    if last > list.ids.Count() - 1 then last = list.ids.Count() - 1
    for i = offset to last
        item = m3u_listItem(list, i, series, list.categoryId, list.categoryName)
        item.isFavorite = favSet.DoesExist(item.id)
        if series then
            item.episodesUrl = pr_refreshUrl(m.session, item.episodesUrl)
        else
            item.streamUrl = pr_refreshUrl(m.session, item.streamUrl)
            item.lastPositionMs = pr_savedPosition(item.id, "MOVIE")
        end if
        out.Push(item)
    end for
    return out
end function

function cat_episodes(args as object) as object
    series = args.series
    key = u_str(series.id)
    list = m.memo.episodes[key]
    if list = invalid or u_true(args.force) then
        url = u_str(series.episodesUrl)
        if url = "" then url = cat_endpoint("list_episodes/" + key + "/")
        r = cat_fetch(pr_refreshUrl(m.session, url), "episódios")
        if not r.ok then return cat_fail(r.message, u_true(r.denied))
        list = m3u_episodes(r.text)
        cat_remember("episodes", key, list)
    end if
    out = []
    for each e in list
        copy = u_copyAA(e)
        copy.streamUrl = pr_refreshUrl(m.session, e.streamUrl)
        out.Push(copy)
    end for
    return cat_ok(out)
end function

' Complete replacement, downloaded before touching the saved copy.
function cat_refreshAll() as object
    r = cat_fetch(m.session.serverUrl + "/ssiptv/get/" + u_escape(m.session.username) + "/" + u_escape(m.session.password) + "/download_m3u/", "catálogo")
    if not r.ok then return cat_fail(r.message, u_true(r.denied))
    roots = m3u_roots(r.text)
    if roots.Count() = 0 then return cat_fail("O servidor não retornou o catálogo.")
    old = m.data.roots
    m.data.roots = roots
    live = cat_fetch(cat_route("CANAIS", "list_lives/"), "canais")
    h24 = cat_fetch(cat_route("24 HORAS", "list_created_channels/"), "canais 24h")
    movies = cat_fetch(cat_route("FILMES", "movie_categories/"), "categorias de filmes")
    series = cat_fetch(cat_route("SÉRIES", "serie_categories/"), "categorias de séries")
    if not (live.ok and h24.ok and movies.ok and series.ok) then
        m.data.roots = old
        return cat_fail("Não foi possível atualizar a lista.")
    end if
    liveParsed = m3u_channels(live.text, "Geral")
    h24Parsed = m3u_channels(h24.text, "24 Horas")
    account = m.data.accountKey
    m.data = cat_empty()
    m.data.accountKey = account
    m.data.roots = roots
    m.data.liveCategories = liveParsed.categories
    m.data.liveChannels = liveParsed.channels
    m.data.created24hCategories = h24Parsed.categories
    m.data.created24hChannels = h24Parsed.channels
    m.data.movieCategories = cat_ordered(m3u_categories(movies.text))
    m.data.serieCategories = cat_ordered(m3u_categories(series.text))
    m.memo = { movies: {}, series: {}, episodes: {} }
    m.memoOrder = { movies: [], series: [], episodes: [] }
    m.syncTimes = {}
    m.folded = {}
    cat_save()
    return cat_ok()
end function
