' Full movie and series lists (search, saved items found again, "Dreamer indica"), replaced once a day.
' The old copy stays searchable while a new one downloads. Request {id, cmd, args} -> response {id, cmd, ok, data};
' the recommendation job answers several times with partial = true while it checks the catalog.

sub init()
    m.top.functionName = "runLoop"
end sub

sub runLoop()
    port = CreateObject("roMessagePort")
    m.top.observeField("request", port)
    m.session = { username: "", password: "", serverUrl: "", knownUsers: {} }
    m.files = { movies: "cachefs:/full_movies.m3u", series: "cachefs:/full_series.m3u", meta: "cachefs:/full_meta.json", matches: "cachefs:/matches.json" }
    m.movies = m3u_newList()
    m.series = m3u_newList()
    m.meta = { updatedAt: 0, accountKey: "" }
    m.byName = invalid
    m.job = invalid
    lib_loadSaved()
    m.top.state = lib_initialState()
    while true
        if m.job <> invalid then
            msg = wait(1, port)
        else
            msg = wait(0, port)
        end if
        if type(msg) = "roSGNodeEvent" and msg.getField() = "request" then
            req = msg.getData()
            if req <> invalid then
                out = lib_handle(req)
                if out <> invalid then
                    out.id = req.id
                    out.cmd = req.cmd
                    m.top.response = out
                end if
            end if
        else if m.job <> invalid then
            rec_step()
        end if
    end while
end sub

function lib_initialState() as string
    if m.movies.ids.Count() > 0 then return "ready"
    return "idle"
end function

sub lib_loadSaved()
    meta = u_readJson(m.files.meta)
    if not u_isAA(meta) then return
    moviesText = u_readFile(m.files.movies)
    seriesText = u_readFile(m.files.series)
    if moviesText = "" or seriesText = "" then return
    m.movies = m3u_fillList(moviesText, false)
    m.series = m3u_fillList(seriesText, true)
    m.meta = meta
    m.byName = invalid
end sub

function lib_ok(data = invalid as dynamic) as object
    return { ok: true, data: data }
end function

function lib_fail(message as string) as object
    return { ok: false, message: message }
end function

function lib_handle(req as object) as dynamic
    args = req.args
    if args = invalid then args = {}
    cmd = req.cmd
    if cmd = "session" then
        m.session = args
        if not u_isAA(m.session.knownUsers) then m.session.knownUsers = {}
        key = LCase(m.session.serverUrl) + "|" + m.session.username
        if m.meta.accountKey <> "" and m.meta.accountKey <> key then lib_forget()
        return lib_ok()
    else if cmd = "logout" then
        lib_forget()
        return lib_ok()
    else if cmd = "build" then
        return lib_build(u_true(args.force))
    else if cmd = "state" then
        return lib_ok({ state: m.top.state, movies: m.movies.ids.Count(), series: m.series.ids.Count() })
    else if cmd = "search" then
        return lib_search(args)
    else if cmd = "find" then
        return lib_ok(lib_find(u_str(args.kind), u_str(args.id)))
    else if cmd = "enrich" then
        out = []
        for each item in args.items
            out.Push(lib_enrich(item))
        end for
        return lib_ok(out)
    else if cmd = "inferSeries" then
        return lib_ok(lib_inferSeries(u_str(args.title)))
    else if cmd = "recommendations" then
        return rec_start(req)
    else if cmd = "cancel" then
        m.job = invalid
        return invalid
    end if
    return lib_fail("Pedido desconhecido.")
end function

sub lib_forget()
    m.movies = m3u_newList()
    m.series = m3u_newList()
    m.meta = { updatedAt: 0, accountKey: "" }
    m.byName = invalid
    for each k in ["movies", "series", "meta", "matches"]
        u_deleteFile(m.files[k])
    end for
    m.top.state = "idle"
end sub

function lib_endpoint(path as string) as string
    return m.session.serverUrl + "/ssiptv/get/" + u_escape(m.session.username) + "/" + u_escape(m.session.password) + "/" + path
end function

' Downloads a provider list straight to a file; returns its text or "" after a failure.
function lib_download(url as string, target as string) as string
    temp = target + ".novo"
    u_deleteFile(temp)
    r = u_httpGet(url, 120000, true, temp)
    if r.status < 200 or r.status >= 300 then
        u_deleteFile(temp)
        return ""
    end if
    text = u_readFile(temp)
    if not m3u_looksLikeM3u(text) then
        u_deleteFile(temp)
        return ""
    end if
    fs = CreateObject("roFileSystem")
    u_deleteFile(target)
    fs.Rename(temp, target)
    return text
end function

function lib_build(force as boolean) as object
    available = m.movies.ids.Count() > 0 and m.series.ids.Count() > 0
    if not force and available and u_now() - u_num(m.meta.updatedAt) < 86400000# then
        m.top.state = "ready"
        return lib_ok({ state: "ready", changed: false })
    end if
    if m.session.username = "" then return lib_fail("Sem acesso.")
    if not available then m.top.state = "loading"
    seriesText = lib_download(lib_endpoint("list_series/-1/"), m.files.series)
    moviesText = ""
    if seriesText <> "" then moviesText = lib_download(lib_endpoint("list_movies/-1/"), m.files.movies)
    if seriesText = "" or moviesText = "" then
        if not available then m.top.state = "error"
        return lib_fail("Não foi possível completar o catálogo.")
    end if
    m.series = m3u_fillList(seriesText, true)
    m.movies = m3u_fillList(moviesText, false)
    m.byName = invalid
    m.meta = { updatedAt: u_now(), accountKey: LCase(m.session.serverUrl) + "|" + m.session.username }
    u_writeJson(m.files.meta, m.meta)
    m.top.state = "ready"
    lib_relinkSavedMovies()
    m.top.revision = m.top.revision + 1
    return lib_ok({ state: "ready", changed: true })
end function

function lib_revision() as string
    return u_str(m.meta.accountKey) + "|" + u_str(m.meta.updatedAt)
end function

' Items -----------------------------------------------------------------------------------------

function lib_movieItem(i as integer) as object
    item = m3u_listItem(m.movies, i, false, "-1", "Geral")
    item.streamUrl = pr_refreshUrl(m.session, item.streamUrl)
    item.isFavorite = pr_isFavorite(item.id, "MOVIE")
    item.lastPositionMs = pr_savedPosition(item.id, "MOVIE")
    return item
end function

function lib_seriesItem(i as integer) as object
    item = m3u_listItem(m.series, i, true, "-1", "Geral")
    item.episodesUrl = pr_refreshUrl(m.session, item.episodesUrl)
    item.isFavorite = pr_isFavorite(item.id, "SERIES")
    return item
end function

function lib_find(kind as string, id as string) as dynamic
    if kind = "series" then
        if m.series.index.DoesExist(id) then return lib_seriesItem(m.series.index[id])
    else
        if m.movies.index.DoesExist(id) then return lib_movieItem(m.movies.index[id])
    end if
    return invalid
end function

' Adds poster and series data found in the current catalog to a history entry.
function lib_enrich(item as object) as object
    out = u_copyAA(item)
    if item.mediaType = "EPISODE" or item.mediaType = "SERIES" then
        series = lib_find("series", u_str(item.seriesId))
        if series <> invalid then
            if series.poster <> "" then out.poster = series.poster
            out.seriesTitle = series.title
            out.seriesEpisodesUrl = series.episodesUrl
        end if
    else if item.mediaType = "MOVIE" then
        movie = lib_find("movie", u_str(item.id))
        if movie <> invalid and movie.poster <> "" then out.poster = movie.poster
    end if
    return out
end function

' A history episode without its series: the series is found only by an unambiguous title prefix.
function lib_inferSeries(title as string) as dynamic
    lower = LCase(title)
    best = -1
    bestLength = 0
    ties = 0
    for i = 0 to m.series.ids.Count() - 1
        prefix = LCase(m.series.titles[i]) + " - "
        if Left(lower, Len(prefix)) = prefix then
            if Len(prefix) > bestLength then
                best = i
                bestLength = Len(prefix)
                ties = 1
            else if Len(prefix) = bestLength then
                ties = ties + 1
            end if
        end if
    end for
    if best >= 0 and ties = 1 then return lib_seriesItem(best)
    return invalid
end function

function lib_search(args as object) as object
    key = u_fold(u_str(args.query).Trim())
    result = { movies: [], series: [] }
    if Len(key) < 2 then return lib_ok(result)
    offset = u_int(args.offset)
    limit = u_int(args.limit)
    if limit <= 0 then limit = 50
    kind = u_str(args.type)
    if kind = "" or kind = "MOVIE" then result.movies = lib_searchList(m.movies, key, offset, limit, false)
    if kind = "" or kind = "SERIES" then result.series = lib_searchList(m.series, key, offset, limit, true)
    return lib_ok(result)
end function

function lib_searchList(list as object, key as string, offset as integer, limit as integer, series as boolean) as object
    out = []
    skipped = 0
    for i = 0 to list.ids.Count() - 1
        if out.Count() >= limit then exit for
        if Instr(1, list.folded[i], key) > 0 then
            if skipped < offset then
                skipped = skipped + 1
            else if series then
                out.Push(lib_seriesItem(i))
            else
                out.Push(lib_movieItem(i))
            end if
        end if
    end for
    return out
end function

' Title index of the full movie list, built on demand and kept until the list changes.
sub lib_buildIndex()
    if m.byName <> invalid then return
    byName = {}
    years = []
    for i = 0 to m.movies.ids.Count() - 1
        parsed = identity_parse(m.movies.titles[i])
        years.Push(parsed.year)
        if not byName.DoesExist(parsed.title) then byName[parsed.title] = []
        byName[parsed.title].Push(i)
    end for
    m.byName = byName
    m.movieYears = years
end sub

' Saved movies whose number vanished are found again by title and year. Copies sharing a title differ
' only by the subtitled category, so the copy outside it is preferred.
sub lib_relinkSavedMovies()
    saved = []
    for each h in pr_history()
        if h.mediaType = "MOVIE" then saved.Push([u_str(h.id), u_str(h.title)])
    end for
    for each fav in pr_favoriteMovies()
        saved.Push([u_str(fav.id), u_str(fav.title)])
    end for
    missing = []
    for each s in saved
        if not m.movies.index.DoesExist(s[0]) then missing.Push(s)
    end for
    if missing.Count() = 0 then return
    lib_buildIndex()
    copies = {}
    multiple = false
    for each s in missing
        wanted = identity_parse(s[1])
        found = []
        indices = m.byName[wanted.title]
        if indices <> invalid then
            for each i in indices
                if wanted.year = 0 or m.movieYears[i] = wanted.year then found.Push(i)
            end for
        end if
        if found.Count() > 0 then
            copies[s[0]] = found
            if found.Count() > 1 then multiple = true
        end if
    end for
    if copies.Count() = 0 then return
    subtitled = {}
    if multiple then subtitled = lib_subtitledIds()
    replacements = {}
    for each id in copies
        chosen = copies[id][0]
        for each i in copies[id]
            if not subtitled.DoesExist(m.movies.ids[i]) then
                chosen = i
                exit for
            end if
        end for
        item = lib_movieItem(chosen)
        replacements[id] = item
    end for
    pr_relinkMovies(replacements)
end sub

function lib_subtitledIds() as object
    ids = {}
    catalog = u_readJson("cachefs:/catalog.json")
    url = ""
    if u_isAA(catalog) and u_isAA(catalog.roots) then url = u_str(catalog.roots["FILMES"])
    if url = "" then url = lib_endpoint("movie_categories/")
    r = u_httpGet(pr_refreshUrl(m.session, url), 45000, true)
    if r.status <> 200 then return ids
    for each c in m3u_categories(r.text)
        if Instr(1, identity_normalize(c.name), "legendad") > 0 then
            list = u_httpGet(pr_refreshUrl(m.session, c.url), 45000, true)
            if list.status = 200 then
                filled = m3u_fillList(list.text, false)
                for each id in filled.ids
                    ids[id] = true
                end for
            end if
            exit for
        end if
    end for
    return ids
end function

' "Dreamer indica" ------------------------------------------------------------------------------------

function rec_start(req as object) as dynamic
    m.job = invalid
    feed = dc_loadFeed()
    if feed.films = invalid then return lib_fail("Não foi possível carregar Dreamer indica.")
    ready = m.movies.ids.Count() > 0
    revision = lib_revision()
    cache = u_readJson(m.files.matches)
    if not u_isAA(cache) then cache = {}
    rows = []
    for each film in feed.films
        saved = cache[film.slug + "|" + film.year.ToStr()]
        row = { film: film, availability: "CHECKING", sources: [], candidates: [] }
        if ready and u_isAA(saved) and saved.revision = revision and u_now() - u_num(saved.time) < 86400000# then
            row.availability = saved.availability
            row.sources = rec_items(saved.sources)
            row.candidates = rec_items(saved.candidates)
        end if
        rows.Push(row)
    end for
    m.job = { id: req.id, cmd: req.cmd, rows: rows, next: 0, stale: feed.stale, ready: ready, revision: revision, cache: cache, lastPublish: 0 }
    if ready then lib_buildIndex()
    rec_publish(true)
    if not ready then m.job = invalid
    return invalid
end function

function rec_items(ids as dynamic) as object
    out = []
    if not u_isArray(ids) then return out
    for each id in ids
        item = lib_find("movie", u_str(id))
        if item <> invalid then out.Push(item)
    end for
    return out
end function

sub rec_publish(partial as boolean)
    job = m.job
    pending = 0
    for each row in job.rows
        if row.availability = "CHECKING" then pending = pending + 1
    end for
    page = { films: job.rows, stale: job.stale, catalogReady: job.ready, verifying: job.ready and pending > 0, total: job.rows.Count(), checked: job.rows.Count() - pending }
    m.top.response = { id: job.id, cmd: job.cmd, ok: true, partial: partial, data: page }
    job.lastPublish = u_now()
end sub

' Checks one recommended film per call, so other requests are answered in between.
sub rec_step()
    job = m.job
    while job.next < job.rows.Count() and job.rows[job.next].availability <> "CHECKING"
        job.next = job.next + 1
    end while
    if job.next >= job.rows.Count() then
        for each row in job.rows
            if row.availability = "CHECKING" then row.availability = "UNAVAILABLE"
        end for
        u_writeJson(m.files.matches, job.cache)
        rec_publish(false)
        m.job = invalid
        return
    end if
    row = job.rows[job.next]
    job.next = job.next + 1
    result = rec_resolve(row.film)
    row.availability = result.availability
    row.sources = rec_items(result.sources)
    row.candidates = rec_items(result.candidates)
    if not result.failed then
        job.cache[row.film.slug + "|" + row.film.year.ToStr()] = { revision: job.revision, time: u_now(), availability: result.availability, sources: result.sources, candidates: result.candidates }
    else
        row.availability = "CHECKING"
    end if
    if u_now() - job.lastPublish > 800 then rec_publish(true)
end sub

function rec_candidates(titles as object, year as integer) as object
    seen = {}
    found = []
    for each t in titles
        if u_str(t) <> "" then
            variants = [t]
            main = t.Split(":")[0].Split(" - ")[0].Trim()
            if main <> t and main.Split(" ").Count() >= 2 then variants.Push(main)
            for each v in variants
                indices = m.byName[identity_parse(v).title]
                if indices <> invalid then
                    for each i in indices
                        id = m.movies.ids[i]
                        if not seen.DoesExist(id) and (m.movieYears[i] = 0 or m.movieYears[i] = year) then
                            seen[id] = true
                            found.Push(i)
                        end if
                    end for
                end if
            end for
        end if
    end for
    return found
end function

function rec_ids(indices as object, exactYear as integer) as object
    out = []
    for each i in indices
        if exactYear = 0 or m.movieYears[i] = exactYear then out.Push(m.movies.ids[i])
    end for
    return out
end function

function rec_resolve(film as object) as object
    names = [film.title, film.originalTitle]
    direct = rec_ids(rec_candidates(names, film.year), film.year)
    if direct.Count() > 0 then return { availability: "AVAILABLE", sources: direct, candidates: [], failed: false }
    m.dc_failed = false
    ed = dc_edition(film)
    if ed = invalid then
        if u_true(m.dc_failed) then return { availability: "CHECKING", sources: [], candidates: [], failed: true }
        loose = rec_ids(rec_candidates(names, film.year), 0)
        if loose.Count() > 0 then return { availability: "UNCONFIRMED", sources: [], candidates: loose, failed: false }
        return { availability: "UNAVAILABLE", sources: [], candidates: [], failed: false }
    end if
    named = rec_candidates(ed.titles, film.year)
    dated = rec_ids(named, film.year)
    if dated.Count() > 0 then return { availability: "AVAILABLE", sources: dated, candidates: [], failed: false }
    loose = rec_ids(named, 0)
    if loose.Count() > 0 then return { availability: "UNCONFIRMED", sources: [], candidates: loose, failed: false }
    return { availability: "UNAVAILABLE", sources: [], candidates: [], failed: false }
end function
