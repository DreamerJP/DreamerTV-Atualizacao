sub init()
    m.bg = m.top.findNode("bg")
    m.mark = m.top.findNode("mark")
    m.title = m.top.findNode("title")
    m.small = m.top.findNode("small")
    m.right = m.top.findNode("right")
    m.badgeBg = m.top.findNode("badgeBg")
    m.badge = m.top.findNode("badge")
end sub

sub render()
    c = m.top.itemContent
    if c = invalid then return
    w = m.top.width
    h = m.top.height
    if w <= 0 then w = 400
    if h <= 0 then h = 80
    focused = m.top.focusPercent > 0.5 and (m.top.listHasFocus or m.top.gridHasFocus)
    selected = false
    if c.selected <> invalid then selected = c.selected
    m.bg.width = w
    m.bg.height = h - 4
    m.mark.height = h - 4
    m.mark.visible = selected and not focused
    rightText = ""
    if c.right <> invalid then rightText = c.right
    badgeText = ""
    if c.badge <> invalid then badgeText = c.badge
    smallText = ""
    if c.small <> invalid then smallText = c.small
    rightWidth = 0
    if rightText <> "" then rightWidth = 110
    badgeWidth = 0
    if badgeText <> "" then badgeWidth = 120
    m.title.translation = [24, 0]
    m.title.width = w - 48 - rightWidth - badgeWidth
    m.title.text = c.title
    if smallText <> "" then
        m.title.height = h * 0.6
        m.small.visible = true
        m.small.text = smallText
        m.small.translation = [24, h * 0.56]
        m.small.width = w - 48
    else
        m.title.height = h - 4
        m.small.visible = false
    end if
    m.right.text = rightText
    m.right.width = rightWidth
    m.right.height = h - 4
    m.right.translation = [w - 24 - rightWidth, 0]
    m.badgeBg.visible = badgeText <> ""
    m.badge.text = badgeText
    m.badgeBg.width = badgeWidth - 16
    m.badgeBg.height = 40
    m.badgeBg.translation = [w - 24 - rightWidth - badgeWidth + 16, (h - 44) / 2]
    m.badge.width = badgeWidth - 16
    m.badge.height = 40
    if focused then
        m.bg.color = "0xFFFFFFFF"
        m.title.color = "0x0B0B0BFF"
        m.right.color = "0x303030FF"
        m.small.color = "0x303030FF"
    else if selected then
        m.bg.color = "0x303030FF"
        m.title.color = "0xFFFFFFFF"
        m.right.color = "0xC4C4C4FF"
        m.small.color = "0xC4C4C4FF"
    else
        m.bg.color = "0x00000000"
        m.title.color = "0xF5F5F5FF"
        m.right.color = "0xA3A3A3FF"
        m.small.color = "0xA3A3A3FF"
    end if
end sub
