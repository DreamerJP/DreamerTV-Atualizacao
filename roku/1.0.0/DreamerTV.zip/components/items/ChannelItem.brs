sub init()
    m.bg = m.top.findNode("bg")
    m.mark = m.top.findNode("mark")
    m.number = m.top.findNode("number")
    m.logo = m.top.findNode("logo")
    m.name = m.top.findNode("name")
    m.star = m.top.findNode("star")
    m.lastLogo = ""
end sub

sub render()
    c = m.top.itemContent
    if c = invalid then return
    w = m.top.width
    h = m.top.height
    if w <= 0 then w = 620
    if h <= 0 then h = 88
    focused = m.top.focusPercent > 0.5 and (m.top.listHasFocus or m.top.gridHasFocus)
    selected = false
    if c.selected <> invalid then selected = c.selected
    fav = false
    if c.fav <> invalid then fav = c.fav
    m.bg.width = w
    m.bg.height = h - 4
    m.mark.height = h - 4
    m.mark.visible = selected and not focused
    m.number.height = h - 4
    m.number.translation = [0, 0]
    number = 0
    if c.number <> invalid then number = c.number
    text = number.ToStr()
    while Len(text) < 3
        text = "0" + text
    end while
    m.number.text = text
    m.logo.translation = [86, (h - 4 - 56) / 2]
    logo = ""
    if c.logo <> invalid then logo = c.logo
    if logo <> m.lastLogo then
        m.lastLogo = logo
        m.logo.uri = logo
    end if
    m.logo.visible = logo <> ""
    m.name.translation = [186, 0]
    m.name.width = w - 186 - 60
    m.name.height = h - 4
    m.name.text = c.title
    m.star.visible = fav
    m.star.translation = [w - 48, (h - 4 - 32) / 2]
    if focused then
        m.bg.color = "0xDDDDDDFF"
        m.name.color = "0x0B0B0BFF"
        m.number.color = "0x0B0B0BFF"
        m.star.blendColor = "0x0B0B0BFF"
    else if selected then
        m.bg.color = "0x303030FF"
        m.name.color = "0xFFFFFFFF"
        m.number.color = "0xC4C4C4FF"
        m.star.blendColor = "0xFFFFFFFF"
    else
        m.bg.color = "0x1B1B1BFF"
        m.name.color = "0xF5F5F5FF"
        m.number.color = "0xC4C4C4FF"
        m.star.blendColor = "0xFFFFFFFF"
    end if
end sub
