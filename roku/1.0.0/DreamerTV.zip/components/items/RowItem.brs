sub init()
    m.channel = m.top.findNode("channel")
    m.poster = m.top.findNode("poster")
end sub

sub render()
    c = m.top.itemContent
    if c = invalid then return
    isChannel = c.kind = "channel"
    target = m.poster
    other = m.channel
    if isChannel then
        target = m.channel
        other = m.poster
    end if
    other.visible = false
    target.visible = true
    target.width = m.top.width
    target.height = m.top.height
    target.listHasFocus = m.top.rowListHasFocus
    target.focusPercent = m.top.focusPercent
    target.itemContent = c
end sub
