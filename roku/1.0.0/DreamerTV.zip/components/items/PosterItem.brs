sub init()
    m.border = m.top.findNode("border")
    m.fill = m.top.findNode("fill")
    m.imageBg = m.top.findNode("imageBg")
    m.placeholder = m.top.findNode("placeholder")
    m.poster = m.top.findNode("poster")
    m.progressBg = m.top.findNode("progressBg")
    m.progress = m.top.findNode("progress")
    m.favBg = m.top.findNode("favBg")
    m.title = m.top.findNode("title")
    m.sub = m.top.findNode("sub")
    m.lastUri = invalid
    m.poster.observeField("loadStatus", "onPosterLoad")
end sub

sub onPosterLoad()
    m.placeholder.visible = m.poster.loadStatus <> "ready"
end sub

sub render()
    c = m.top.itemContent
    if c = invalid then return
    w = m.top.width
    h = m.top.height
    if w <= 0 then w = 260
    if h <= 0 then h = 500
    focused = m.top.focusPercent > 0.5 and (m.top.listHasFocus or m.top.gridHasFocus)
    borderSize = 2
    if focused then borderSize = 5
    m.border.width = w
    m.border.height = h
    m.fill.translation = [borderSize, borderSize]
    m.fill.width = w - borderSize * 2
    m.fill.height = h - borderSize * 2
    imageW = w - 24
    imageH = Int(imageW * 1.5)
    m.imageBg.translation = [12, 12]
    m.imageBg.width = imageW
    m.imageBg.height = imageH
    m.poster.translation = [12, 12]
    m.poster.width = imageW
    m.poster.height = imageH
    m.poster.loadWidth = imageW
    m.poster.loadHeight = imageH
    uri = ""
    if c.poster <> invalid then uri = c.poster
    if m.lastUri = invalid or uri <> m.lastUri then
        m.lastUri = uri
        m.poster.uri = uri
    end if
    m.placeholder.translation = [12 + (imageW - 80) / 2, 12 + (imageH - 80) / 2]
    m.placeholder.visible = uri = "" or m.poster.loadStatus <> "ready"
    dimmed = false
    if c.dim <> invalid then dimmed = c.dim
    if dimmed then m.poster.opacity = 0.35 else m.poster.opacity = 1
    progress = -1
    if c.progress <> invalid then progress = c.progress
    m.progressBg.visible = progress >= 0
    m.progressBg.translation = [12, 12 + imageH - 12]
    m.progressBg.width = imageW
    m.progress.width = imageW * progress / 100
    fav = false
    if c.fav <> invalid then fav = c.fav
    m.favBg.visible = fav
    m.favBg.translation = [12 + imageW - 56, 20]
    m.title.translation = [12, imageH + 20]
    m.title.width = imageW
    m.title.height = 56
    m.title.text = c.title
    subText = ""
    if c.sub <> invalid then subText = c.sub
    muted = false
    if c.subMuted <> invalid then muted = c.subMuted
    m.sub.visible = subText <> ""
    m.sub.text = subText
    m.sub.translation = [12, imageH + 76]
    m.sub.width = imageW
    if muted then m.sub.color = "0xA3A3A3FF" else m.sub.color = "0xFFFFFFFF"
    if focused then
        m.border.color = "0xFFFFFFFF"
        m.fill.color = "0x303030FF"
    else
        m.border.color = "0x3A3A3AFF"
        m.fill.color = "0x1B1B1BFF"
    end if
end sub
