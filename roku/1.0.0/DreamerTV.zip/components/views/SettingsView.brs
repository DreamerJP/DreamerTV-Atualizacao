' Ajustes: list refresh, playback, storage and account. UP/DOWN move inside a section, LEFT returns to the
' section list.

sub init()
    m.navGroup = m.top.findNode("nav")
    m.panelsGroup = m.top.findNode("panels")
    m.sectionTitle = m.top.findNode("sectionTitle")
    m.sectionDesc = m.top.findNode("sectionDesc")
    m.info = {
        content: ["Lista de conteúdo", "Mantenha seu catálogo atualizado."],
        playback: ["Reprodução", "Escolha como o aplicativo mostra os vídeos."],
        storage: ["Armazenamento", "Consulte o espaço usado e limpe os temporários."],
        account: ["Conta e aplicativo", "Acesso, inicialização e informações do DreamerTV."]
    }
    m.order = ["content", "playback", "storage", "account"]
    m.navButtons = {}
    y = 0
    for each key in m.order
        b = ui_btn(m.info[key][0], 420, 88)
        b.name = key
        b.translation = [0, y]
        b.observeField("pressed", "onNavPressed")
        m.navGroup.appendChild(b)
        m.navButtons[key] = b
        y = y + 104
    end for
    m.panels = {}
    m.panelButtons = {}
    buildPanels()
    m.section = "content"
    show("content", false)
end sub

function addBox(panel as object, y as float, height as float, title as string) as object
    r = CreateObject("roSGNode", "Rectangle")
    r.color = "0x1B1B1BFF"
    r.width = 1300
    r.height = height
    r.translation = [0, y]
    panel.appendChild(r)
    if title <> "" then
        t = ui_label(title, 30, "0xFFFFFFFF", true)
        t.translation = [32, 24]
        r.appendChild(t)
    end if
    return r
end function

function addText(parent as object, value as string, x as float, y as float, width as float, size = 26 as integer, color = "0xC4C4C4FF" as string) as object
    l = ui_label(value, size, color)
    l.translation = [x, y]
    l.width = width
    l.wrap = true
    l.maxLines = 6
    parent.appendChild(l)
    return l
end function

function addButton(parent as object, panelKey as string, name as string, label as string, x as float, y as float, width as float) as object
    b = ui_btn(label, width, 80)
    b.name = name
    b.translation = [x, y]
    b.observeField("pressed", "onAction")
    parent.appendChild(b)
    m.panelButtons[panelKey].Push(b)
    return b
end function

sub buildPanels()
    for each key in m.order
        g = CreateObject("roSGNode", "Group")
        g.visible = false
        m.panelsGroup.appendChild(g)
        m.panels[key] = g
        m.panelButtons[key] = []
    end for

    p = m.panels.content
    b1 = addBox(p,0, 300, "Atualizar sua lista")
    addText(b1, "Busque novos canais, filmes e séries. Se a conexão falhar, sua lista atual será mantida.", 32, 74, 1236)
    m.refreshBtn = addButton(b1, "content", "refresh", "Atualizar canais, filmes e séries", 32, 150, 620)
    addText(b1, "Seu acesso, favoritos e histórico são preservados.", 32, 246, 1236, 22, "0xA3A3A3FF")
    b2 = addBox(p,320, 420, "Categorias de canais")
    m.layoutText = addText(b2, "", 32, 74, 1236)
    m.layoutBtn = addButton(b2, "content", "resetLayout", "Restaurar ordem padrão", 32, 270, 520)
    addText(b2, "Para fixar ou ocultar, aperte * no controle sobre a categoria em TV ao vivo ou 24 horas.", 32, 366, 1236, 22, "0xA3A3A3FF")

    p = m.panels.playback
    b3 = addBox(p,0, 170, "Relógio no vídeo")
    addText(b3, "Mostra a hora junto aos controles durante a reprodução.", 32, 74, 900)
    m.clockBtn = addButton(b3, "playback", "clock", "", 980, 45, 280)

    p = m.panels.storage
    b4 = addBox(p,0, 330, "Espaço usado")
    m.storageText = addText(b4, "Consultando o espaço usado…", 32, 74, 1236)
    addButton(b4, "storage", "clear", "Limpar arquivos temporários", 32, 140, 560)
    addText(b4, "Remove sinopses e recomendações guardadas. Seu catálogo, acesso, favoritos e histórico são mantidos.", 32, 240, 1236, 22, "0xA3A3A3FF")

    p = m.panels.account
    b5 = addBox(p,0, 170, "Abrir no último canal")
    addText(b5, "Ao abrir o DreamerTV, inicia o último canal assistido em tela cheia.", 32, 74, 900)
    m.autoBtn = addButton(b5, "account", "autoBoot", "", 980, 45, 280)
    b6 = addBox(p,190, 270, "Aplicativo")
    m.versionText = addText(b6, "", 32, 74, 1236)
    addText(b6, "Informações de filmes e séries: TMDB." + Chr(10) + "This product uses the TMDB API but is not endorsed or certified by TMDB.", 32, 180, 1236, 20, "0x8A8A8AFF")
    b7 = addBox(p,480, 280, "Sua conta")
    m.accountText = addText(b7, "", 32, 74, 1236)
    addButton(b7, "account", "logout", "Desconectar", 32, 170, 320)
end sub

function showView(params = invalid as dynamic) as boolean
    update()
    if m.section = "storage" then updateStorage()
    return true
end function

function hideView(params = invalid as dynamic) as boolean
    return true
end function

function focusView(params = invalid as dynamic) as boolean
    m.navButtons[m.section].setFocus(true)
    return true
end function

function returnToView(result = invalid as dynamic) as boolean
    update()
    return true
end function

sub show(key as string, focusPanel as boolean)
    m.section = key
    for each k in m.order
        m.panels[k].visible = k = key
        m.navButtons[k].selected = k = key
    end for
    m.sectionTitle.text = m.info[key][0]
    m.sectionDesc.text = m.info[key][1]
    if key = "storage" then updateStorage()
    if focusPanel then
        first = firstEnabled(key)
        if first <> invalid then first.setFocus(true)
    end if
end sub

function firstEnabled(key as string) as dynamic
    for each b in m.panelButtons[key]
        if not b.disabled then return b
    end for
    return invalid
end function

sub onNavPressed(event as object)
    show(event.getRoSGNode().name, true)
end sub

sub update()
    s = pr_settings()
    setToggle(m.clockBtn, u_true(s.showClock))
    setToggle(m.autoBtn, u_true(s.autoBoot))
    m.versionText.text = "DreamerTV " + cfg_version() + " para Roku" + updateLine()
    updateLayout()
    c = pr_credentials()
    m.accountText.text = "Usuário conectado: " + u_str(c.username) + Chr(10) + "Servidor: " + u_str(c.serverUrl)
    u_trace("settings", { clock: m.clockBtn.text, autoBoot: m.autoBtn.text, version: m.versionText.text })
end sub

sub setToggle(b as object, value as boolean)
    if value then b.text = "Ativado" else b.text = "Desativado"
    b.selected = value
end sub

function updateLine() as string
    info = m.global.updateInfo
    if info = invalid or info.published = invalid then return ""
    if u_true(info.newer) then return Chr(10) + "Versão nova disponível: " + u_str(info.published) + ". Instale pelo Instalar.bat no computador."
    return Chr(10) + "Esta é a versão mais recente."
end function

' Pinned and hidden categories per list; a name missing from the current list is marked.
sub updateLayout()
    m.layoutLines = []
    rq_send(m.global.catalog, "channels", { is24h: false }, onLiveForLayout)
end sub

sub onLiveForLayout(response as object)
    m.liveNames = []
    if response.ok then
        for each c in response.data.categories
            m.liveNames.Push(cl_norm(c.name))
        end for
    end if
    rq_send(m.global.catalog, "channels", { is24h: true }, on24hForLayout)
end sub

sub on24hForLayout(response as object)
    names24 = []
    if response.ok then
        for each c in response.data.categories
            names24.Push(cl_norm(c.name))
        end for
    end if
    lines = []
    for each list in [["live", "TV ao vivo", m.liveNames], ["24h", "24 horas", names24]]
        l = cl_get(list[0])
        present = list[2]
        if l.pins.Count() > 0 then lines.Push(list[1] + ", fixadas: " + describe(l.pins, present))
        if l.hidden.Count() > 0 then lines.Push(list[1] + ", ocultas: " + describe(l.hidden, present))
    end for
    if lines.Count() > 0 then
        m.layoutText.text = lines.Join(Chr(10))
    else
        m.layoutText.text = "Nenhuma categoria fixada ou oculta."
    end if
    m.layoutBtn.disabled = lines.Count() = 0
    u_trace("layout", { text: m.layoutText.text })
end sub

function describe(names as object, present as object) as string
    parts = []
    for each n in names
        label = n
        if present.Count() > 0 and u_indexOf(present, cl_norm(n)) < 0 then label = n + " (fora da lista atual)"
        parts.Push(label)
    end for
    return parts.Join(", ")
end function

sub updateStorage()
    rq_send(m.global.net, "storage", {}, onStorage)
end sub

sub onStorage(response as object)
    if not response.ok then
        m.storageText.text = "Não foi possível consultar o espaço usado."
        return
    end if
    mb = Int(u_num(response.data.bytes) / 1048576 + 0.5)
    m.storageText.text = "Catálogo e dados salvos: " + mb.ToStr() + " MB"
end sub

sub onAction(event as object)
    name = event.getRoSGNode().name
    if name = "refresh" then
        refresh()
    else if name = "resetLayout" then
        cl_reset("live")
        cl_reset("24h")
        updateLayout()
        ui_toast("Categorias na ordem padrão")
        m.refreshBtn.setFocus(true)
    else if name = "clock" then
        pr_setSetting("showClock", not u_true(pr_settings().showClock))
        update()
    else if name = "autoBoot" then
        pr_setSetting("autoBoot", not u_true(pr_settings().autoBoot))
        update()
    else if name = "clear" then
        rq_send(m.global.net, "clearCaches", {}, onCleared)
    else if name = "logout" then
        ui_choose("Desconectar desta conta?", "Para assistir novamente, será preciso informar os dados de acesso.", [{ label: "Cancelar", primary: true }, { label: "Desconectar" }], onLogoutChoice)
    end if
end sub

sub refresh()
    if m.refreshBtn.disabled then return
    m.refreshBtn.disabled = true
    m.refreshBtn.text = "Atualizando lista…"
    rq_send(m.global.catalog, "refreshAll", {}, onRefreshed)
end sub

sub onRefreshed(response as object)
    if not response.ok then
        finishRefresh("Não foi possível atualizar. O catálogo anterior foi mantido.", 4)
        return
    end if
    rq_send(m.global.library, "build", { force: true }, onRebuilt)
end sub

sub onRebuilt(response as object)
    rq_send(m.global.net, "invalidate", {}, invalid)
    if response.ok then
        finishRefresh("Lista atualizada com sucesso!", 2.6)
    else
        finishRefresh("Não foi possível atualizar. O catálogo anterior foi mantido.", 4)
    end if
end sub

sub finishRefresh(message as string, seconds as float)
    ui_toast(message, seconds)
    m.refreshBtn.disabled = false
    m.refreshBtn.text = "Atualizar canais, filmes e séries"
end sub

sub onCleared(response as object)
    updateStorage()
    ui_toast("Temporários limpos. Seu catálogo foi preservado.")
end sub

sub onLogoutChoice(index as integer)
    if index <> 1 then return
    m.global.player.callFunc("stopPlayback", {})
    rq_send(m.global.library, "logout", {}, invalid)
    rq_send(m.global.catalog, "logout", {}, onLoggedOut)
end sub

sub onLoggedOut(response as object)
    pr_clearAuth()
    ui_nav("login")
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    navIndex = -1
    for i = 0 to m.order.Count() - 1
        if m.navButtons[m.order[i]].hasFocus() then navIndex = i
    end for
    if navIndex >= 0 then
        if key = "down" and navIndex < m.order.Count() - 1 then
            m.navButtons[m.order[navIndex + 1]].setFocus(true)
            return true
        end if
        if key = "up" and navIndex > 0 then
            m.navButtons[m.order[navIndex - 1]].setFocus(true)
            return true
        end if
        if key = "right" then
            show(m.order[navIndex], true)
            return true
        end if
        return false
    end if
    buttons = m.panelButtons[m.section]
    at = -1
    for i = 0 to buttons.Count() - 1
        if buttons[i].hasFocus() then at = i
    end for
    if at < 0 then return false
    if key = "left" then
        m.navButtons[m.section].setFocus(true)
        return true
    end if
    if key = "down" or key = "up" then
        stepBy = 1
        if key = "up" then stepBy = -1
        i = at + stepBy
        while i >= 0 and i < buttons.Count()
            if not buttons[i].disabled then
                buttons[i].setFocus(true)
                return true
            end if
            i = i + stepBy
        end while
        if key = "up" then return false
        return true
    end if
    if key = "back" then
        m.navButtons[m.section].setFocus(true)
        return true
    end if
    return false
end function
