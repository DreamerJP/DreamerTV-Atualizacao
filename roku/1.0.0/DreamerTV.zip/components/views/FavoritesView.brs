' Favorite channels, movies and series. "*" removes the item from the favorites.

sub init()
    m.rows = m.top.findNode("rows")
    m.empty = m.top.findNode("empty")
    m.rows.observeField("rowItemSelected", "onSelected")
    m.sections = []
    m.channels = []
end sub

function showView(params = invalid as dynamic) as boolean
    rq_send(m.global.catalog, "allChannels", {}, onChannels)
    return true
end function

function hideView(params = invalid as dynamic) as boolean
    return true
end function

function focusView(params = invalid as dynamic) as boolean
    if m.rows.visible then
        m.rows.setFocus(true)
    else
        ' The favorites are still loading: the rows take the focus as soon as they appear.
        m.focusWhenReady = true
    end if
    return true
end function

function returnToView(result = invalid as dynamic) as boolean
    rq_send(m.global.catalog, "allChannels", {}, onChannels)
    return true
end function

sub onChannels(response as object)
    m.channels = []
    if response.ok then
        ids = pr_favoriteIds("CHANNEL")
        for each c in response.data
            if u_indexOf(ids, c.id) >= 0 then
                c.isFavorite = true
                m.channels.Push(c)
            end if
        end for
    end if
    render()
end sub

sub render()
    focusRow = 0
    focusCol = 0
    hadFocus = m.rows.hasFocus()
    if hadFocus and m.rows.rowItemFocused <> invalid and m.rows.rowItemFocused.Count() = 2 then
        focusRow = m.rows.rowItemFocused[0]
        focusCol = m.rows.rowItemFocused[1]
    end if
    movies = pr_favoriteMovies()
    shows = pr_favoriteSeries()
    m.sections = []
    rows = []
    sizes = []
    heights = []
    if m.channels.Count() > 0 then
        m.sections.Push({ kind: "channel", items: m.channels })
        rows.Push({ title: "CANAIS FAVORITOS", kind: "channel", items: m.channels })
        sizes.Push([440, 92])
        heights.Push(170)
    end if
    if movies.Count() > 0 then
        cards = []
        for each mv in movies
            cards.Push({ title: mv.title, poster: mv.poster, fav: true })
        end for
        m.sections.Push({ kind: "movie", items: movies })
        rows.Push({ title: "FILMES FAVORITOS", kind: "poster", items: cards })
        sizes.Push([219, 406])
        heights.Push(480)
    end if
    if shows.Count() > 0 then
        cards = []
        for each s in shows
            cards.Push({ title: s.title, poster: s.poster, fav: true })
        end for
        m.sections.Push({ kind: "series", items: shows })
        rows.Push({ title: "SÉRIES & NOVELAS FAVORITAS", kind: "poster", items: cards })
        sizes.Push([219, 406])
        heights.Push(480)
    end if
    if rows.Count() = 0 then
        m.rows.visible = false
        m.empty.visible = true
        return
    end if
    m.empty.visible = false
    m.rows.visible = true
    m.rows.rowItemSize = sizes
    m.rows.rowHeights = heights
    m.rows.rowItemSpacing = [[20, 0]]
    m.rows.content = ui_rowContent(rows)
    u_trace("favorites", { channels: m.channels.Count(), movies: movies.Count(), series: shows.Count() })
    if u_true(m.focusWhenReady) then
        m.focusWhenReady = false
        m.rows.setFocus(true)
    else if hadFocus then
        if focusRow >= rows.Count() then focusRow = rows.Count() - 1
        count = m.sections[focusRow].items.Count()
        if focusCol >= count then focusCol = count - 1
        m.rows.jumpToRowItem = [focusRow, focusCol]
        m.rows.setFocus(true)
    end if
end sub

sub onSelected()
    sel = m.rows.rowItemSelected
    if sel = invalid or sel.Count() < 2 then return
    section = m.sections[sel[0]]
    item = section.items[sel[1]]
    if section.kind = "channel" then
        ui_nav("open", { screen: "PlayerScreen", live: true, channel: item, channels: m.channels })
    else if section.kind = "movie" then
        ui_nav("open", { screen: "DetailsScreen", movie: item })
    else
        ui_nav("open", { screen: "DetailsScreen", series: item })
    end if
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    if key = "options" and m.rows.hasFocus() then
        f = m.rows.rowItemFocused
        if f = invalid or f.Count() < 2 then return true
        section = m.sections[f[0]]
        item = section.items[f[1]]
        if section.kind = "channel" then
            pr_toggleFavorite(item.id, "CHANNEL")
            newList = []
            for each c in m.channels
                if c.id <> item.id then newList.Push(c)
            end for
            m.channels = newList
        else if section.kind = "movie" then
            pr_toggleFavoriteMovie(item)
        else
            pr_toggleFavoriteSeries(item)
        end if
        ui_toast("Removido dos Favoritos")
        render()
        return true
    end if
    return false
end function
