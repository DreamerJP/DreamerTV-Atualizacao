' Filmes and Séries: provider categories plus "Continuar assistindo" and, for movies, "Dreamer indica".
' Big categories arrive in pages while the grid is scrolled.

sub init()
    m.cats = m.top.findNode("cats")
    m.grid = m.top.findNode("grid")
    m.title = m.top.findNode("title")
    m.summary = m.top.findNode("summary")
    m.loadingText = m.top.findNode("loadingText")
    m.cats.observeField("itemSelected", "onCategorySelected")
    m.grid.observeField("itemSelected", "onItemSelected")
    m.grid.observeField("itemFocused", "onItemFocused")
    m.CONTINUE = "continue_watching"
    m.PICKS = "dreamer_recommendations"
    m.categories = []
    m.list = []
    m.selected = ""
    m.request = 0
    m.items = []
    m.mode = ""
    m.total = 0
    m.listKey = ""
    m.paging = false
    m.active = false
    m.rows = []
end sub

function listKind() as string
    if m.top.series then return "series"
    return "movies"
end function

function showView(params = invalid as dynamic) as boolean
    m.active = true
    rq_send(m.global.catalog, "categories", { series: m.top.series }, onSavedCategories)
    return true
end function

function hideView(params = invalid as dynamic) as boolean
    m.active = false
    if m.mode = "picks" then rq_send(m.global.library, "cancel", {}, invalid)
    return true
end function

function focusView(params = invalid as dynamic) as boolean
    m.cats.setFocus(true)
    return true
end function

function returnToView(result = invalid as dynamic) as boolean
    m.active = true
    if m.selected = m.CONTINUE then renderHistory()
    return true
end function

' Categories ----------------------------------------------------------------------------------------

sub onSavedCategories(response as object)
    if response.ok then m.categories = response.data
    renderCategories(true)
    rq_send(m.global.catalog, "syncCategories", { series: m.top.series }, onSyncedCategories)
end sub

sub onSyncedCategories(response as object)
    if not m.active then return
    if not response.ok then
        ui_toast("Não foi possível carregar as categorias. Tente novamente.")
        return
    end if
    m.categories = response.data
    renderCategories(false)
    rq_send(m.global.catalog, "verifyCategories", { series: m.top.series }, onVerified)
end sub

sub onVerified(response as object)
    if not m.active or not response.ok or not u_true(response.data.changed) then return
    m.categories = response.data.categories
    renderCategories(false)
end sub

function displayName(c as object) as string
    if m.top.series then return category_seriesName(c.name)
    return category_movieName(c.name)
end function

sub renderCategories(reload as boolean)
    list = [{ id: m.CONTINUE, name: "Continuar assistindo" }]
    if not m.top.series then list.Push({ id: m.PICKS, name: "Dreamer indica" })
    list.Append(m.categories)
    focusedId = ""
    if m.cats.hasFocus() and m.cats.itemFocused >= 0 and m.cats.itemFocused < m.list.Count() then focusedId = m.list[m.cats.itemFocused].id
    m.list = list
    active = invalid
    for each c in list
        if c.id = m.selected then active = c
    end for
    if active = invalid then active = list[0]
    rows = []
    focusIndex = 0
    for i = 0 to list.Count() - 1
        c = list[i]
        name = c.name
        if c.id <> m.CONTINUE and c.id <> m.PICKS then name = displayName(c)
        rows.Push({ title: name, selected: c.id = active.id })
        if c.id = focusedId then focusIndex = i
    end for
    m.cats.content = ui_textContent(rows)
    if focusedId <> "" then m.cats.jumpToItem = focusIndex
    if reload or m.selected <> active.id then selectCategory(active, false)
end sub

sub onCategorySelected()
    index = m.cats.itemSelected
    if index < 0 or index >= m.list.Count() then return
    selectCategory(m.list[index], true)
end sub

sub markCategory(id as string)
    content = m.cats.content
    if content = invalid then return
    for i = 0 to m.list.Count() - 1
        content.getChild(i).selected = m.list[i].id = id
    end for
end sub

sub setSummary(text as string)
    m.summary.text = text
    m.summary.visible = text <> ""
end sub

sub selectCategory(c as object, fromClick as boolean)
    m.request = m.request + 1
    if m.mode = "picks" then rq_send(m.global.library, "cancel", {}, invalid)
    m.selected = c.id
    markCategory(c.id)
    if c.id = m.PICKS then
        m.title.text = "Dreamer indica"
    else if c.id = m.CONTINUE then
        m.title.text = "CONTINUAR ASSISTINDO"
    else
        m.title.text = UCase(displayName(c))
    end if
    setSummary("")
    if c.id = m.CONTINUE then
        renderHistory()
        return
    end if
    if c.id = m.PICKS then
        renderRecommendations()
        return
    end if
    m.mode = "list"
    m.items = []
    m.total = 0
    m.paging = false
    m.grid.content = CreateObject("roSGNode", "ContentNode")
    m.loadingText.visible = true
    mine = m.request
    m.pendingRequest = mine
    rq_send(m.global.catalog, "items", { kind: listKind(), category: c, count: 60 }, onItems)
    u_trace("vodCategory", { kind: listKind(), name: c.name })
end sub

function cardOf(item as object) as object
    return { title: item.title, poster: item.poster, fav: u_true(item.isFavorite) }
end function

sub onItems(response as object)
    if m.pendingRequest <> m.request then return
    m.loadingText.visible = false
    if not response.ok then
        if m.top.series then ui_toast("Não foi possível carregar as séries. Tente novamente.") else ui_toast("Não foi possível carregar os filmes. Tente novamente.")
        return
    end if
    m.items = response.data.items
    m.total = response.data.total
    m.listKey = response.data.key
    root = CreateObject("roSGNode", "ContentNode")
    cards = []
    for each item in m.items
        cards.Push(cardOf(item))
    end for
    ui_appendPosters(root, cards)
    m.grid.content = root
    if m.total = 0 then setSummary("Nenhum título nesta categoria.")
    u_trace("vodItems", { total: m.total, shown: m.items.Count() })
end sub

' Loads the next page when the focus gets close to the end of what is loaded.
sub onItemFocused()
    if m.mode <> "list" or m.paging then return
    if m.items.Count() >= m.total then return
    if m.grid.itemFocused < m.items.Count() - 18 then return
    m.paging = true
    m.pageRequest = m.request
    rq_send(m.global.catalog, "page", { kind: listKind(), key: m.listKey, offset: m.items.Count(), count: 60 }, onPage)
end sub

sub onPage(response as object)
    m.paging = false
    if m.pageRequest <> m.request or not response.ok then return
    cards = []
    for each item in response.data.items
        m.items.Push(item)
        cards.Push(cardOf(item))
    end for
    ui_appendPosters(m.grid.content, cards)
end sub

sub onItemSelected()
    index = m.grid.itemSelected
    if index < 0 or index >= m.items.Count() then return
    item = m.items[index]
    if m.mode = "history" then
        ui_nav("open", { screen: "DetailsScreen", history: item })
    else if m.mode = "picks" then
        ui_nav("open", { screen: "DetailsScreen", recommendation: m.rows[index], catalogReady: m.catalogReady })
    else if m.top.series then
        ui_nav("open", { screen: "DetailsScreen", series: item })
    else
        ui_nav("open", { screen: "DetailsScreen", movie: item })
    end if
end sub

' "*" on a card: favorite, or remove it from "Continuar assistindo".
sub onOptions()
    index = m.grid.itemFocused
    if index < 0 or index >= m.items.Count() then return
    item = m.items[index]
    if m.mode = "history" then
        if m.top.series then
            pr_removeSeriesHistory(item)
            ui_toast("Série removida de Continuar Assistindo")
        else
            pr_removeHistory(item.id, item.mediaType)
            ui_toast(item.title + " removido de Continuar Assistindo")
        end if
        renderHistory()
        return
    end if
    if m.mode <> "list" then return
    if m.top.series then added = pr_toggleFavoriteSeries(item) else added = pr_toggleFavoriteMovie(item)
    item.isFavorite = added
    m.grid.content.getChild(index).fav = added
    if added then ui_toast("Adicionado aos Favoritos") else ui_toast("Removido dos Favoritos")
end sub

' Continuar assistindo --------------------------------------------------------------------------------

sub renderHistory()
    m.mode = "history"
    m.loadingText.visible = false
    if m.top.series then items = pr_seriesHistory() else items = pr_movieHistory()
    m.historyRequest = m.request
    m.items = items
    showHistory(items)
    if items.Count() > 0 then rq_send(m.global.library, "enrich", { items: items }, onHistoryEnriched)
end sub

sub onHistoryEnriched(response as object)
    if m.historyRequest <> m.request or m.mode <> "history" or not response.ok then return
    m.items = response.data
    showHistory(m.items)
end sub

sub showHistory(items as object)
    focusIndex = m.grid.itemFocused
    if items.Count() > 0 then
        setSummary("Aperte * sobre um título para removê-lo desta lista.")
    else if m.top.series then
        setSummary("As séries que você começar a assistir aparecerão aqui.")
    else
        setSummary("Os filmes que você começar a assistir aparecerão aqui.")
    end if
    cards = []
    for each item in items
        title = item.title
        if m.top.series and u_str(item.seriesTitle) <> "" then title = item.seriesTitle
        cards.Push({ title: title, poster: item.poster, progress: ui_progressOf(item), sub: season_displaySubtitle(item.subtitle) })
    end for
    root = CreateObject("roSGNode", "ContentNode")
    ui_appendPosters(root, cards)
    m.grid.content = root
    if m.grid.hasFocus() and items.Count() > 0 then
        if focusIndex >= items.Count() then focusIndex = items.Count() - 1
        m.grid.jumpToItem = focusIndex
    else if items.Count() = 0 and m.grid.hasFocus() then
        m.cats.setFocus(true)
    end if
end sub

' Dreamer indica --------------------------------------------------------------------------------------

sub renderRecommendations()
    m.mode = "picks"
    m.items = []
    m.rows = []
    m.grid.content = CreateObject("roSGNode", "ContentNode")
    m.loadingText.visible = true
    setSummary("Carregando as recomendações do Dreamer…")
    m.picksRequest = m.request
    m.picksFirst = true
    rq_send(m.global.library, "build", {}, onLibraryForPicks)
end sub

sub onLibraryForPicks(response as object)
    if m.picksRequest <> m.request then return
    rq_send(m.global.library, "recommendations", {}, onPicks)
end sub

sub onPicks(response as object)
    if m.picksRequest <> m.request or m.mode <> "picks" then return
    m.loadingText.visible = false
    if not response.ok then
        setSummary("Não foi possível carregar as recomendações. Selecione Dreamer indica para tentar novamente.")
        return
    end if
    page = response.data
    m.catalogReady = page.catalogReady
    u_trace("picks", { films: page.films.Count(), checked: page.checked, verifying: page.verifying, ready: page.catalogReady })
    available = 0
    unconfirmed = 0
    for each row in page.films
        if row.sources.Count() > 0 then available = available + 1
        if row.availability = "UNCONFIRMED" then unconfirmed = unconfirmed + 1
    end for
    if page.verifying then
        setSummary("Conferindo disponibilidade: " + u_str(page.checked) + " de " + u_str(page.total))
    else if page.stale then
        setSummary("Exibindo a última seleção salva. A atualização será tentada novamente.")
    else if not page.catalogReady then
        setSummary("Não foi possível conferir a disponibilidade. Atualize a lista e tente novamente.")
    else
        setSummary("Seleção: " + u_str(page.films.Count()) + " · Disponíveis: " + available.ToStr() + " · A confirmar: " + unconfirmed.ToStr())
    end if
    focusIndex = m.grid.itemFocused
    cards = []
    for each row in page.films
        year = u_str(row.film.year)
        if not page.catalogReady then
            status = year + " · A conferir"
        else if row.availability = "CHECKING" then
            status = year + " · Conferindo"
        else if row.availability = "UNCONFIRMED" then
            status = year + " · A confirmar"
        else if row.availability = "UNAVAILABLE" then
            status = year + " · Indisponível"
        else
            status = year + " · Disponível"
        end if
        cards.Push({ title: row.film.title, poster: row.film.details.poster, sub: status, subMuted: true, dim: page.catalogReady and row.availability = "UNAVAILABLE" })
    end for
    m.rows = page.films
    m.items = page.films
    root = CreateObject("roSGNode", "ContentNode")
    ui_appendPosters(root, cards)
    m.grid.content = root
    if not m.picksFirst and m.grid.hasFocus() and focusIndex < cards.Count() then m.grid.jumpToItem = focusIndex
    m.picksFirst = false
end sub

' Keys --------------------------------------------------------------------------------------------------

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    if m.cats.hasFocus() then
        if key = "right" and m.items.Count() > 0 then
            m.grid.setFocus(true)
            return true
        end if
    else if m.grid.hasFocus() then
        if key = "left" then
            m.cats.setFocus(true)
            return true
        end if
        if key = "options" then
            onOptions()
            return true
        end if
    end if
    return false
end function
