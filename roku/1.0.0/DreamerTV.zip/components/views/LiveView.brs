' TV ao vivo and 24 horas. The preview and the full screen share one playback: opening the full screen
' only enlarges the video, and returning shrinks it back into the preview card.

sub init()
    m.cats = m.top.findNode("cats")
    m.chans = m.top.findNode("chans")
    m.header = m.top.findNode("header")
    m.channelsStatus = m.top.findNode("channelsStatus")
    m.preview = m.top.findNode("preview")
    m.frames = [m.top.findNode("frame"), m.top.findNode("frameLeft"), m.top.findNode("frameRight")]
    m.loading = m.top.findNode("loading")
    m.catText = m.top.findNode("catText")
    m.nameText = m.top.findNode("nameText")
    m.hint = m.top.findNode("hint")
    m.badge = m.top.findNode("badge")
    m.top.findNode("tip").text = "Aperte * no controle sobre um canal para favoritar, ou sobre uma categoria para fixar no topo ou ocultar."
    m.cats.observeField("itemSelected", "onCategorySelected")
    m.chans.observeField("itemSelected", "onChannelSelected")
    m.preview.observeField("focusedChild", "onPreviewFocus")
    m.allChannels = []
    m.rawCategories = []
    m.filtered = []
    m.categoryList = []
    m.current = invalid
    m.selectedCategory = ""
    m.active = false
    m.loaded = false
    m.FAVORITES = "__FAV"
    m.RECENT = "__REC"
end sub

function is24h() as boolean
    return m.top.mode = "24h"
end function

function showView(params = invalid as dynamic) as boolean
    m.active = true
    if not m.loaded then
        load()
    else
        renderCategories()
        rq_send(m.global.catalog, "syncChannels", { is24h: is24h() }, onSync)
    end if
    m.global.player.observeFieldScoped("event", "onPlayerEvent")
    return true
end function

function hideView(params = invalid as dynamic) as boolean
    m.active = false
    m.global.player.unobserveFieldScoped("event")
    current = m.global.player.current
    if current <> invalid and u_str(current.owner) = m.top.mode then m.global.player.callFunc("stopPlayback", {})
    m.loading.callFunc("hideBox", {})
    return true
end function

function focusView(params = invalid as dynamic) as boolean
    if m.filtered.Count() > 0 then
        m.chans.setFocus(true)
    else
        ' The channels are still loading: the list takes the focus as soon as they arrive.
        m.focusChannelsWhenLoaded = true
        m.cats.setFocus(true)
    end if
    return true
end function

' Back from the full screen: the channel watched there becomes the current one.
function returnToView(result as object) as boolean
    m.active = true
    m.global.player.observeFieldScoped("event", "onPlayerEvent")
    channel = result.channel
    if channel <> invalid then
        rememberChannel(channel)
        found = findChannel(channel.id)
        if found = invalid then found = channel
        m.current = found
        if indexIn(m.filtered, found.id) < 0 then
            for each c in m.rawCategories
                if LCase(c.name) = LCase(u_str(found.category)) then
                    selectCategory(c, false)
                    exit for
                end if
            end for
        else
            playInPreview(found)
        end if
    end if
    startPreview()
    focusView()
    return true
end function

' Loading --------------------------------------------------------------------------------------------

sub load()
    m.channelsStatus.text = "Carregando canais…"
    m.channelsStatus.visible = true
    rq_send(m.global.catalog, "channels", { is24h: is24h() }, onChannels)
end sub

sub onChannels(response as object)
    if not response.ok then
        m.channelsStatus.text = "Não foi possível carregar os canais. Tente atualizar a lista."
        m.channelsStatus.visible = true
        return
    end if
    m.loaded = true
    m.channelsStatus.visible = false
    adopt(response.data)
    if not m.active then return
    renderCategories()
    if u_true(m.focusChannelsWhenLoaded) and m.cats.hasFocus() and m.filtered.Count() > 0 then m.chans.setFocus(true)
    m.focusChannelsWhenLoaded = false
    maybeAutoBoot()
    rq_send(m.global.catalog, "syncChannels", { is24h: is24h() }, onSync)
end sub

sub onSync(response as object)
    if not response.ok or response.data = invalid or not u_true(response.data.changed) then return
    adopt(response.data)
    if m.active then renderCategories()
end sub

sub adopt(data as object)
    m.allChannels = data.channels
    if m.allChannels.Count() > 0 then m.rawCategories = data.categories else m.rawCategories = []
    lastId = u_str(pr_settings().lastChannelId)
    found = findChannel(lastId)
    if found = invalid and m.current <> invalid then found = findChannel(m.current.id)
    m.current = found
end sub

function findChannel(id as string) as dynamic
    for each c in m.allChannels
        if c.id = id then return c
    end for
    return invalid
end function

function indexIn(list as object, id as string) as integer
    for i = 0 to list.Count() - 1
        if list[i].id = id then return i
    end for
    return -1
end function

' Categories -----------------------------------------------------------------------------------------

function favoriteChannels() as object
    out = []
    for each c in m.allChannels
        if u_true(c.isFavorite) then out.Push(c)
    end for
    return out
end function

function buildCategories() as object
    list = []
    favorites = favoriteChannels().Count()
    recent = cl_recentChannels(m.top.mode, m.allChannels).Count()
    if favorites > 0 then list.Push({ id: m.FAVORITES, name: "FAVORITOS", count: favorites })
    if recent > 0 then list.Push({ id: m.RECENT, name: "RECENTES", count: recent })
    list.Append(cl_order(m.top.mode, m.rawCategories))
    return list
end function

sub setCategoryContent(focusIndex as integer)
    rows = []
    for each c in m.categoryList
        right = ""
        if u_int(c.count) > 0 then right = u_int(c.count).ToStr()
        rows.Push({ title: c.name, right: right, selected: c.id = m.selectedCategory })
    end for
    m.cats.content = ui_textContent(rows)
    if focusIndex >= 0 and focusIndex < rows.Count() then m.cats.jumpToItem = focusIndex
    names = []
    for each c in m.categoryList
        names.Push(c.name)
    end for
    u_trace("categories", { mode: m.top.mode, names: names.Join(" | ") })
end sub

' Rebuilds only the category column, keeping the chosen category and the focus.
sub redrawCategories()
    focusedId = ""
    if m.cats.hasFocus() and m.cats.itemFocused >= 0 and m.cats.itemFocused < m.categoryList.Count() then focusedId = m.categoryList[m.cats.itemFocused].id
    m.categoryList = buildCategories()
    focusIndex = indexIn(m.categoryList, focusedId)
    if focusIndex < 0 then focusIndex = indexIn(m.categoryList, m.selectedCategory)
    setCategoryContent(focusIndex)
end sub

sub renderCategories()
    m.categoryList = buildCategories()
    selected = invalid
    for each c in m.categoryList
        if c.id = m.selectedCategory then selected = c
    end for
    if selected = invalid and m.current <> invalid then
        for each c in m.categoryList
            if LCase(c.name) = LCase(u_str(m.current.category)) then
                selected = c
                exit for
            end if
        end for
    end if
    if selected = invalid and m.categoryList.Count() > 0 then selected = m.categoryList[0]
    if selected = invalid then
        m.selectedCategory = ""
        setCategoryContent(-1)
        m.header.text = "CANAIS"
        m.filtered = []
        m.chans.content = CreateObject("roSGNode", "ContentNode")
        clearPreview("Nenhum canal disponível")
        return
    end if
    m.selectedCategory = selected.id
    setCategoryContent(indexIn(m.categoryList, selected.id))
    selectCategory(selected, false)
end sub

sub selectCategory(category as object, fromClick as boolean)
    m.selectedCategory = category.id
    focusIndex = m.cats.itemFocused
    if not m.cats.hasFocus() then focusIndex = indexIn(m.categoryList, category.id)
    setCategoryContent(focusIndex)
    m.header.text = UCase(category.name)
    if category.id = m.FAVORITES then
        m.filtered = favoriteChannels()
    else if category.id = m.RECENT then
        m.filtered = cl_recentChannels(m.top.mode, m.allChannels)
    else
        m.filtered = []
        key = LCase(category.name)
        for each c in m.allChannels
            if LCase(u_str(c.category)) = key then m.filtered.Push(c)
        end for
    end if
    selectedId = ""
    if m.current <> invalid then selectedId = m.current.id
    m.chans.content = ui_channelContent(m.filtered, selectedId)
    pick = invalid
    if m.current <> invalid then
        at = indexIn(m.filtered, m.current.id)
        if at >= 0 then
            pick = m.filtered[at]
            m.chans.jumpToItem = at
        end if
    end if
    if pick = invalid and m.filtered.Count() > 0 then pick = m.filtered[0]
    if pick <> invalid then
        playInPreview(pick)
    else
        clearPreview("Nenhum canal nesta categoria")
    end if
    u_trace("category", { mode: m.top.mode, name: category.name, channels: m.filtered.Count() })
end sub

sub onCategorySelected()
    index = m.cats.itemSelected
    if index < 0 or index >= m.categoryList.Count() then return
    selectCategory(m.categoryList[index], true)
end sub

' "*" on a category: pin it to the top or hide it. Ajustes undoes both.
sub categoryMenu(category as object)
    m.menuCategory = category
    pinned = cl_isPinned(m.top.mode, category.name)
    label = "Fixar no topo"
    if pinned then label = "Desafixar"
    m.menuPinned = pinned
    ui_choose(category.name, "", [{ label: label, primary: true }, { label: "Ocultar" }, { label: "Cancelar" }], onCategoryMenu)
end sub

sub onCategoryMenu(index as integer)
    c = m.menuCategory
    if index = 0 then
        if m.menuPinned then
            cl_unpin(m.top.mode, c.name)
            ui_toast("Categoria desafixada")
        else
            cl_pin(m.top.mode, c.name)
            ui_toast("Categoria fixada no topo")
        end if
        redrawCategories()
    else if index = 1 then
        cl_hide(m.top.mode, c.name)
        ui_toast("Categoria oculta. Para mostrar de novo: Ajustes > Lista de conteúdo")
        if m.selectedCategory = c.id then
            m.selectedCategory = ""
            renderCategories()
        else
            redrawCategories()
        end if
    end if
end sub

' Channels -------------------------------------------------------------------------------------------

sub onChannelSelected()
    index = m.chans.itemSelected
    if index < 0 or index >= m.filtered.Count() then return
    c = m.filtered[index]
    playInPreview(c)
    rememberChannel(c)
end sub

sub markSelected()
    content = m.chans.content
    if content = invalid then return
    selectedId = ""
    if m.current <> invalid then selectedId = m.current.id
    for i = 0 to content.getChildCount() - 1
        content.getChild(i).selected = i < m.filtered.Count() and m.filtered[i].id = selectedId
    end for
end sub

sub toggleFavorite(c as object)
    now = pr_toggleFavorite(c.id, "CHANNEL")
    if now then ui_toast(c.name + " adicionado aos Favoritos") else ui_toast(c.name + " removido dos Favoritos")
    for each x in m.allChannels
        if x.id = c.id then x.isFavorite = now
    end for
    content = m.chans.content
    for i = 0 to m.filtered.Count() - 1
        if m.filtered[i].id = c.id then content.getChild(i).fav = now
    end for
    redrawCategories()
end sub

' A channel the user chose (OK on the list or the full screen) joins RECENTES.
sub rememberChannel(c as object)
    before = cl_recentChannels(m.top.mode, m.allChannels).Count()
    cl_remember(m.top.mode, c)
    if cl_recentChannels(m.top.mode, m.allChannels).Count() <> before then redrawCategories()
end sub

' Preview ---------------------------------------------------------------------------------------------

sub playInPreview(c as object)
    m.current = c
    pr_setSetting("lastChannelId", c.id)
    markSelected()
    m.nameText.text = c.name
    m.catText.text = u_str(c.category)
    m.badge.visible = true
    m.hint.visible = true
    startPreview()
end sub

sub startPreview()
    if not m.active or m.current = invalid then return
    player = m.global.player
    player.callFunc("setRect", { x: 1120, y: 168, w: 760, h: 428 })
    if player.callFunc("isKeepable", { id: m.current.id }) then
        player.callFunc("setOwner", { owner: m.top.mode })
        return
    end if
    player.callFunc("playItem", { url: m.current.streamUrl, live: true, id: m.current.id, owner: m.top.mode })
end sub

sub clearPreview(message as string)
    current = m.global.player.current
    if current <> invalid and u_str(current.owner) = m.top.mode then m.global.player.callFunc("stopPlayback", {})
    m.loading.callFunc("hideBox", {})
    m.current = invalid
    m.nameText.text = message
    m.catText.text = ""
    m.badge.visible = false
    m.hint.visible = false
end sub

sub onPlayerEvent(event as object)
    e = event.getData()
    if not m.active or e = invalid or e.owner <> m.top.mode then return
    if e.kind = "buffering" then
        message = "Conectando"
        if e.pct <> invalid then message = "Carregando"
        m.loading.callFunc("showStatus", { message: message, pct: e.pct })
    else if e.kind = "ready" then
        m.loading.callFunc("hideBox", {})
    else if e.kind = "retry" then
        m.loading.callFunc("showStatus", { message: "Reconectando", pct: invalid, extra: "Tentativa " + u_str(e.n) + " de " + u_str(e.max) })
    else if e.kind = "error" then
        m.loading.callFunc("showError", { message: e.message, hint: "Escolha outro canal ou abra a tela cheia." })
    end if
end sub

sub onPreviewFocus()
    focused = m.preview.hasFocus()
    color = "0x3A3A3AFF"
    if focused then color = "0xFFFFFFFF"
    for each f in m.frames
        f.color = color
    end for
end sub

sub openFullscreen()
    if m.current = invalid or indexIn(m.filtered, m.current.id) < 0 then return
    rememberChannel(m.current)
    m.active = false
    m.global.player.unobserveFieldScoped("event")
    ui_nav("open", { screen: "PlayerScreen", live: true, channel: m.current, channels: m.filtered, keepLive: true })
end sub

sub maybeAutoBoot()
    if is24h() or m.current = invalid or not m.active then return
    if m.global.autoBootPending then
        m.global.autoBootPending = false
        openFullscreen()
    end if
end sub

' Keys -------------------------------------------------------------------------------------------------

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    u_trace("liveKey", { mode: m.top.mode, key: key, cats: m.cats.hasFocus(), chans: m.chans.hasFocus(), preview: m.preview.hasFocus() })
    if m.cats.hasFocus() then
        if key = "right" and m.filtered.Count() > 0 then
            m.chans.setFocus(true)
            return true
        end if
        if key = "options" then
            index = m.cats.itemFocused
            if index >= 0 and index < m.categoryList.Count() then
                c = m.categoryList[index]
                if c.id <> m.FAVORITES and c.id <> m.RECENT then categoryMenu(c)
            end if
            return true
        end if
    else if m.chans.hasFocus() then
        if key = "left" then
            m.cats.setFocus(true)
            return true
        end if
        if key = "right" then
            m.preview.setFocus(true)
            return true
        end if
        if key = "options" then
            index = m.chans.itemFocused
            if index >= 0 and index < m.filtered.Count() then toggleFavorite(m.filtered[index])
            return true
        end if
    else if m.preview.hasFocus() then
        if key = "left" then
            if m.filtered.Count() > 0 then m.chans.setFocus(true) else m.cats.setFocus(true)
            return true
        end if
        if key = "OK" then
            openFullscreen()
            return true
        end if
    end if
    return false
end function
