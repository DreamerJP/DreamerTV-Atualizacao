' Screen stack, background tasks, messages and choices shared by every screen.

sub init()
    m.top.backgroundColor = "0x0B0B0BFF"
    m.top.backgroundUri = ""
    m.screens = m.top.findNode("screens")
    m.dialog = m.top.findNode("dialog")
    m.toast = m.top.findNode("toast")
    m.toastBox = m.top.findNode("toastBox")
    m.toastText = m.top.findNode("toastText")
    m.toastTimer = m.top.findNode("toastTimer")
    m.stack = []
    m.dialogReturn = invalid

    g = m.global
    for each name in ["toast", "dialogRequest", "dialogResult", "nav"]
        g.addField(name, "assocarray", true)
    end for
    g.addField("autoBootPending", "boolean", false)
    g.addField("updateInfo", "assocarray", false)
    g.autoBootPending = pr_settings().autoBoot

    m.catalog = CreateObject("roSGNode", "CatalogTask")
    m.library = CreateObject("roSGNode", "LibraryTask")
    m.net = CreateObject("roSGNode", "NetTask")
    g.addFields({ catalog: m.catalog, library: m.library, net: m.net, player: m.top.findNode("player") })

    g.observeField("toast", "onToast")
    g.observeField("dialogRequest", "onDialogRequest")
    g.observeField("nav", "onNav")
    m.dialog.observeField("done", "onDialogDone")
    m.toastTimer.observeField("fire", "onToastTimer")

    ' Without "Lembrar meu acesso" the account lasts only while the app is open.
    if not pr_credentials().remember then pr_clearAuth()
    m.catalog.control = "RUN"
    m.library.control = "RUN"
    m.net.control = "RUN"
    if pr_isLoggedIn() then sendSession()
    m.catalog.observeField("ready", "onCatalogReady")
    if m.catalog.ready then onCatalogReady()
end sub

sub sendSession()
    session = pr_session()
    rq_send(m.catalog, "session", session, invalid)
    rq_send(m.library, "session", session, invalid)
end sub

sub onCatalogReady()
    if not m.catalog.ready or u_true(m.started) then return
    m.started = true
    openScreen("LoginScreen", {}, true)
end sub

' Screens ---------------------------------------------------------------------------------------------

sub openScreen(name as string, params as object, reset as boolean)
    if reset then
        while m.stack.Count() > 0
            node = m.stack.Pop()
            node.callFunc("leaveScreen", {})
            m.screens.removeChild(node)
        end while
    else if m.stack.Count() > 0 then
        top = m.stack.Peek()
        ' The focused item is given back when this screen shows again.
        if not top.hasField("returnFocus") then top.addField("returnFocus", "node", false)
        top.returnFocus = ui_focusedLeaf(top)
        top.visible = false
        top.callFunc("coverScreen", {})
    end if
    node = CreateObject("roSGNode", name)
    m.screens.appendChild(node)
    m.stack.Push(node)
    u_trace("screen", { name: name })
    node.callFunc("showScreen", params)
end sub

sub closeScreen(result as dynamic)
    if m.stack.Count() < 2 then return
    node = m.stack.Pop()
    node.callFunc("leaveScreen", {})
    m.screens.removeChild(node)
    top = m.stack.Peek()
    top.visible = true
    if result = invalid then result = {}
    u_trace("screen", { name: top.subtype() })
    top.callFunc("returnToScreen", result)
    if not top.isInFocusChain() then
        focus = top.returnFocus
        if focus <> invalid then focus.setFocus(true) else top.setFocus(true)
    end if
end sub

sub onNav()
    nav = m.global.nav
    if nav = invalid then return
    action = u_str(nav.action)
    if action = "login" then
        openScreen("LoginScreen", nav, true)
    else if action = "main" then
        sendSession()
        openScreen("HomeScreen", nav, true)
    else if action = "session" then
        sendSession()
    else if action = "back" then
        closeScreen(nav.result)
    else if action = "exit" then
        m.top.exitApp = true
    else
        ' details, episodes, options, player and search screens; "replace" takes the place of the top one.
        if u_true(nav.replace) and m.stack.Count() > 1 then
            node = m.stack.Pop()
            node.callFunc("leaveScreen", {})
            m.screens.removeChild(node)
            m.stack.Peek().visible = true
        end if
        openScreen(u_str(nav.screen), nav, false)
    end if
end sub

' Messages and choices -------------------------------------------------------------------------------

sub onToast()
    t = m.global.toast
    if t = invalid then return
    text = u_str(t.text)
    m.toastText.text = text
    width = Len(text) * 15 + 96
    if width < 420 then width = 420
    if width > 1400 then width = 1400
    lines = 1
    if Len(text) * 15 > 1300 then lines = 2
    height = 48 + lines * 40
    m.toastBox.width = width
    m.toastBox.height = height
    m.toastText.width = width - 48
    m.toastText.height = height
    m.toastText.translation = [24, 0]
    m.toastBox.translation = [(1920 - width) / 2, 1080 - height - 80]
    m.toast.visible = true
    u_trace("toast", { text: text })
    m.toastTimer.control = "stop"
    m.toastTimer.duration = u_num(t.seconds)
    m.toastTimer.control = "start"
end sub

sub onToastTimer()
    m.toast.visible = false
end sub

sub onDialogRequest()
    request = m.global.dialogRequest
    if request = invalid then return
    if not m.dialog.visible then m.dialogReturn = ui_focusedLeaf(m.top)
    u_trace("dialog", { title: request.title, options: request.options })
    m.dialog.callFunc("openDialog", request)
end sub

sub onDialogDone()
    done = m.dialog.done
    if m.dialogReturn <> invalid then m.dialogReturn.setFocus(true)
    m.dialogReturn = invalid
    u_trace("choice", { index: done.index })
    m.global.dialogResult = done
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    return false
end function
