sub init()
    m.shade = m.top.findNode("shade")
    m.pct = m.top.findNode("pct")
    m.status = m.top.findNode("status")
    m.detail = m.top.findNode("detail")
    m.dots = m.top.findNode("dots")
    m.dots.observeField("fire", "onDots")
    m.base = ""
    m.step = 0
    m.top.visible = false
    layout()
end sub

sub layout()
    w = m.top.boxWidth
    h = m.top.boxHeight
    m.shade.width = w
    m.shade.height = h
    m.pct.width = w
    m.pct.height = h * 0.45
    m.pct.translation = [0, h * 0.05]
    m.status.width = w - 40
    m.status.translation = [20, h * 0.5]
    m.detail.width = w - 60
    m.detail.translation = [30, h * 0.5 + 50]
end sub

sub onDots()
    m.step = (m.step + 1) mod 4
    dots = ""
    for i = 1 to m.step
        dots = dots + "."
    end for
    m.status.text = m.base + dots
end sub

' params: {message, pct (invalid when unknown), extra}
function showStatus(params as object) as boolean
    m.top.visible = true
    message = "Conectando"
    if params.message <> invalid and params.message <> "" then message = params.message
    m.base = message
    m.status.text = message
    m.status.color = "0xFFFFFFFF"
    if params.pct <> invalid then m.pct.text = params.pct.ToStr() + "%" else m.pct.text = "..."
    extra = ""
    if params.extra <> invalid then extra = params.extra
    m.detail.text = extra
    m.dots.control = "start"
    return true
end function

function showError(params as object) as boolean
    m.top.visible = true
    m.dots.control = "stop"
    m.pct.text = "!"
    m.status.text = params.message
    m.status.color = "0xFDA4AFFF"
    hint = ""
    if params.hint <> invalid then hint = params.hint
    m.detail.text = hint
    return true
end function

function hideBox(params = invalid as dynamic) as boolean
    m.dots.control = "stop"
    m.top.visible = false
    return true
end function
