sub init()
    m.border = m.top.findNode("border")
    m.fill = m.top.findNode("fill")
    m.label = m.top.findNode("label")
    m.top.focusable = true
    m.top.observeField("focusedChild", "render")
    restyle()
end sub

sub restyle()
    font = CreateObject("roSGNode", "Font")
    if m.top.bold then font.uri = "font:BoldSystemFontFile" else font.uri = "font:SystemFontFile"
    font.size = m.top.fontSize
    m.label.font = font
    render()
end sub

sub render()
    w = m.top.width
    h = m.top.height
    focused = m.top.hasFocus()
    m.border.width = w
    m.border.height = h
    m.fill.width = w - 8
    m.fill.height = h - 8
    m.label.width = w - 16
    m.label.height = h
    m.label.translation = [8, 0]
    m.label.text = m.top.text
    isTab = m.top.kind = "tab"
    if focused then
        m.border.color = "0xFFFFFFFF"
        m.fill.color = "0xFFFFFFFF"
        m.label.color = "0x0B0B0BFF"
    else if m.top.disabled then
        m.border.color = "0x121212FF"
        m.fill.color = "0x121212FF"
        m.label.color = "0xA3A3A3FF"
    else if m.top.selected then
        m.fill.color = "0x303030FF"
        if isTab then m.border.color = "0x3A3A3AFF" else m.border.color = "0xD8D8D8FF"
        m.label.color = "0xFFFFFFFF"
    else if isTab then
        m.border.color = "0x00000000"
        m.fill.color = "0x00000000"
        m.label.color = "0xC4C4C4FF"
    else
        m.border.color = "0x3A3A3AFF"
        m.fill.color = "0x1B1B1BFF"
        m.label.color = "0xF5F5F5FF"
    end if
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if press and key = "OK" then
        if not m.top.disabled then m.top.pressed = true
        return true
    end if
    return false
end function
