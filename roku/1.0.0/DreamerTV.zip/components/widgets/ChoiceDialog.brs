sub init()
    m.border = m.top.findNode("border")
    m.box = m.top.findNode("box")
    m.title = m.top.findNode("title")
    m.message = m.top.findNode("message")
    m.list = m.top.findNode("list")
    m.list.observeField("itemSelected", "onSelected")
    m.token = ""
end sub

' request: {token, title, message, options: [{label, selected, primary}]}
function openDialog(request as object) as boolean
    m.token = request.token
    m.title.text = request.title
    message = ""
    if request.message <> invalid then message = request.message
    m.message.text = message
    m.message.visible = message <> ""
    titleHeight = 60
    if Len(request.title) > 40 then titleHeight = 100
    y = 40 + titleHeight
    if message <> "" then
        m.message.translation = [48, y]
        lines = Int(Len(message) / 55) + 1
        if lines > 6 then lines = 6
        y = y + lines * 36 + 24
    end if
    root = CreateObject("roSGNode", "ContentNode")
    focusIndex = 0
    n = 0
    for each option in request.options
        child = root.createChild("ContentNode")
        selected = false
        if option.selected <> invalid then selected = option.selected
        right = ""
        if selected then right = "Atual"
        child.update({ title: option.label, right: right, badge: "", small: "", selected: selected }, true)
        if option.primary <> invalid and option.primary then focusIndex = n
        n = n + 1
    end for
    shown = n
    if shown > 8 then shown = 8
    m.list.numRows = shown
    m.list.translation = [48, y]
    m.list.content = root
    m.list.jumpToItem = focusIndex
    height = y + shown * 92 + 40
    m.border.width = 906
    m.border.height = height + 6
    m.box.width = 900
    m.box.height = height
    m.border.translation = [(1920 - 906) / 2, (1080 - height - 6) / 2]
    m.top.visible = true
    m.list.setFocus(true)
    return true
end function

sub finish(index as integer)
    m.top.visible = false
    m.top.done = { token: m.token, index: index }
end sub

sub onSelected()
    finish(m.list.itemSelected)
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    if key = "back" then
        finish(-1)
        return true
    end if
    ' Keeps the keys inside the box while it is open.
    return true
end function
