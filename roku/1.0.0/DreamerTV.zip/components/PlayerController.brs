' Live channels use the provider's HLS address of the same channel: the Roku player does not accept the
' plain transport stream of the list. Movies and episodes play the list address (MP4 or MKV).
' The player may wait forever without reporting an error; these limits turn a silent stall into a retry
' with a renewed address, like the Samsung and Android players.

sub init()
    m.video = m.top.findNode("video")
    m.watchdog = m.top.findNode("watchdog")
    m.retryTimer = m.top.findNode("retryTimer")
    m.video.observeField("state", "onState")
    m.video.observeField("bufferingStatus", "onBuffering")
    m.video.observeField("position", "onPosition")
    m.watchdog.observeField("fire", "onWatchdog")
    m.retryTimer.observeField("fire", "onRetryTimer")
    m.item = invalid
    m.retries = 0
    m.maxRetries = 5
    m.lastTime = 0
    m.generation = 0
    m.rect = [0, 0, 1920, 1080]
    m.watch = { openedAt: 0, prepared: false, bufferingSince: 0, progressAt: 0, position: -1 }
    agent = CreateObject("roHttpAgent")
    agent.AddHeader("User-Agent", u_providerAgent())
    agent.SetCertificatesFile("common:/certs/ca-bundle.crt")
    agent.InitClientCertificates()
    m.video.setHttpAgent(agent)
end sub

sub emit(kind as string, extra = invalid as dynamic)
    e = { kind: kind, owner: "" }
    if m.item <> invalid then e.owner = u_str(m.item.owner)
    if extra <> invalid then
        for each k in extra
            e[k] = extra[k]
        end for
    end if
    m.top.event = e
end sub

function liveAddress(url as string) as string
    re = CreateObject("roRegex", "^(https?://[^/]+)/([^/]+)/([^/]+)/(\d+)(?:\.ts)?$", "i")
    found = re.Match(url)
    if found.Count() > 4 then return found[1] + "/live/" + found[2] + "/" + found[3] + "/" + found[4] + ".m3u8"
    return url
end function

function streamFormat(url as string, live as boolean) as string
    lower = LCase(url)
    if live or Instr(1, lower, ".m3u8") > 0 then return "hls"
    if u_endsWith(lower, ".mkv") then return "mkv"
    return "mp4"
end function

' item: {url, live, id, owner, startMs, playWhenReady}
function playItem(item as object) as boolean
    m.retries = 0
    openItem(item, u_num(item.startMs))
    return true
end function

' The preview and the full screen hand the same playback to each other.
function setOwner(params as object) as boolean
    if m.item = invalid then return false
    m.item.owner = u_str(params.owner)
    current = m.top.current
    current.owner = m.item.owner
    m.top.current = current
    return true
end function

sub openItem(item as object, startMs as double)
    m.generation = m.generation + 1
    m.retryTimer.control = "stop"
    m.video.control = "stop"
    m.recovering = false
    m.item = item
    m.top.current = { id: u_str(item.id), live: u_true(item.live), url: u_str(item.url), owner: u_str(item.owner) }
    m.lastTime = startMs
    m.watch = { openedAt: u_now(), prepared: false, bufferingSince: 0, progressAt: u_now(), position: -1 }
    url = u_str(item.url)
    live = u_true(item.live)
    if live then url = liveAddress(url)
    content = CreateObject("roSGNode", "ContentNode")
    content.url = url
    content.streamFormat = streamFormat(url, live)
    content.live = live
    if not live and startMs > 0 then content.playStart = startMs / 1000
    m.video.content = content
    applyRect()
    m.video.visible = true
    m.video.suppressCaptions = true
    m.watchdog.control = "start"
    emit("buffering", { pct: invalid })
    u_trace("play", { id: item.id, live: live, format: content.streamFormat })
    if u_false(item.playWhenReady) then
        m.video.control = "prebuffer"
    else
        m.video.control = "play"
    end if
end sub

sub applyRect()
    m.video.translation = [m.rect[0], m.rect[1]]
    m.video.width = m.rect[2]
    m.video.height = m.rect[3]
end sub

function stopPlayback(params = invalid as dynamic) as boolean
    m.generation = m.generation + 1
    m.retryTimer.control = "stop"
    m.watchdog.control = "stop"
    m.video.control = "stop"
    m.video.visible = false
    m.item = invalid
    m.top.current = {}
    return true
end function

function pausePlayback(params = invalid as dynamic) as boolean
    m.video.control = "pause"
    return true
end function

function resumePlayback(params = invalid as dynamic) as boolean
    m.video.control = "resume"
    return true
end function

function togglePlayback(params = invalid as dynamic) as boolean
    if m.video.state = "playing" then
        m.video.control = "pause"
    else
        m.video.control = "resume"
    end if
    return true
end function

function seekTo(params as object) as boolean
    ms = u_num(params.ms)
    if ms < 0 then ms = 0
    m.lastTime = ms
    m.video.seek = ms / 1000
    return true
end function

function setRect(params as object) as boolean
    m.rect = [u_num(params.x), u_num(params.y), u_num(params.w), u_num(params.h)]
    applyRect()
    return true
end function

function fullscreen(params = invalid as dynamic) as boolean
    m.rect = [0, 0, 1920, 1080]
    applyRect()
    return true
end function

function playerState(params = invalid as dynamic) as string
    if m.item = invalid then return "none"
    return m.video.state
end function

' True while this channel's playback is open and has not failed or ended, even before the first image.
function isKeepable(params as object) as boolean
    if m.item = invalid or not u_true(m.item.live) or u_str(m.item.id) <> u_str(params.id) then return false
    state = m.video.state
    return state <> "error" and state <> "stopped" and state <> "finished"
end function

function playerTime(params = invalid as dynamic) as double
    p = m.video.position
    if p = invalid or p < 0 then return m.lastTime
    return p * 1000
end function

function playerDuration(params = invalid as dynamic) as double
    d = m.video.duration
    if d = invalid or d <= 0 then return 0
    return d * 1000
end function

function audioTracks(params = invalid as dynamic) as object
    out = []
    selected = u_str(m.video.audioTrack)
    n = 0
    tracks = m.video.availableAudioTracks
    if tracks = invalid then return out
    for each t in tracks
        n = n + 1
        name = u_str(t.Name)
        language = u_str(t.Language)
        if name = "" and language <> "" then name = UCase(language)
        if name = "" then name = "Áudio " + n.ToStr()
        out.Push({ track: u_str(t.Track), name: name, selected: u_str(t.Track) = selected })
    end for
    return out
end function

function selectAudio(params as object) as boolean
    m.video.audioTrack = u_str(params.track)
    return true
end function

function textTracks(params = invalid as dynamic) as object
    out = []
    tracks = m.video.availableSubtitleTracks
    if tracks = invalid then return out
    selected = u_str(m.video.subtitleTrack)
    n = 0
    for each t in tracks
        n = n + 1
        name = u_str(t.Description)
        language = u_str(t.Language)
        if name = "" and language <> "" then name = UCase(language)
        if name = "" then name = "Legenda " + n.ToStr()
        track = u_str(t.TrackName)
        out.Push({ track: track, name: name, selected: track = selected and not m.video.suppressCaptions })
    end for
    return out
end function

' track "" hides the embedded subtitles.
function selectText(params as object) as boolean
    track = u_str(params.track)
    if track = "" then
        m.video.suppressCaptions = true
    else
        m.video.subtitleTrack = track
        m.video.globalCaptionMode = "On"
        m.video.suppressCaptions = false
    end if
    return true
end function

' Events --------------------------------------------------------------------------------------------

sub onState()
    if m.item = invalid then return
    state = m.video.state
    u_trace("state", { state: state })
    if state = "playing" then
        if not m.watch.prepared then m.retries = 0
        m.watch.prepared = true
        m.watch.bufferingSince = 0
        m.watch.progressAt = u_now()
        emit("ready")
    else if state = "buffering" then
        if m.watch.bufferingSince = 0 then m.watch.bufferingSince = u_now()
        emit("buffering", { pct: invalid })
    else if state = "paused" then
        m.watch.bufferingSince = 0
        emit("paused")
    else if state = "finished" then
        ' An error is followed by "finished"; only a playback that really ran can end.
        if u_true(m.recovering) then return
        if not m.watch.prepared then
            ' A late "finished" from the previous address is ignored right after opening a new one.
            if u_now() - m.watch.openedAt > 1500 then failed(-3, "finished before playing")
        else
            emit("ended")
        end if
    else if state = "error" then
        failed(m.video.errorCode, u_str(m.video.errorMsg))
    end if
end sub

sub onBuffering()
    if m.item = invalid then return
    status = m.video.bufferingStatus
    if status <> invalid and status.percentage <> invalid then emit("buffering", { pct: u_int(status.percentage) })
end sub

sub onPosition()
    if m.item = invalid then return
    m.lastTime = playerTime()
    emit("time", { ms: m.lastTime })
end sub

function errorMessage(code as integer) as string
    if code = -5 then return "Este formato não pôde ser reproduzido neste aparelho."
    if code = -1 or code = -2 then return "Não foi possível reconectar. Verifique a conexão e tente novamente."
    return "Não foi possível reproduzir este conteúdo. Tente outro canal ou vídeo."
end function

sub failed(code as integer, detail as string)
    if u_true(m.recovering) then return
    m.recovering = true
    u_trace("error", { code: code, detail: detail })
    fatal = code = -5 or code = -4
    if not fatal and m.item <> invalid and not u_true(m.item.live) and m.retries = 0 then
        ' The player does not report HTTP answers; a missing or refused file must not be retried.
        m.probeGeneration = m.generation
        m.probeCode = code
        rq_send(m.global.net, "probe", { url: m.item.url }, onProbe)
        return
    end if
    retryLater(code)
end sub

sub onProbe(response as object)
    if m.probeGeneration <> m.generation or m.item = invalid then return
    status = 0
    if response.data <> invalid then status = u_int(response.data.status)
    if status = 404 or status = 410 then
        closePlayer()
        emit("error", { message: "Este conteúdo não está disponível no servidor." })
        return
    end if
    if status = 401 or status = 403 then
        closePlayer()
        emit("error", { message: "Acesso não autorizado pelo servidor. Verifique sua conta." })
        return
    end if
    retryLater(m.probeCode)
end sub

sub closePlayer()
    m.watchdog.control = "stop"
    m.retryTimer.control = "stop"
    m.video.control = "stop"
end sub

sub retryLater(code as integer)
    fatal = code = -5 or code = -4
    if not fatal and m.retries < m.maxRetries and m.item <> invalid then
        m.retries = m.retries + 1
        emit("retry", { n: m.retries, max: m.maxRetries })
        delay = m.retries * 1.2
        if delay > 5 then delay = 5
        m.video.control = "stop"
        m.retryTimer.duration = delay
        m.retryGeneration = m.generation
        m.retryTimer.control = "start"
        return
    end if
    closePlayer()
    emit("error", { message: errorMessage(code) })
end sub

sub onRetryTimer()
    if m.item = invalid or m.retryGeneration <> m.generation then return
    session = pr_session()
    item = u_copyAA(m.item)
    item.url = pr_refreshUrl(session, item.url)
    resumeAt = m.lastTime
    if u_true(item.live) then resumeAt = 0
    retries = m.retries
    openItem(item, resumeAt)
    m.retries = retries
end sub

sub stalled()
    m.watch.prepared = true
    m.watch.bufferingSince = 0
    m.watch.progressAt = u_now()
    u_trace("stalled")
    failed(-2, "stall")
end sub

sub onWatchdog()
    if m.item = invalid then return
    now = u_now()
    live = u_true(m.item.live)
    if not m.watch.prepared then
        if now - m.watch.openedAt > 25000 then stalled()
        return
    end if
    limit = 25000
    if live then limit = 15000
    if m.watch.bufferingSince > 0 and now - m.watch.bufferingSince > limit then
        stalled()
        return
    end if
    if m.video.state = "playing" then
        position = m.video.position
        if position <> m.watch.position then
            m.watch.position = position
            m.watch.progressAt = now
        else if live and now - m.watch.progressAt > 12000 then
            stalled()
        end if
    else
        m.watch.progressAt = now
    end if
end sub
