sub Main(args as dynamic)
    screen = CreateObject("roSGScreen")
    port = CreateObject("roMessagePort")
    screen.SetMessagePort(port)
    info = CreateObject("roAppInfo")
    m.global = screen.getGlobalNode()
    ' Test packages set dtv_trace=1 so the computer checks can follow each step of the app.
    m.global.addFields({ traceEnabled: info.GetValue("dtv_trace") = "1" })
    scene = screen.CreateScene("MainScene")
    screen.Show()
    scene.observeField("exitApp", port)
    while true
        msg = wait(0, port)
        msgType = type(msg)
        if msgType = "roSGScreenEvent" then
            if msg.isScreenClosed() then return
        else if msgType = "roSGNodeEvent" then
            if msg.getField() = "exitApp" then
                screen.Close()
                return
            end if
        end if
    end while
end sub
